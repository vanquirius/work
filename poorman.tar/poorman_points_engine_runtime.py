# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# Points Engine Runtime

from poorman_back_end import *

if postgreSQLSupport == 1:
    from poorman_points_engine_postgresql import *
else:
    from poorman_points_engine_csv import *

beginLogPointsEngine()

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################

# Import batch files
if postgreSQLSupport == 1:
    programSetupLoad()
    userProfileLoad()
    wrapperExternalAccount()
    welcomeUserQueue()
    addUser()
    updateUser()
    pointsBankLoad()
    loadPointsLoad()
    redeemPointsLoad()
    expiredPointsLoad()
    addedPointsLoad()
    redeemApprovedLoad()
    redeemRejectedLoad()
else:
    programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
    userProfileDF = userProfileLoad()
    wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)
    welcomeUserQueueDF = welcomeUserQueue()
    addUserDF = addUser()
    updateUserDF = updateUser()
    pointsBankDF = pointsBankLoad()
    loadPointsDF = loadPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
    redeemPointsDF = redeemPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
    expiredPointsDF = expiredPointsLoad()
    addedPointsDF = addedPointsLoad()
    redeemApprovedDF = redeemApprovedLoad()
    redeemRejectedDF = redeemRejectedLoad()

# Process batch files
batchBackup()

if postgreSQLSupport == 1:
    # Merge program setup attributes
    programSetupMerge()
    # Add new users to profile
    addUserProfile()
    # Update new users to profile
    updateUserProfile()
    # Convert new transactions into points, add them to point bank, add them to control of added points, remove transactions from points to be loaded
    addPointsBank()
    # Removed expired points from points bank and move them to control of expired points
    removeExpiredPoints()
    # Approve or reject redemption requests and move them control of approved/rejected redemptions, remove from points bank when approved
    redeemPoints()
    # Generate outgoing batch files
    outAddedPoints()
    outExpiredPoints()
    outRedeemApproved()
    outRedeemRejected()
    # Generate redeemable points list
    listRedeemable()
else:
    # Merge program setup attributes
    programSetupAttributesDF = programSetupMerge(programSetupDF, programAttribDF)
    # Add new users to profile
    userProfileDF, addUserDF, welcomeUserQueueDF = addUserProfile(userProfileDF, addUserDF, welcomeUserQueueDF)
    # Update new users to profile
    userProfileDF, updateUserDF = updateUserProfile(userProfileDF, updateUserDF, wrapperExternalAccountDF, wrapperTaxIDDF)
    # Convert new transactions into points, add them to point bank, add them to control of added points, remove transactions from points to be loaded
    pointsBankDF, addedPointsDF, loadPointsDF = addPointsBank(loadPointsDF, programSetupAttributesDF, pointsBankDF, addedPointsDF, programAttribDF, userProfileDF)
    # Removed expired points from points bank and move them to control of expired points
    pointsBankDF, expiredPointsDF = removeExpiredPoints(pointsBankDF,expiredPointsDF)
    # Approve or reject redemption requests and move them control of approved/rejected redemptions, remove from points bank when approved
    redeemPointsDF, pointsBankDF, redeemApprovedDF, redeemRejectedDF = redeemPoints(redeemPointsDF,pointsBankDF,redeemApprovedDF,redeemRejectedDF,programSetupAttributesDF,userProfileDF)
    # Generate outgoing batch files
    outAddedPointsDF = outAddedPoints(addedPointsDF, outgoingBatchCut, userProfileDF)
    outExpiredPointsDF = outExpiredPoints(expiredPointsDF, outgoingBatchCut, userProfileDF)
    outRedeemApprovedDF = outRedeemApproved(redeemApprovedDF, outgoingBatchCut, userProfileDF)
    outRedeemRejectedDF = outRedeemRejected(redeemRejectedDF, outgoingBatchCut, userProfileDF)
    # Generate redeemable points list
    listRedeemableDF = listRedeemable(pointsBankDF, programAttribDF, userProfileDF, programSetupAttributesDF)

if postgreSQLSupport == 1:
    batchExport()
else:
    batchExport(programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF, userProfileDF, welcomeUserQueueDF, pointsBankDF, expiredPointsDF, addedPointsDF, redeemApprovedDF, redeemRejectedDF, listRedeemableDF, loadPointsDF, redeemPointsDF, addUserDF, updateUserDF, outAddedPointsDF, outExpiredPointsDF, outRedeemApprovedDF, outRedeemRejectedDF)

endLogPointsEngine()