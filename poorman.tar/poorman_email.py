# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-15
# E-mail module

from poorman_back_end import *
import time
import re

def validateEmail(mailTo):
    emailRegex = '^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w{2,3}$'     
    if(re.search(emailRegex,mailTo)):  
        return True       
    else:  
        return False

def sendSingleEmail(mailSubject, mailContent, mailTo):
    if allowSendMail == 1:
        if validateEmail(mailTo) == True:
            message = MIMEMultipart()
            message['Subject'] = mailSubject
            message['To'] = mailTo
            message['From'] = userEmail
            message.attach(MIMEText(mailContent, 'plain'))
            session = smtplib.SMTP(smptServer, smptPort)
            session.starttls()
            session.login(userEmail, userPassword)
            text = message.as_string()      
            time.sleep(mailWait)
            session.sendmail(userEmail, reportsEmail, text)
            session.quit()
        if verbose == 1:
            print("E-mail sent")

def testEmail(reportsEmail):
    mailSubject = "Poorman's Payback Test E-Mail"
    mailContent = "Poorman's Payback Test E-Mail"
    mailTo = reportsEmail
    sendSingleEmail(mailSubject, mailContent, mailTo)