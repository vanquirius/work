# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# API Redeem - PostgreSQL version

# How to run development server (Windows/Linux):
# set FLASK_APP=poorman_api_redeem_postgresql.py (Windows)
# set FLASK_DEBUG=1 (Windows)
# export FLASK_APP=poorman_api_redeem_postgresql.py (Linux)
# export FLASK_DEBUG=1 (Linux)
# python -m flask run -p [port number]

# API server and redemption server are on different files by design
# They should be run separately so that only the redemption server is customer facing,
# while the API server is meant to exchange services with other systems

from poorman_points_engine_postgresql import *

import flask
from flask import request, jsonify

beginLogAPIServer

#######################################################################################################################################################
# Program                                                                                                                                             #
#######################################################################################################################################################

app = flask.Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    return '''<h1>Poorman's Payback API Server</h1>
<p>This is the API Server for Poorman's Payback.</p>'''

@app.route('/api/redeem/request', methods=['GET'])
# Attempt to redeem points
def postUserRedeem():
    if 'token' in request.args:
        # get token
        tokenReceived = str(request.args['token'])
        if verbose == 1:
            print("Token processed: " + str(tokenReceived))
        requestNumber = str(secrets.token_hex(16))

        conn, cur = postgreSQLConnect(postgreSQL_dic)  
        # load token table
        # filter out entry for token
        # organize data that came from API
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeemtoken_" + requestNumber
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeemtoken_" + requestNumber + " as SELECT Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, NULL AS Tax_ID, NULL AS External_Account_Code FROM poorman.redeemablesent WHERE Token_code = '" + tokenReceived + "'"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # load points tables
        # append new points to redeem attempt
        SQLCommand = "INSERT INTO poorman.redeempoints (SELECT * FROM poorman.redeemtoken_" + requestNumber +")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove token from database
        SQLCommand = "DELETE FROM poorman.redeemablesent WHERE Token_code = '" + tokenReceived + "'"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # clean-up
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeemtoken_" + requestNumber
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        
        # attempt to redeem points
        pointsBankLoad()
        redeemPoints()
        
        return "Success: request was received"
    else:
        return "Error: unable to process request"

endLogAPIServer()