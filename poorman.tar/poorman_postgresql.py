# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-12
# PostgreSQL module

from poorman_back_end import *
import psycopg2

# Connection parameters
postgreSQL_dic = {
    "host"      : postgreSQLServer,
    "database"  : postgreSQLDB,
    "user"      : postgreSQLUsername,
    "password"  : postgreSQLPassword,
    "application_name" : "poorman_postgresql"
}

def postgreSQLConnect(postgreSQL_dic):
    # Connect to the PostgreSQL database server
    conn = None
    try:
        conn = psycopg2.connect(**postgreSQL_dic)
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
        sys.exit(1)
    cur = conn.cursor()
    return conn, cur

def postgreSQLExecuteCommand(cur, SQLCommand):
    # Execute SQL commands in PostgreSQL database server
    cur.execute(SQLCommand)

def postgreSQLClose(conn, cur):
    # Commit changes and disconnect from PostgreSQL database server
    conn.commit()
    cur.close()
    conn.close()

def postgreSQLtoPandas(cur, SQLCommand, fieldnames):
    # Select data and move to Pandas dataframe
    try:
       cur.execute(SQLCommand)
    except (Exception, psycopg2.DatabaseError) as error:
        print("Error: %s" % error)
        return 1
   
    tupples = cur.fetchall()
    df = pandas.DataFrame(tupples, columns=fieldnames)
    return df