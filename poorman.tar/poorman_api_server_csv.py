# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-17
# API Server - csv version

# How to run development server (Windows/Linux):
# set FLASK_APP=poorman_api_server_csv.py (Windows)
# set FLASK_DEBUG=1 (Windows)
# export FLASK_APP=poorman_api_server_csv.py (Linux)
# export FLASK_DEBUG=1 (Linux)
# python -m flask run -p [port number]

# API server and redemption server are on different files by design
# They should be run separately so that only the redemption server is customer facing,
# while the API server is meant to exchange services with other systems

from poorman_points_engine_csv import *

import flask
from flask import request, jsonify

beginLogAPIServer

#######################################################################################################################################################
# Program                                                                                                                                             #
#######################################################################################################################################################

app = flask.Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    return '''<h1>Poorman's Payback API Server</h1>
<p>This is the API Server for Poorman's Payback.</p>'''

@app.route('/api/programs/setup', methods=['GET'])
# Get list of programs
def getPrograms():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
        jsonResults = programSetupDF.to_json(orient="split")
        return jsonResults

    else:
        return "Error: token not accepted or missing"

@app.route('/api/programs/attributes', methods=['GET'])
# Get list of programs
def getProgramsAttrib():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
        jsonResults = programAttribDF.to_json(orient="split")
        return jsonResults

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/usercode', methods=['GET'])
# Get user information with user code
def getUsersPerUserCode():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            userProfileDF = userProfileLoad()
            userProfileDF = userProfileDF.loc[userProfileDF['User_Code'].astype(str) == usercode]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/taxid', methods=['GET'])
# Get user information based on tax ID
def getUsersPerTaxID():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'taxid' in request.args:
            taxid = str(request.args['taxid'])
            userProfileDF = userProfileLoad()
            userProfileDF = userProfileDF.loc[userProfileDF['Tax_ID'].astype(str) == taxid]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: tax id missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/externalaccount', methods=['GET'])
# Get user information based on external account
def getUsersPerExternalAccount():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'externalaccount' in request.args:
            externalaccount = str(request.args['externalaccount'])
            userProfileDF = userProfileLoad()
            userProfileDF = userProfileDF.loc[userProfileDF['External_Account_Code'].astype(str) == externalaccount]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: external account missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/pointsbank', methods=['GET'])
# Get points bank information based on user code
def getPointsBankperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            pointsBankDF = pointsBankLoad()
            pointsBankDF = pointsBankDF.loc[pointsBankDF['User_Code'].astype(str) == usercode]
            jsonResults = pointsBankDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/added', methods=['GET'])
# Get added points history based on user code
def getAddedPointsperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            addedPointsDF = addedPointsLoad()
            addedPointsDF = addedPointsDF.loc[addedPointsDF['User_Code'].astype(str) == usercode]
            jsonResults = addedPointsDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/expired', methods=['GET'])
# Get expired points history based on user code
def getExpiredPointsperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            expiredPointsDF = expiredPointsLoad()
            expiredPointsDF = expiredPointsDF.loc[expiredPointsDF['User_Code'].astype(str) == usercode]
            jsonResults = expiredPointsDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/approved', methods=['GET'])
# Get approved redemptions based on user code
def getApprovedRedeemperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            redeemApprovedDF = redeemApprovedLoad()
            redeemApprovedDF = redeemApprovedDF.loc[redeemApprovedDF['User_Code'].astype(str) == usercode]
            jsonResults = redeemApprovedDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/rejected', methods=['GET'])
# Get rejected redemptions based on user code
def getRejectedRedeemperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            redeemRejectedDF = redeemRejectedLoad()
            redeemRejectedDF = redeemRejectedDF.loc[redeemRejectedDF['User_Code'].astype(str) == usercode]
            jsonResults = redeemRejectedDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"


@app.route('/api/users/add', methods=['POST'])
# Add new user profile
def postAddUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('activeuser' in request.args) & ('useremail' in request.args) & ('usermobilecountrycode' in request.args) & ('usermobileareacode' in request.args) & ('usermobilephonenumber' in request.args) & ('activeemail' in request.args) & ('activemobile' in request.args) & ('taxid' in request.args) & ('externalaccountcode' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            activeuser = str(request.args['activeuser'])
            useremail = str(request.args['useremail'])
            usermobilecountrycode = str(request.args['usermobilecountrycode'])
            usermobileareacode = str(request.args['usermobileareacode'])
            usermobilephonenumber = str(request.args['usermobilephonenumber'])
            activeemail = str(request.args['activeemail'])
            activemobile = str(request.args['activemobile'])
            taxid = str(request.args['taxid'])
            externalaccountcode = str(request.args['externalaccountcode'])

            # organize data that came from API
            newUserDF = pandas.DataFrame({'Corp_Code' : [corpcode], 'Program_Code' : [programcode], 'Active_User' : [activeuser], 'User_Email' : [useremail], 'User_Mobile_Country_Code' : [usermobilecountrycode], 'User_Mobile_Area_Code' : [usermobileareacode], 'User_Mobile_Phone_Number' : [usermobilephonenumber], 'Active_Email' : [activeemail], 'Active_Mobile' : [activemobile], 'Tax_ID' : [taxid], 'External_Account_Code' : [externalaccountcode]})

            # load user tables
            addUserDF = addUser()
            userProfileDF = userProfileLoad()
            welcomeUserQueueDF = welcomeUserQueue()

            # append new user to add user list
            addUserDF = addUserDF.append(newUserDF)

            # add new users to profile
            userProfileDF, addUserDF, welcomeUserQueueDF = addUserProfile(userProfileDF, addUserDF, welcomeUserQueueDF)

            # export updated files
            userProfileDF.to_csv("UserProfile.csv", index = False)
            welcomeUserQueueDF.to_csv("WelcomeUserQueue.csv", index = False)
            addUserDF.to_csv(incomingbatchFileDirectory + "AddUserProfile.csv", index = False)

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/update', methods=['POST'])
# Update profile of existing user
def postUpdateUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('activeuser' in request.args) & ('useremail' in request.args) & ('usermobilecountrycode' in request.args) & ('usermobileareacode' in request.args) & ('usermobilephonenumber' in request.args) & ('activeemail' in request.args) & ('activemobile' in request.args) & ('taxid' in request.args) & ('externalaccountcode' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            activeuser = int(request.args['activeuser'])
            useremail = str(request.args['useremail'])
            usermobilecountrycode = str(request.args['usermobilecountrycode'])
            usermobileareacode = str(request.args['usermobileareacode'])
            usermobilephonenumber = str(request.args['usermobilephonenumber'])
            activeemail = int(request.args['activeemail'])
            activemobile = int(request.args['activemobile'])
            taxid = str(request.args['taxid'])
            externalaccountcode = str(request.args['externalaccountcode'])

            # organize data that came from API
            newUpdateDF = pandas.DataFrame({'Corp_Code' : [corpcode], 'Program_Code' : [programcode], 'User_Code' : [usercode], 'Active_User' : [activeuser], 'User_Email' : [useremail], 'User_Mobile_Country_Code' : [usermobilecountrycode], 'User_Mobile_Area_Code' : [usermobileareacode], 'User_Mobile_Phone_Number' : [usermobilephonenumber], 'Active_Email' : [activeemail], 'Active_Mobile' : [activemobile], 'Tax_ID' : [taxid], 'External_Account_Code' : [externalaccountcode]})
 
            # load user tables
            updateUserDF = updateUser()
            userProfileDF = userProfileLoad()
            wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)

            # append new user to add user list
            updateUserDF = updateUserDF.append(newUpdateDF)

            # update users to profile
            userProfileDF, updateUserDF = updateUserProfile(userProfileDF, updateUserDF, wrapperExternalAccountDF, wrapperTaxIDDF)

            # export updated files
            userProfileDF.to_csv("UserProfile.csv", index = False)
            updateUserDF.to_csv(incomingbatchFileDirectory + "UpdateUserProfile.csv", index = False)

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/add', methods=['POST'])
# Add points to user
def postAddPoints():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('currencycode' in request.args) & ('value' in request.args) & ('externalaccountcode' in request.args) & ('taxid' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            currencycode = int(request.args['currencycode'])
            value = float(request.args['value'])
            dateday = str(datetime.now().day)
            datemonth = str(datetime.now().month)
            dateyear = str(datetime.now().year)
            externalaccountcode = str(request.args['externalaccountcode'])
            taxid = str(request.args['taxid'])

            # organize data that came from API
            newPointsDF = pandas.DataFrame({'Corp_Code' : [corpcode], 'Program_Code' : [programcode], 'User_Code' : [usercode], 'Currency_Code' : [currencycode], 'Value' : [value], 'Date_Day' : [dateday], 'Date_Month' : [datemonth], 'Date_Year' : [dateyear], 'External_Account_Code' : [externalaccountcode], 'Tax_ID' : [taxid]})
 
            # load points tables
            userProfileDF = userProfileLoad()
            wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)
            loadPointsDF = loadPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
            programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
            programSetupAttributesDF = programSetupMerge(programSetupDF, programAttribDF)
            pointsBankDF = pointsBankLoad()
            addedPointsDF = addedPointsLoad()
            userProfileDF = userProfileLoad()

            # append new points to load points
            loadPointsDF = loadPointsDF.append(newPointsDF)

            # add points to point bank
            pointsBankDF, addedPointsDF, loadPointsDF = addPointsBank(loadPointsDF, programSetupAttributesDF, pointsBankDF, addedPointsDF, programAttribDF, userProfileDF)

            # export updated files
            pointsBankDF.to_csv("PointsBank.csv", index = False)
            addedPointsDF.to_csv("AddedPoints.csv", index = False)
            loadPointsDF.to_csv(incomingbatchFileDirectory + "LoadPoints.csv", index = False)

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/execute', methods=['POST'])

# Attempt to redeem points
def postRedeemPoints():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
 
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('points' in request.args) & ('externalaccountcode' in request.args) & ('taxid' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            points = float(request.args['points'])
            dateday = str(datetime.now().day)
            datemonth = str(datetime.now().month)
            dateyear = str(datetime.now().year)
            externalaccountcode = str(request.args['externalaccountcode'])
            taxid = str(request.args['taxid'])

            # organize data that came from API
            newRedeemDF = pandas.DataFrame({'Corp_Code' : [corpcode], 'Program_Code' : [programcode], 'User_Code' : [usercode], 'Points' : [points], 'Date_Day' : [dateday], 'Date_Month' : [datemonth], 'Date_Year' : [dateyear], 'External_Account_Code' : [externalaccountcode], 'Tax_ID' : [taxid]})
 
            # load points tables
            userProfileDF = userProfileLoad()
            wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)
            redeemPointsDF = redeemPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
            pointsBankDF = pointsBankLoad()
            redeemApprovedDF = redeemApprovedLoad()
            redeemRejectedDF = redeemRejectedLoad()
            programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
            programSetupAttributesDF = programSetupMerge(programSetupDF, programAttribDF)
            addedPointsDF = addedPointsLoad()
            userProfileDF = userProfileLoad()

            # append new points to redeem attempt
            redeemPointsDF = redeemPointsDF.append(newRedeemDF)

            # attempt to redeem points
            redeemPointsDF, pointsBankDF, redeemApprovedDF, redeemRejectedDF = redeemPoints(redeemPointsDF,pointsBankDF,redeemApprovedDF,redeemRejectedDF,programSetupAttributesDF,userProfileDF)

            # export updated files
            redeemPointsDF.to_csv(incomingbatchFileDirectory + "RedeemPoints.csv", index = False)
            pointsBankDF.to_csv("PointsBank.csv", index = False)
            redeemApprovedDF.to_csv("RedeemApproved.csv", index = False)
            redeemRejectedDF.to_csv("RedeemRejected.csv", index = False)

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

endLogAPIServer()