# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-15
# Event broker module - PostgreSQL version

from poorman_points_engine_postgresql import *
from poorman_email import *
from poorman_sms import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# Send welcome message to new users
def sendWelcomeQueue():
    try:
        welcomeUserQueueDF = readWelcomeUserQueuePostgreSQL()
        if welcomeUserQueueDF.empty == False: 
            # get amount of rows in queue
            welcomeIndex = welcomeUserQueueDF.index
            welcomeRows = len(welcomeIndex)

            # loop through queue
            for queueNumber in range(0, welcomeRows):
                userCode = welcomeUserQueueDF.iloc[queueNumber]['User_Code']
                activeUser = welcomeUserQueueDF.iloc[queueNumber]['Active_User']
                activeUserEmail = welcomeUserQueueDF.iloc[queueNumber]['Active_Email']
                activeUserMobile = welcomeUserQueueDF.iloc[queueNumber]['Active_Mobile']

                # send e-mail
                if activeUser == 1 & activeUserEmail == 1 & sendWelcomeEmail == 1:
                    userEmail = welcomeUserQueueDF.iloc[queueNumber]['User_Email']
                    mailTo = userEmail
                    mailSubject = "Welcome User " + str(userCode) + " to Poorman's Payback!!!"
                    mailContent = "User " + str(userCode) + ", welcome to the coolest payback program on the market!"
                    sendSingleEmail(mailSubject, mailContent, mailTo)
            
                # send SMS
                if activeUser == 1 & activeUserMobile == 1 & sendWelcomeSMS == 1:
                    areaCode = welcomeUserQueueDF.iloc[queueNumber]['User_Mobile_Area_Code']
                    phoneNumber = welcomeUserQueueDF.iloc[queueNumber]['User_Mobile_Phone_Number']
                    sendSingleSMS(smsText, areaCode, phoneNumber)

            # empty out queue
            conn, cur = postgreSQLConnect(postgreSQL_dic)
            SQLCommand = "DELETE FROM poorman.welcomeuserqueue"
            postgreSQLExecuteCommand(cur, SQLCommand)
            postgreSQLClose(conn, cur)

        successSendWelcomeQueue()
    except:
        failSendWelcomeQueue()
        errorTerminationLog()
        raise
    return welcomeUserQueueDF

# Create and control mail list for users with redeemable points
def manageRedeemable():
    try:
        # load new list, compare against previously sent list
        conn, cur = postgreSQLConnect(postgreSQL_dic)        
        
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeemablesent2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeemablesent2 AS SELECT * FROM poorman.redeemablesent"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeemablesent2 DROP COLUMN IF EXISTS Points2"
        postgreSQLExecuteCommand(cur, SQLCommand)       
        SQLCommand = "ALTER TABLE poorman.redeemablesent2 RENAME Points TO Points2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DROP TABLE IF EXISTS poorman.listredeemable2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.listredeemable2 AS SELECT * FROM poorman.listredeemable"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Token_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Token_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Token_Sent"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Token_Sent int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Points2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Points2 float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Active_Email"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Active_Email int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Active_Mobile"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Active_Mobile int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS User_Email"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD User_Email varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS User_Mobile_Area_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD User_Mobile_Area_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS User_Mobile_Phone_Number"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD User_Mobile_Phone_Number varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS User_Mobile_Country_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD User_Mobile_Country_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 DROP COLUMN IF EXISTS Currency_Name"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable2 ADD Currency_Name varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "UPDATE poorman.listredeemable2 as a SET Token_Code = b.Token_Code, Token_Sent = b.Token_Sent, Points2 = b.Points2 FROM poorman.redeemablesent2 as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.listredeemable2 as a SET Currency_Name = b.Currency_Name FROM poorman.currencynames as b WHERE a.Redeem_Currency_Code = b.Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.listredeemable2 as a SET Active_Email = b.Active_Email, Active_Mobile = b.Active_Mobile, User_Email = b.User_Email, User_Mobile_Area_Code = b.User_Mobile_Area_Code, User_Mobile_Phone_Number = b.User_Mobile_Phone_Number, User_Mobile_Country_Code = b.User_Mobile_Country_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
            
        # if there is a change in points, create a new token and set sent to 0
        # get amount of rows in queue
        SQLCommand = "UPDATE poorman.listredeemable2 SET Token_Sent = 0, Token_Code = concat(User_Code,'-',substr(md5(random()::text), 0, 16)) WHERE Points <> Points2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Repopulate redeem sent
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeemablesent"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeemablesent as SELECT Corp_Code, Program_Code, User_Code, Points, Redeem_Currency_Code, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Redeem_Value, Date_Day, Date_Month, Date_Year, Token_Code, Token_Sent, Points2, Currency_Name FROM poorman.listredeemable2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # clean-up
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeemablesent2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.listredeemable2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        postgreSQLClose(conn, cur)
        successManageRedeemable()
    except:
        failManageRedeemable()
        errorTerminationLog()
        raise

# Send communication to users with redeemable points that have not been sent this before
def sendRedeemable():
    try:
        redeemableSentDF = readRedeemableSentPostgreSQL()
        if redeemableSentDF.empty == False:

            # get amount of rows in queue
            listIndex = redeemableSentDF.index
            listRows = len(listIndex)

            # loop through queue
            for queueNumber in range(0, listRows):
                userCode = redeemableSentDF.iloc[queueNumber]['User_Code']
                activeUserEmail = redeemableSentDF.iloc[queueNumber]['Active_Email']
                activeUserMobile = redeemableSentDF.iloc[queueNumber]['Active_Mobile']
                points = redeemableSentDF.iloc[queueNumber]['Points']
                value = redeemableSentDF.iloc[queueNumber]['Redeem_Value']
                currencyName = redeemableSentDF.iloc[queueNumber]['Currency_Name']
                tokenCode = redeemableSentDF.iloc[queueNumber]['Token_Code']
                tokenSent = redeemableSentDF.iloc[queueNumber]['Token_Sent']

                # send e-mail
                if (activeUserEmail == 1) & (tokenSent == 0):
                    userEmail = redeemableSentDF.iloc[queueNumber]['User_Email']
                    mailTo = userEmail
                    mailSubject = "Redeem " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " + str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals)))
                    mailContent = "User " + str(userCode) + ", you are now able to exchange " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " +  str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals))) + ". Please click on the link to make your request: " + str(domainLink) + ":" + str(redeemPort) + "/api/redeem/request?token=" + str(tokenCode)
                    sendSingleEmail(mailSubject, mailContent, mailTo)
            
                # send SMS
                if (activeUserMobile == 1) & (tokenSent == 0):
                    areaCode = redeemableSentDF.iloc[queueNumber]['User_Mobile_Area_Code']
                    phoneNumber = redeemableSentDF.iloc[queueNumber]['User_Mobile_Phone_Number']
                    smsText = "Exchange " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " +  str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals))) + ". Link: " + str(domainLink) + ":" + str(redeemPort) + "/api/redeem/request?token=" + str(tokenCode)
                    sendSingleSMS(smsText, areaCode, phoneNumber)

            # mark list as sent
            conn, cur = postgreSQLConnect(postgreSQL_dic)
            SQLCommand = "UPDATE poorman.redeemablesent as a SET Token_Sent = 1"
            postgreSQLExecuteCommand(cur, SQLCommand)
            postgreSQLClose(conn, cur)
           
            successSendRedeemable()
    except:
        failSendRedeemable()
        errorTerminationLog()
        raise