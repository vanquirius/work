# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-17

# README.txt

**************************************************************************************************************************
* What is this software - Poorman's Payback?									         *
**************************************************************************************************************************

Poorman's Payback is a loyalty engine written in Python geared towards cashback programs.
It is meant to be lightweight and easy to integrate with other products such as cards or loans.

Features:
- Points Engine
-- Core of the system. Loads configuration for loyalty programs, users and takes interfaces to add, redeem or expire
   points. Consists of a batch process that can be run in its own internal database format (.csv) or in conjunction
   with an external database like PostgreSQL.
- API Engine
-- Online interfaces to the system. Made of two modules: the first is meant for the program manager and is not available
   for the end clients. The second module is exclusive to allow end clients to redeem points through tokenized links.
- Event Broker (E-Mail and SMS)
-- Sends a welcome message to new users.
-- Sends tokenized links for users to redeem points (supported by the API Engine above).
- Log file
-- Logs all events in poorman.log to support with debugging and auditting.
- Configuration file
-- Preferences about how the software should run.

Software dependencies:
- Python >=3.7
-- Pandas
-- Numpy
-- Flask
-- psycopg2 (optional if using external database)
-- azure-storage-file-share (optional if deploying to Azure)
- PostgreSQL (optional if using external database)
- comtele_sdk (optional for SMS integration for Brazil)

How to use Poorman's Payback:
- Please edit the configuration file poorman_config.py according to your preferences and installation.
- If using internal .csv files, files must follow the provided templates for the databases.
- If using external database (i.e. PostgreSQL), it must be configured first.
  Use poorman_postgresql_create.py to create the initial tables.
  Use poorman_postgresql_migrate_runtime.py if you have data in .csv that you want to migrate to PostgreSQL
  Warning: .csv and PostgreSQL are not interchangeable; choose one or the other when in production.
- Points engine (poorman_points_engine_runtime.py) and
  Event Broker (poorman_event_broker_runtime.py) should be configured to run periodically, at least once a day.
- There are two API servers that can be run: poorman_api_server_csv.py (or poorman_api_server_postgresql.py) has the
  API's that should be accessible by the program manager (avoid exposing to the Internet)
  and poorman_api_redeem_csv.py (or poorman_api_redeem_postgresql.py) has one user-facing API to redeem points
  (needs to be exposed to the Internet).

**************************************************************************************************************************
* Configuring poorman_config.py 											 *
**************************************************************************************************************************

- Set whether you want to work with .csv files or an external database.
- Set paths for your working directory, incoming batch files and outgoing batch files.
- Set how many decimal points you want to work with for currency (recommended: 2) and for points.
- Set cut for batch interfaces; this is important if you are feeding an external system (i.e. card processing platform).
  Recommended: "day".
- Set an API token for the server (very strong and random). This will be needed to access the API Server.
- Set the ports for the API servers - this will also be used when generating links (can be left blank if port is 80).
- Set the domain link for the redeem tokens (i.e. http://www.mydomain.com).
- Choose whether you want to allow e-mail and SMS communications and whether you want to send welcome e-mail and SMS's.
  When set to 0 (1 = on, 0 = off), this will override individual user preferences.
- Choose allowed times when the event broker can run (to avoid sending SMS's to users at unwanted times).
- Set tokens and test numbers for your SMS broker.
- Set e-mail server settings so that users may receive e-mails (i.e. SMPT server).

**************************************************************************************************************************
* Setting up the databases									    		         *
**************************************************************************************************************************
When using internal .csv databases:
- Additional columns in batch files will be ignored
- Missing columns in batch files will cause an error
- Changing column order will not impact execution, but is not recommended

-- Setting up the loyalty programs
--- CorpNames           unique code for tenants and their names
                        (Corp_Code = 1, Corp_Name = Bank 1)
--- CountryCodes        unique country codes and names
                        (Country_Code = 1, Country_Name = United States)
--- CurrencyNames       unique currency codes (preferably ISO8583 standard) and names
                        (Currency_Code = 840, Currency_Name = US$)
--- ProductNames        unique product codes and names
                        (Product_Code = 1, Product_Name = Card)
--- ProgramNames        unique program codes and names
                        (Program_Code = 1, Program_Name = Poorman Card Gold)
--- ProgramSetup        Main attributes linked to loyalty programs
			Corp_Code, Country_Code, Program_code, Product_Code and Currency_Code linked to tables above,
	                the other two fields configure points to be generated per currency and how many days to expire
                        (Points_per_Currency = 1, Expiration_Days = 365)
--- ProgramAttrib       Additional attributes linked to loyalty programs
			Program_Code linked to table above
                        Active_Program enables or disables program (1 = on, 0 = off)
                        Redeem_Currency_Code sets the currency code for redemption (i.e. 840)
                        Currency_per_Points sets how much each point is worth
                        Redeem_Min_points sets the minimum points allowed in a redemption event (i.e. 1,000 points)
                        Renew_Expiry_On_Purchase sets whether expiry date is extended for
                        existing points when a new purchase is made

-- Setting up users
--- UserProfile         Controls information for users of the loyalty programs
			Corp_Code, Program_Code linked to the loyalty program tables
		        User_Code unique internal identifier
 		        Active_User whether user is active (1 = on, 0 = off)
		        User_Email is the user email (user@email.com)
		        User_Mobile_Country_Code - is the country code for the mobile number (i.e. 1 for the US)
		        User_Mobile_Area_Code - is the area code for the mobile number
		        User_Mobile_Phone_Number - is the mobile phone number
		        Active_Email whether users should get emails from the tool (1 = on, 0 = off)
 		        Active_Mobile whether users should get texts from the tool (1 = on, 0 = off)
		        Tax_ID is the tax ID for the user (i.e. SSN in the US, CPF in Brazil)
		        External_Account_Code is the user code in the interfacing systems;
                        for example, this could be a user token in a card processing platform		 

-- Files automatically generated to control the loyalty program
--- PointsBank          Controls points bank considering loyalty programs and users
			Corp_Code, Program_Code linked to the loyalty program tables
		        User_Code is linked to the UserProfile
                        Points is the amount of user points in the bank
		        Date_Day, Date_Month and Date_Year are relative to the input date into the points bank
                        Expiry_Date_Day, Expiry_Date_Month and Expiry_Date_Year are relative
                        to the expected expiration date
--- AddedPoints         Historical information on added points
			Corp_Code, Program_Code linked to the loyalty program tables
	                User_Code is linked to the UserProfile
                        Points is how many points were added in this specific historic entry
		        Currency_Code means the currency that was used to generate the points
                        Points_per_Currency means the ratio of currency per points used in the calculation
      		        Date_Day, Date_Month and Date_Year are relative to the input date into the points bank
                        Expiry_Date_Day, Expiry_Date_Month and Expiry_Date_Year are relative
                        to the expected expiration date
                        Added_ID is a unique identifier for the entry
--- ExpiredPoints       Historical information on expired points
			Corp_Code, Program_Code linked to the loyalty program tables
	                User_Code is linked to the UserProfile
		        Points is how many points were expired in this specific historic entry
      		        Date_Day, Date_Month and Date_Year are relative to the input date into the points bank
                        Expiry_Date_Day, Expiry_Date_Month and Expiry_Date_Year are relative
                        to the actual expiration date
                        Expired_ID is a unique identifier for the entry
--- RedeemApproval	Historical information on approved redemptions
			Corp_Code, Program_Code linked to the loyalty program tables
	                User_Code is linked to the UserProfile
			Points are how many points were redeemed
			Date_Day, Date_Month and Date_Year are relative to the processing date
			Redeem_Currency_Code is the currency that was redeemed
			Redeem_Value is the financial value that was claimed
			Approval_ID is the internal control for approved redemptions
--- RedeemRejected	Historical information on rejected redemptions
			Mirrors structure for RedeemApproval
			Points are how many points the user tried to redeem
			Redeem_Value is the financial value that would have been redeemed
			Rejected_ID is the internal control for rejected redemptions
--- ListRedeemable      A dynamic list of users who have points to be redeemed
			Corp_Code, Program_Code linked to the loyalty program tables
			Points is the total amount of points available to be redeemed
      		        Date_Day, Date_Month and Date_Year are relative to the generation date
			Redeem_Currency_Code is the code for the currency in which the benefit will be paid
			Redeem_Value is the expected financial amount for the redemption
--- RedeemableSent      Control of users who received or not a token to redeem points
			Same fields as list redeemable, plus the fields below
			Token_Code is a dynamic token to allow API's to request redemptions
			Token_Sent controls whether user received the token before (1 = yes, 0 = no)
			Points2 controls previous positions and expires/reissues new tokens if necessary
			Currency_Name is linked to CurrencyNames table		

--- WelcomeUserQueue    Queue to send a welcome e-mail/SMS to new users of the programs
			Corp_Code, Program_Code linked to the loyalty program tables
		        All other fields linked to the UserProfile
			
-- Incoming interfaces  (to come from external systems, such as a card processing platform)
--- AddUserProfile   	Interface to add a new user. All fields are the same as UserProfile
			except User_Code that is assigned internally after processing
--- UpdateUserProfile   Interface to update existing user information. All fields are the same as UserProfile
			Changes will be made based on User_Code
			If no User_Code is passed but Tax_ID or External Account are present,
			User_Code will be inferred
--- LoadPoints   	Used to load transactions into points in the system
			Corp_Code, Program_Code linked to the loyalty program tables
			User_Code is linked to the UserProfile
			Currency_Code is the currency for each transaction
			Value is the financial value of the transaction
			Date_Day, Date_Month and Date_Year are relative to the transaction date
			Tax_ID and External Account are relative to the UserProfile
			If no User_Code is passed but Tax_ID or External Account are present,
			User_Code will be inferred
--- RedeemPoints  	Used to redeem points from the system; requests may be accepted or rejected
			Corp_Code, Program_Code linked to the loyalty program tables
			
-- Outgoing interfaces (to be loaded in external systems, such as a card processing platform)
-- Outgoing interfaces include the following fields on top of the original ones:
   Batch cut date (Batch_Day, Batch_Month, Batch_Year), Tax_ID and External Account
--- OutAddedPoints  	AddedPoints cut by period set in configuration
--- OutExpiredPoints    ExpiredPoints cut by period set in configuration
--- OutRedeemApproved   RedeemApproved cut by period set in configuration
--- OutRedeemRejected   RedeemRejected cut by period set in configuration

**************************************************************************************************************************
* API's															 *
**************************************************************************************************************************
All API's are REST/JSON by design.

/api/programs/setup
- Method: GET
- Required argument(s): apiToken
- Returns: full list of programs in JSON format

/api/programs/attributes
- Method: GET
- Required argument(s): apiToken
- Returns: full list of program attributes in JSON format

/api/users/usercode
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: UserProfile filted by usercode in JSON format

/api/users/taxid
- Method: GET
- Required argument(s): apiToken and taxid
- Returns: UserProfile filted by usercode in JSON format
- Note: important if you want to discover the usercode and only have the tax id

/api/users/externalaccount
- Method: GET
- Required argument(s): apiToken and externalaccount
- Returns: UserProfile filted by usercode in JSON format
- Note: important if you want to discover the usercode and only have the external account

/api/points/pointsbank
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: bank points filtered by usercode in JSON format

/api/points/added
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: history of added points filtered by usercode in JSON format

/api/points/expired
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: history of expired points filtered by usercode in JSON format

/api/redeem/approved
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: history of approved redemption requested filtered by usercode in JSON format

/api/redeem/rejected
- Method: GET
- Required argument(s): apiToken and usercode
- Returns: history of rejected redemption requested filtered by usercode in JSON format

/api/users/add
- Method: POST
- Required argument(s): apiToken, corpcode, programcode, activeuser, useremail, usermobilecountrycode, 
  usermobileareacode, usermobilephonenumber, activeemail, activemobile, taxid, externalaccountcode
- Effects: creates a new user in the system

/api/users/update
- Method: POST
- Required argument(s): apiToken, corpcode, usercode, programcode, activeuser, useremail, usermobilecountrycode, 
  usermobileareacode, usermobilephonenumber, activeemail, activemobile, taxid, externalaccountcode
- Effects: updates an new user in the system

/api/points/add
- Method: POST
- Required argument(s): apiToken, corpcode, programcode, usercode, currencycode, value, externalaccountcode, taxid
- Effects: adds points to point bank for selected user

/api/redeem/execute
- Method: POST
- Required argument(s): apiToken, corpcode, programcode, usercode, points, externalaccountcode, taxid
- Effects: requests to redeem points for selected user
- Note: request by be approved or rejected (i.e. inactive user, not enough points)

/api/redeem/request
- Method: GET
- Required argument(s): token
- Effects: this runs a previously created request
- Note 1: request by be approved or rejected (i.e. inactive user, not enough points)
- Note 2: this is in separate server (poorman_api_redeem_csv or poorman_api_redeem_postgresql.py) than the other API's

**************************************************************************************************************************
* Deploying to Azure as a native application										 *
**************************************************************************************************************************
- Create, configure and use an external database (i.e. PostgreSQL).
  Note that the database does not have to be in Azure necessarily.
- Create and configure Azure Files Storage. This will be the working directory for the application, as well as where
  incoming and outgoing batch interfaces will be stored.
- Install the API servers as Python Apps for Flask
  (https://docs.microsoft.com/en-us/azure/app-service/quickstart-python?tabs=bash&pivots=python-framework-flask)
- Run the batch programs in Azure Batch
  (https://docs.microsoft.com/en-us/azure/batch/quick-run-python)

**************************************************************************************************************************
* Q&A															 *
**************************************************************************************************************************
Why not give the ability to delete programs and users?
- This could corrupt the database, including historical information. The recommended way is make programs and users that
  are not needed any longer into inactive (i.e. Active_Program = 0, Active_User = 0). User data such as e-mail and mobile
  number can still be removed.

How to remove points without redeeming? Is there an interface?
- The recommended way is to setup a currency code that is not in use by any external platform, set Points_per_Currency
  equal to the points amount and redeem those points away from the system. This is useful if you are rolling back a
  transaction in an external system and want to remove points (i.e. card processing chargeback).
  Note: posting negative points will be ignored by the system as invalid input.

Why support .csv and external databases?
- .csv allows for easy development and setup without the need of a full database. It also supports smaller workloads.
  Files can always be migrated to an external database with help of the migration tool.