# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# Event broker runtime

from poorman_config import *

if postgreSQLSupport == 1:
    from poorman_event_broker_postgresql import *
else:
    from poorman_event_broker_csv import *

beginLogEventBroker()

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################

# Process will only run at approved time windows
hourNow = datetime.now().hour

if ((hourNow in (23, 24, 0, 1, 2, 3, 4, 5, 6, 7, 8) == 1) & (timeAllowed22to8 == 1)) | timeAllowed9to21 == 1:

    if postgreSQLSupport == 1:
        # Import batch files
        manageRedeemable()
        sendRedeemable()

        # Process welcome queue
        sendWelcomeQueue()

    else:
        # Import batch files
        welcomeUserQueueDF = welcomeUserQueue()
        userProfileDF = userProfileLoad()
        listRedeemableDF, redeemableSentDF = loadListRedeemable()
        programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
        redeemableSentDF = manageRedeemable(listRedeemableDF, redeemableSentDF, currencyNamesDF, userProfileDF)
        redeemableSentDF = sendRedeemable(redeemableSentDF)

        # Process batch files
        batchBackup()

        # Process welcome queue
        welcomeUserQueueDF = sendWelcomeQueue(welcomeUserQueueDF)

        batchExport(welcomeUserQueueDF, redeemableSentDF)

endLogEventBroker()