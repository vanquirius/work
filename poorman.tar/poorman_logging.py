# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-14
# Back-end

import logging
from datetime import datetime
from poorman_config import *

logging.basicConfig(filename='poorman.log', filemode='a', level=logging.DEBUG, format='%(asctime)s %(message)s')

# General Logs Functions
def runLog(logtext):
    logging.info(logtext)
    if verbose == 1:
        print(logtext)

def beginLog():
    logtext = "Poorman's Payback started"
    runLog(logtext)

def endLog():
    logtext =  "Poorman's Payback ended"
    runLog(logtext)

def errorTerminationLog():
    logtext =  "Poorman's Payback terminated with an error"
    runLog(logtext)

def successBatchExport():
    logtext =  "Successfully exported batch files"
    runLog(logtext)

def failBatchExport():
    logtext =  "Failed to export batch files"
    runLog(logtext)

def successBatchBackup():
    logtext =  "Successfully backed-up previous batch files"
    runLog(logtext)

def failBatchBackup():
    logtext =  "Failed to back up previous batch files"
    runLog(logtext)

# Points Engine
def beginLogPointsEngine():
    logtext =  "Points Engine started"
    runLog(logtext)

def endLogPointsEngine():
    logtext =  "Points Engine ended"
    runLog(logtext)

# Points Engine - Import routine
def loadedProgramSetup():
    logtext =  "PE - Program Setup loaded"
    runLog(logtext)

def failedProgramSetup():
    logtext =  "PE - Program Setup failed"
    runLog(logtext)

def loadedUserProfile():
    logtext =  "PE - User Profile loaded"
    runLog(logtext)

def failedUserProfile():
    logtext =  "PE - User Profile failed"
    runLog(logtext)

def loadedAddUser():
    logtext =  "PE - Add User loaded"
    runLog(logtext)

def failedAddUser():
    logtext =  "PE - Add User failed"
    runLog(logtext)

def loadedUpdateUser():
    logtext =  "PE - Update User loaded"
    runLog(logtext)

def failedUpdateUser():
    logtext =  "PE - Update User failed"
    runLog(logtext)

def loadedPointsBank():
    logtext =  "PE - Points Bank loaded"
    runLog(logtext)

def failedPointsBank():
    logtext =  "PE - Points Bank failed"
    runLog(logtext)

def loadedLoadPoints():
    logtext =  "PE - Load Points loaded"
    runLog(logtext)

def failedLoadPoints():
    logtext =  "PE - Load Points failed"
    runLog(logtext)

def loadedRedeemPoints():
    logtext =  "PE - Redeem Points loaded"
    runLog(logtext)

def failedRedeemPoints():
    logtext =  "PE - Redeem Points failed"
    runLog(logtext)

def loadedExpiredPoints():
    logtext =  "PE - Expired Points loaded"
    runLog(logtext)

def failedExpiredPoints():
    logtext =  "PE - Expired Points failed"
    runLog(logtext)

def loadedAddedPoints():
    logtext =  "PE - Added Points loaded"
    runLog(logtext)

def failedAddedPoints():
    logtext =  "PE - Added Points failed"
    runLog(logtext)

def loadedRedeemApproved():
    logtext =  "PE - Approved redemptions loaded"
    runLog(logtext)

def failedRedeemApproved():
    logtext =  "PE - Approved redemptions failed"
    runLog(logtext)

def loadedRedeemRejected():
    logtext =  "PE - Rejected redemptions loaded"
    runLog(logtext)

def failedRedeemRejected():
    logtext =  "PE - Rejected redemptions failed"
    runLog(logtext)

def sucessWrapperExternalAccount():
    logtext =  "PE - Wrapper for external accounts successful"
    runLog(logtext)

def failedWrapperExternalAccount():
    logtext =  "PE - Wrapper for external accounts failed"
    runLog(logtext)

# Points Engine - Processing

def successMergeProgramSetup():
    logtext =  "PE - Successfully joined program setup tables"
    runLog(logtext)

def failMergeProgramSetup():
    logtext =  "PE - Failed to join program setup tables"
    runLog(logtext)

def successWelcomeQueue():
    logtext =  "Successfully loaded welcome queue"
    runLog(logtext)

def failWelcomeQueue():
    logtext =  "Failed to load welcome queue"
    runLog(logtext)

def successAddUserProfile():
    logtext =  "PE - Successfully added user to profile"
    runLog(logtext)

def failAddUserProfile():
    logtext =  "PE - Failed to add user to profile"
    runLog(logtext)

def successUpdateUserProfile():
    logtext =  "PE - Successfully updated user to profile"
    runLog(logtext)

def failUpdateUserProfile():
    logtext =  "PE - Failed to update user to profile"
    runLog(logtext)

def successRemoveExpiredPoints():
    logtext =  "PE - Successfully removed expired points from point bank"
    runLog(logtext)

def failRemoveExpiredPoints():
    logtext =  "PE - Failed to remove expired points from point bank"
    runLog(logtext)

def successAddPointsBank():
    logtext =  "PE - Successfully added batch points to point bank"
    runLog(logtext)

def failAddPointsBank():
    logtext =  "PE - Failed to add batch points to point bank"
    runLog(logtext)

def successRedeemPointsBank():
    logtext =  "PE - Successfully redeemed batch points from point bank"
    runLog(logtext)

def failRedeemPointsBank():
    logtext =  "PE - Failed to redeem batch points from point bank"
    runLog(logtext)
def successOutFile():
    logtext =  "PE - Successfully generated outgoing batch file"
    runLog(logtext)

def failOutFile():
    logtext =  "PE - Failed to generate outgoing batch file"
    runLog(logtext)

def successReports():
    logtext =  "PE - Successfully generated reports"
    runLog(logtext)

def failReports():
    logtext =  "PE - Failed to generate reports"
    runLog(logtext)

def successListRedeemable():
    logtext =  "PE - Successfully listed redeemable points"
    runLog(logtext)

def failListRedeemable():
    logtext =  "PE - Failed to list redeemable points"
    runLog(logtext)

# Points Engine - Errors/Warnings/Checks

def notUniqueError():
    logtext =  "Warning: expected unique values, data did not match"
    runLog(logtext)

def notExpectedError():
    logtext =  "Warning: data not in expected format"
    runLog(logtext)

def checkOk():
    logtext =  "Check: data format ok"
    runLog(logtext)

def blankFile():
    logtext =  "Warning: file has no data"
    runLog(logtext)

# Event Broker
def beginLogEventBroker():
    logtext =  "Event Broker started"
    runLog(logtext)

def endLogEventBroker():
    logtext =  "Event Broker ended"
    runLog(logtext)

def successSendWelcomeQueue():
    logtext =  "EB - Successfully processed welcome queue"
    runLog(logtext)

def failSendWelcomeQueue():
    logtext =  "EB - Failed to process welcome queue"
    runLog(logtext)

def loadedListRedeemable():
    logtext =  "EB - List redeemable loaded"
    runLog(logtext)

def failedListRedeemable():
    logtext =  "EB - List redeemable failed"
    runLog(logtext)

def successManageRedeemable():
    logtext =  "EB - Reedemable list ran with success"
    runLog(logtext)

def failManageRedeemable():
    logtext =  "EB - Reedeemable list failed"
    runLog(logtext)

def successSendRedeemable():
    logtext =  "EB - Sent communication to redeemable users"
    runLog(logtext)

def failSendRedeemable():
    logtext =  "EB - Failed to send communication to redeemable users"
    runLog(logtext)

# API Server
def beginLogAPIServer():
    logtext =  "API server started"
    runLog(logtext)

def endLogAPIServer():
    logtext =  "API server ended"
    runLog(logtext)

# Test Kit
def beginLogTestKit():
    logtext =  "Test Kit started"
    runLog(logtext)

def endLogTestKit():
    logtext =  "TestKit ended"
    runLog(logtext)

# GUI
def beginLogGUI():
    logtext =  "GUI started"
    runLog(logtext)

def endLogGUI():
    logtext =  "GUI ended"
    runLog(logtext)