# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-01
# Back-end

import os
from poorman_config import *
# Set working directory
os.chdir(workingDirectory)

import shutil
import pandas
import numpy
import smtplib
import string
import secrets
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime, timedelta
from poorman_logging import *

# Headers
programName = "Poorman Payback"
programAuthor = "Marcelo Ambrosio de Góes"
version = "0.1"

# Setup Corporation
corporation = "FIS"

# Import configuration
from poorman_config import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# Open file
def openFile(filename):
    file = open(filename,'rb')
    
    # headers
    programName = pickle.load(file)
    programAuthor = pickle.load(file)
    version = pickle.load(file)
    timestamp = pickle.load(file)

    # setup corporation
    corporation = pickle.load(file)

    file.close()
    # log
    logging.info(filename + " opened")

    # return loaded variables
    return programName, programAuthor, version, timestamp, corporation

# Save file
def saveFile(filename, corporation):
    timestamp = datetime.today().strftime('%Y-%m-%d-%H:%M:%S')
    file = open(filename,'wb')
    
    # headers
    pickle.dump(programName, file)
    pickle.dump(programAuthor, file)
    pickle.dump(version, file)
    pickle.dump(timestamp, file)

    # setup corporation
    pickle.dump(corporation, file)

    file.close
    # log
    logging.info(filename + " saved")

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################
beginLog()