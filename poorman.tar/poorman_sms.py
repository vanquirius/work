# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-15
# SMS module

from poorman_back_end import *
from comtele_sdk.textmessage_service import TextMessageService

def validatePhone(areaCode, phoneNumber):
    if areaCode.isdecimal() & phoneNumber.isdecimal():
        return True       
    else:  
        return False

def sendSingleSMS(smsText, areaCode, phoneNumber):
    if allowSendSMS == 1:
        if validatePhone(areaCode, phoneNumber) == True:
            #textmessage_service = TextMessageService(smsToken)
            #result = textmessage_service.send(
            #    # ID for reports
            #    'ppb',
            #    # Text to be sent
            #    smsText,
            #    # Phone number
            #    [str(areaCode) + str(phoneNumber)])
            #print(result)
            print("SMS module disabled by hardcode")
        if verbose == 1:
            print("SMS sent")

def testSMS():
    smsText = "Poorman's Payback Test SMS"
    areaCode = smsTestAreaCode
    phoneNumber = smsTestPhoneNumber
    sendSingleSMS(smsText, areaCode, phoneNumber)

#testSMS()