# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# PostgreSQL module to create new tables

from poorman_postgresql import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# creates poorman schema if it does not exist
def createSchemaPostgreSQL():
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "CREATE SCHEMA IF NOT EXISTS poorman"
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)

# deletes existing tablesS
def cleanUpExistingPostgreSQL():
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "DROP TABLE IF EXISTS poorman.addedpoints"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.adduserprofile"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.corpnames"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.currencynames"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.expiredpoints"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.listredeemable"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.outaddedpoints"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.outexpiredpoints"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.outredeemapproved"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.outredeemrejected"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.productnames"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.programattrib"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.programnames"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.programsetupattrib"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.redeemablesent"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.redeemapproved"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.redeemrejected"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.updateuserprofile"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.userprofile"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.welcomeuserqueue"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.wrapperexternalaccount"
    postgreSQLExecuteCommand(cur, SQLCommand)
    SQLCommand = "DROP TABLE IF EXISTS poorman.wrappertaxid"
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print("Existing PostgreSQL tables dropped")

# CorpNames
def createCorpNamesPostgreSQL():
    tablename = "corpnames"
    fieldnames = "Corp_Code varchar PRIMARY KEY, Corp_Name varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# CountryCodes
def createCountryCodesPostgreSQL():
    tablename = "countrycodes"
    fieldnames = "Country_Code varchar PRIMARY KEY, Country_Name varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# CurrencyNames
def createCurrencyNamesPostgreSQL():
    tablename = "currencynames"
    fieldnames = "Currency_Code varchar PRIMARY KEY, Currency_Name varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ProductNames
def createProductNamesPostgreSQL():
    tablename = "productnames"
    fieldnames = "Product_Code varchar PRIMARY KEY, Product_Name varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ProgramNames
def createProgramNamesPostgreSQL():
    tablename = "programnames"
    fieldnames = "Program_Code varchar PRIMARY KEY, Program_Name varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ProgramSetup
def createProgramSetupPostgreSQL():
    tablename = "programsetup"
    fieldnames = "Corp_Code varchar, Country_Code varchar, Program_Code varchar, Currency_Code varchar, Points_per_Currency float8, Expiration_Days int8"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ProgramAttrib
def createProgramAttribPostgreSQL():
    tablename = "programattrib"
    fieldnames = "Program_Code varchar PRIMARY KEY, Active_Program int, Redeem_Currency_Code varchar, Currency_per_Points float8, Redeem_Min_points float8, Renew_Expiry_On_Purchase int"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# UserProfile
def createUserProfilePostgreSQL():
    tablename = "userprofile"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8 PRIMARY KEY, Active_User int, User_Email varchar, User_Mobile_Country_Code varchar, User_Mobile_Area_Code varchar, User_Mobile_Phone_Number varchar, Active_Email int, Active_Mobile int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# PointsBank
def createPointsBankPostgreSQL():
    tablename = "pointsbank"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Expiry_Date_Day int, Expiry_Date_Month int, Expiry_Date_Year int"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# AddedPoints
def createAddedPointsPostgreSQL():
    tablename = "addedpoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Points float8, Currency_Code	varchar, Value float8, Points_per_Currency float8, Date_Day	int, Date_Month	int, Date_Year int, Expiry_Date_Day	int, Expiry_Date_Month int, Expiry_Date_Year int, Added_ID int8 PRIMARY KEY"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ExpiredPoints
def createExpiredPointsPostgreSQL():
    tablename = "expiredpoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Expiry_Date_Day int, Expiry_Date_Month int, Expiry_Date_Year int, Expiry_ID int8 PRIMARY KEY"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# RedeemApproved
def createRedeemApprovedPostgreSQL():
    tablename = "redeemapproved"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Redeem_Currency_Code varchar, Redeem_Value float8, Approval_ID int8 PRIMARY KEY"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# RedeemRejected
def createRedeemRejectedPostgreSQL():
    tablename = "redeemrejected"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Redeem_Currency_Code varchar, Redeem_Value float8, Rejected_ID int8 PRIMARY KEY"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# ListRedeemable
def createListRedeemablePostgreSQL():
    tablename = "listredeemable"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8 PRIMARY KEY, Points float8, Date_Day int,	Date_Month int, Date_Year int, Redeem_Currency_Code	varchar, Redeem_Value float8"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"  
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# RedeemableSent
def createRedeemableSentPostgreSQL():
    tablename = "redeemablesent"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8 PRIMARY KEY, Points float8, Date_Day int,	Date_Month int, Date_Year int, Redeem_Currency_Code	varchar, Redeem_Value float8, Token_Code varchar, Token_Sent int, Points2 float8, Currency_Name	varchar, Active_Email int, Active_Mobile int, User_Email varchar, User_Mobile_Area_Code varchar, User_Mobile_Phone_Number varchar, User_Mobile_Country_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# WelcomeUserQueue
def createWelcomeUserQueuePostgreSQL():
    tablename = "welcomeuserqueue"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8 PRIMARY KEY, Active_User int, User_Email varchar, User_Mobile_Country_Code varchar, User_Mobile_Area_Code varchar, User_Mobile_Phone_Number varchar, Active_Email	int, Active_Mobile int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# AddUserProfile
def createAddUserPostgreSQL():
    tablename = "adduserprofile"
    fieldnames = "Corp_Code varchar, Program_Code varchar, Active_User int, User_Email varchar, User_Mobile_Country_Code varchar, User_Mobile_Area_Code varchar, User_Mobile_Phone_Number varchar, Active_Email int, Active_Mobile int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# UpdateUserProfile
def createUpdateUserPostgreSQL():
    tablename = "updateuserprofile"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Active_User int, User_Email varchar, User_Mobile_Country_Code varchar, User_Mobile_Area_Code varchar, User_Mobile_Phone_Number varchar, Active_Email int, Active_Mobile int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# LoadPoints
def createLoadPointsPostgreSQL():
    tablename = "loadpoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Currency_Code varchar, Value float8, Date_Day int, Date_Month int, Date_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# RedeemPoints
def createRedeemPointsPostgreSQL():
    tablename = "redeempoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# OutAddedPoints
def createoutAddedPointsPostgreSQL():
    tablename = "outaddedpoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Points float8, Currency_Code	varchar, Value float8, Points_per_Currency float8, Date_Day	int, Date_Month	int, Date_Year int, Expiry_Date_Day	int, Expiry_Date_Month int, Expiry_Date_Year int, Added_ID int8 PRIMARY KEY, Batch_Day int, Batch_Month int, Batch_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# OutExpiredPoints
def createoutExpiredPointsPostgreSQL():
    tablename = "outexpiredpoints"
    fieldnames = "Corp_Code	varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Expiry_Date_Day int, Expiry_Date_Month int, Expiry_Date_Year int, Expiry_ID int8 PRIMARY KEY, Batch_Day int, Batch_Month int, Batch_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# OutRedeemApproved
def createoutRedeemApprovedPostgreSQL():   
    tablename = "outredeemapproved"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Redeem_Currency_Code varchar, Redeem_Value float8, Approval_ID int8 PRIMARY KEY, Batch_Day int, Batch_Month int, Batch_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

# OutRedeemRejected
def createoutRedeemRejectedPostgreSQL():
    tablename = "outredeemrejected"
    fieldnames = "Corp_Code varchar, Program_Code varchar, User_Code int8, Points float8, Date_Day int, Date_Month int, Date_Year int, Redeem_Currency_Code varchar, Redeem_Value float8, Rejected_ID int8 PRIMARY KEY, Batch_Day int, Batch_Month int, Batch_Year int, Tax_ID varchar, External_Account_Code varchar"
    SQLCommand = "CREATE TABLE IF NOT EXISTS poorman." + tablename + " (" + fieldnames + ");"
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " created")

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################

createSchemaPostgreSQL()
cleanUpExistingPostgreSQL()

# Export CSV files to PostgreSQL tables
createCorpNamesPostgreSQL()
createCountryCodesPostgreSQL()
createCurrencyNamesPostgreSQL()
createProductNamesPostgreSQL()
createProgramNamesPostgreSQL()
createProgramSetupPostgreSQL()
createProgramAttribPostgreSQL()
createUserProfilePostgreSQL()
createPointsBankPostgreSQL()
createAddedPointsPostgreSQL()
createExpiredPointsPostgreSQL()
createRedeemApprovedPostgreSQL()
createRedeemRejectedPostgreSQL()

createListRedeemablePostgreSQL()
createRedeemableSentPostgreSQL()
createWelcomeUserQueuePostgreSQL()
createAddUserPostgreSQL()
createUpdateUserPostgreSQL()
createLoadPointsPostgreSQL()
createRedeemPointsPostgreSQL()

createoutAddedPointsPostgreSQL()
createoutExpiredPointsPostgreSQL()
createoutRedeemApprovedPostgreSQL()
createoutRedeemRejectedPostgreSQL()