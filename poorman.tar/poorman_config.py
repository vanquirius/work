# Poorman's Payback
# Marcelo Ambrosio de Góes
# Configuration file

# Edit this according to your system and your needs

# Directories
workingDirectory = "D:\\Users\\Marcelo\\Documents\\Code\\Poorman Payback\\Poorman Payback\\Working\\"
incomingbatchFileDirectory = workingDirectory + "Incoming\\"
outgoingbatchFileDirectory = workingDirectory + "Outgoing\\"

# External database support
# Note that enabling postgreSQL disables support for internal .csv files except for incoming and outgoing files
postgreSQLSupport = 1
postgreSQLServer = "hansken.db.elephantsql.com"
postgreSQLPort = "5432"
postgreSQLDB = "jtlhlnnq"
postgreSQLUsername = "jtlhlnnq"
postgreSQLPassword = "A2lbggvM-LHgZ8cbzuEJXVQ1RyhTE5fX"

# Points engine settings (used for rounding)
currencyDecimals = 2
pointsDecimals = 2 # this is used internally in calculations and storing values
displayPointsDecimals = 0 # this is what is displayed to the end user

# Verbose prompt (1 = on, 0 = off)
verbose = 1

# Outgoing batch files
# The variable belows sets the cut date - please mark as "day", "month", "year" or "all"
# day means all events that took place yesterday
# month and year are month to date and year to date, including events from today
# All brings the entire history in the database
outgoingBatchCut = "all"

# API server settings
apiToken = "bx0sGjy1Pb5vWe2Ik0UoQh1bzQT9pxk1"
apiPort = "5000"
redeemPort = "5001"
domainLink = "http://127.0.0.1"

# Event broker settings
# Allow to send e-mails (1 = on)
allowSendMail = 1
sendWelcomeEmail = 1
# Allow to send SMS's (1 = on)
allowSendSMS = 1
sendWelcomeSMS = 0
# Time trigger - recommended to disable at night time not to inconvenience users with messages (military hours); (1 = on)
timeAllowed22to8 = 1 # recommended 1 = on
timeAllowed9to21 = 1 # recommended 0 = off
# Token for SMS broker
smsToken = "8a936508-0cdd-4d87-887b-940d2b50ab02"
# Test number for SMS
smsTestAreaCode = "11"
smsTestPhoneNumber = "996320490"

# E-Mail server settings
reportsEmail = "poormanpayback@gmail.com"
userEmail = "poormanpayback@gmail.com"
userPassword = "poorman123!"
smptServer = "smtp.gmail.com"
smptPort = 587
mailWait = 5 # wait time in seconds before sending another e-mail

# Test kit settings
testServerIP = "127.0.0.1"
testSampleSize = 10000

# Disaster recovery integration
# Please select "off", "main" or "dr"
# off runs as a standalone installation
# main turns on data replication to disaster recovery node
# dr works as cold disaster recovery; turn switch to main to takeover
disasterRecoveryStatus = "off"