# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-14
# Points Engine - csv version

from poorman_back_end import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# Import routine

# Program Setup - ProgramSetup.csv - Configuration of loyalty programs
def programSetupLoad():
    try:
        cols = ["Corp_Code","Country_Code","Program_Code","Product_Code","Currency_Code","Points_per_Currency","Expiration_Days"]
        programSetupDF = pandas.read_csv('ProgramSetup.csv', usecols=cols, index_col=False, dtype={'Corp_Code':'object', 'Program_Code':'object', 'Product_Code':'object'})
        cols = ["Corp_Code","Corp_Name"]
        corpNamesDF = pandas.read_csv('CorpNames.csv', usecols=cols, index_col=False, dtype={'Corp_Code':'object'})
        cols = ["Country_Code","Country_Name"]
        countryCodesDF = pandas.read_csv('CountryCodes.csv', usecols=cols, index_col=False)
        cols = ["Currency_Code","Currency_Name"]
        currencyNamesDF = pandas.read_csv('CurrencyNames.csv', usecols=cols, index_col=False, dtype={'Product_Code':'object'})
        cols = ["Product_Code","Product_Name"]
        productNamesDF = pandas.read_csv('ProductNames.csv', usecols=cols, index_col=False, dtype={'Program_Code':'object'})
        cols = ["Program_Code","Program_Name"]
        programNamesDF = pandas.read_csv('ProgramNames.csv', usecols=cols, index_col=False, dtype={'Program_Code':'object'})
        cols = ["Program_Code","Active_Program","Redeem_Currency_Code","Currency_per_Points","Redeem_Min_points","Renew_Expiry_On_Purchase"]
        programAttribDF = pandas.read_csv('ProgramAttrib.csv', usecols=cols, index_col=False, dtype={'Program_Code':'object'})

        # throw warnings if files are empty
        if programSetupDF.empty == True:
            blankFile()
        if corpNamesDF.empty == True:
            blankFile()
        if countryCodesDF.empty == True:
            blankFile()
        if currencyNamesDF.empty == True:
            blankFile()
        if productNamesDF.empty == True:
            blankFile()
        if programNamesDF.empty == True:
            blankFile()
        if programAttribDF.empty == True:
            blankFile()

        # check that program codes are unique
        programCodeList = programAttribDF['Program_Code']
        if programCodeList.is_unique:
            checkOk()
        else:
            notUniqueError()
            # remove duplicates - will keep last entry
            programAttribDF = programAttribDF.drop_duplicates(subset=['Program_Code'], keep='last')

        # enforce boolean attributes
        programAttribDF['Active_Program'][(programAttribDF['Active_Program'] != 1)] = 0
        programAttribDF['Renew_Expiry_On_Purchase'][(programAttribDF['Renew_Expiry_On_Purchase'] != 1)] = 0

        loadedProgramSetup()
    except:
        failedProgramSetup()
        errorTerminationLog()
        raise
    return programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF

# User Profile - UserProfile.csv - Data on users of loyalty programs
def userProfileLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        userProfileDF = pandas.read_csv('UserProfile.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'User_Mobile_Country_Code':'object', 'User_Mobile_Area_Code':'object', 'User_Mobile_Phone_Number':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})
        
        # throw warnings if files are empty
        if userProfileDF.empty == True:
            blankFile()

        # check that user codes and external accounts are unique
        userCodeList = userProfileDF['User_Code']
        if userCodeList.is_unique:
            checkOk()
        else:
            notUniqueError()
            # remove duplicates - will keep last entry
            userProfileDF = userProfileDF.drop_duplicates(subset=['User_Code'], keep='last')
        externalAccountList = userProfileDF['External_Account_Code']
        if externalAccountList.is_unique:
            checkOk()
        else:
            notUniqueError()

        # enforce boolean attributes
        userProfileDF['Active_User'][(userProfileDF['Active_User'] != 1)] = 0
        userProfileDF['Active_Email'][(userProfileDF['Active_Email'] != 1)] = 0
        userProfileDF['Active_Mobile'][(userProfileDF['Active_Mobile'] != 1)] = 0

        # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
        userProfileDF['Active_Email'][(userProfileDF['User_Email'].notnull() == False)] = 0
        userProfileDF['Active_Mobile'][(userProfileDF['User_Mobile_Area_Code'].notnull() == False)] = 0
        userProfileDF['Active_Mobile'][(userProfileDF['User_Mobile_Phone_Number'].notnull() == False)] = 0

        loadedUserProfile()
    except:
        failedUserProfile()
        errorTerminationLog()
        raise
    return userProfileDF

# Wrapper - external accounts to user code
def wrapperExternalAccount(userProfileDF):
    try:
        wrapperExternalAccountDF = userProfileDF[['User_Code', 'External_Account_Code', 'Tax_ID']]
        wrapperExternalAccountDF = wrapperExternalAccountDF.drop_duplicates(subset=['External_Account_Code'], keep='last')
        wrapperExternalAccountDF.rename(columns={'User_Code': 'User_Code2'}, inplace=True)
        wrapperExternalAccountDF = wrapperExternalAccountDF.astype({'User_Code2': 'object'})
        wrapperExternalAccountDF = wrapperExternalAccountDF[wrapperExternalAccountDF['External_Account_Code'].notna()]

        wrapperTaxIDDF = userProfileDF[['User_Code', 'External_Account_Code', 'Tax_ID']]
        wrapperTaxIDDF = wrapperTaxIDDF.drop_duplicates(subset=['Tax_ID'], keep='last')
        wrapperTaxIDDF.rename(columns={'User_Code': 'User_Code3'}, inplace=True)
        wrapperTaxIDDF = wrapperTaxIDDF.astype({'User_Code3': 'object'})
        wrapperTaxIDDF = wrapperTaxIDDF[wrapperTaxIDDF['Tax_ID'].notna()]

        sucessWrapperExternalAccount()
    except:
        failedWrapperExternalAccount()
        errorTerminationLog()
        raise
    return wrapperExternalAccountDF, wrapperTaxIDDF

# Welcome User - WelcomeUserQueue.csv - queue of users to get welcome
def welcomeUserQueue():
    cols = ["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        welcomeUserQueueDF = pandas.read_csv('WelcomeUserQueue.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})
        successWelcomeQueue()
    except:
        failWelcomeQueue()
        errorTerminationLog()
        raise
    return welcomeUserQueueDF

# Add User - AddUserProfile.csv - Batch file to add new user
def addUser():
    cols = ["Corp_Code","Program_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        addUserDF = pandas.read_csv(incomingbatchFileDirectory + 'AddUserProfile.csv', usecols=cols, index_col=False, dtype={'User_Mobile_Country_Code':'object', 'User_Mobile_Area_Code':'object', 'User_Mobile_Phone_Number':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})        
        loadedAddUser()
    except:
        failedAddUser()
        errorTerminationLog()
        raise
    return addUserDF

# Update User - UpdateUserProfile.csv - Batch file to update existing users
def updateUser():
    cols = ["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        updateUserDF = pandas.read_csv(incomingbatchFileDirectory + 'UpdateUserProfile.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'User_Mobile_Country_Code':'object', 'User_Mobile_Area_Code':'object', 'User_Mobile_Phone_Number':'object','External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})  
        loadedUpdateUser()
    except:
        failedUpdateUser()
        errorTerminationLog()
        raise
    return updateUserDF

# Points Bank - PointsBank.csv - Current status of points
def pointsBankLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Expiry_Date_Day","Expiry_Date_Month","Expiry_Date_Year"]
    try:
        pointsBankDF = pandas.read_csv('PointsBank.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object', 'Expiry_Date_Day':'object', 'Expiry_Date_Month':'object','Expiry_Date_Year':'object'})
        
        # throw warnings if files are empty
        if pointsBankDF.empty == True:
            blankFile()
        
        # remove zero and negative points
        pointsBankDF = pointsBankDF.loc[pointsBankDF['Points'] > 0]

        # round points
        pointsBankDF = pointsBankDF.round({'Points': pointsDecimals})
        
        loadedPointsBank()
    except:
        failedPointsBank()
        errorTerminationLog()
        raise
    return pointsBankDF 

# Load Points - LoadPoints.csv - Batch file to load new points
def loadPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF):
    cols = ["Corp_Code","Program_Code","User_Code","Currency_Code","Value","Date_Day","Date_Month","Date_Year","Tax_ID","External_Account_Code"]
    try:
        loadPointsDF = pandas.read_csv(incomingbatchFileDirectory + 'LoadPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        
        # round currency
        loadPointsDF = loadPointsDF.round({'Value': currencyDecimals})

        # remove zero and negative values
        loadPointsDF = loadPointsDF.loc[loadPointsDF['Value'] > 0]
        
        # External Account to User ID conversion
        loadPointsDF = loadPointsDF.merge(wrapperExternalAccountDF[['External_Account_Code','User_Code2']], how='left')
        loadPointsDF = loadPointsDF.merge(wrapperTaxIDDF[['Tax_ID','User_Code3']], how='left')     
        loadPointsDF['User_Code'][(loadPointsDF['User_Code'].notnull() == False)] = loadPointsDF['User_Code2']
        loadPointsDF['User_Code'][(loadPointsDF['User_Code'].notnull() == False)] = loadPointsDF['User_Code3']
        del loadPointsDF['User_Code2']
        del loadPointsDF['User_Code3']

        # remove entries with no user accounts
        loadPointsDF['User_Code'].replace('', numpy.nan, inplace=True)
        loadPointsDF.dropna(subset=['User_Code'], inplace=True)   

        loadedLoadPoints()
    except:
        failedLoadPoints()
        errorTerminationLog()
        raise
    return loadPointsDF

# Redeem Points - RedeemPoints.csv - Batch file to redeem points
def redeemPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF):
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Tax_ID","External_Account_Code"]
    try:
        redeemPointsDF = pandas.read_csv(incomingbatchFileDirectory + 'RedeemPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})

        # round points
        redeemPointsDF = redeemPointsDF.round({'Points': pointsDecimals})

        # External Account to User ID conversion
        redeemPointsDF = redeemPointsDF.merge(wrapperExternalAccountDF[['External_Account_Code','User_Code2']], how='left')
        redeemPointsDF = redeemPointsDF.merge(wrapperTaxIDDF[['Tax_ID','User_Code3']], how='left')
        redeemPointsDF['User_Code'][(redeemPointsDF['User_Code'].notnull() == False)] = redeemPointsDF['User_Code2']
        redeemPointsDF['User_Code'][(redeemPointsDF['User_Code'].notnull() == False)] = redeemPointsDF['User_Code3']
        del redeemPointsDF['User_Code2']
        del redeemPointsDF['User_Code3']

        # remove entries with no user accounts
        redeemPointsDF['User_Code'].replace('', numpy.nan, inplace=True)
        redeemPointsDF.dropna(subset=['User_Code'], inplace=True)   
        
        loadedRedeemPoints()
    except:
        failedRedeemPoints()
        errorTerminationLog()
        raise
    return redeemPointsDF

# Expired Points - ExpiredPoints.csv - Control points moved to expired
def expiredPointsLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Expiry_Date_Day","Expiry_Date_Month","Expiry_Date_Year","Expiry_ID"]
    try:
        expiredPointsDF = pandas.read_csv('ExpiredPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        # round points
        expiredPointsDF = expiredPointsDF.round({'Points': pointsDecimals})

        loadedExpiredPoints()
    except:
        failedExpiredPoints()
        errorTerminationLog()
        raise
    return expiredPointsDF

# Added Points - AddedPoints.csv - Control points added to points bank
def addedPointsLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Currency_Code","Value","Points_per_Currency","Date_Day","Date_Month","Date_Year","Expiry_Date_Day","Expiry_Date_Month","Expiry_Date_Year","Added_ID"]
    try:
        addedPointsDF = pandas.read_csv('AddedPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object', 'Expiry_Date_Day':'object', 'Expiry_Date_Month':'object','Expiry_Date_Year':'object'})
        # round points
        addedPointsDF = addedPointsDF.round({'Points': pointsDecimals})
        loadedAddedPoints()
    except:
        failedAddedPoints()
        errorTerminationLog()
        raise
    return addedPointsDF

# Approved redemption requests - RedeemApproved.csv - Control requests that were approved
def redeemApprovedLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Redeem_Currency_Code","Redeem_Value","Approval_ID"]
    try:
        redeemApprovedDF = pandas.read_csv('RedeemApproved.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        # round currency
        redeemApprovedDF = redeemApprovedDF.round({'Redeem_Value': currencyDecimals})
        # round points
        redeemApprovedDF = redeemApprovedDF.round({'Points': pointsDecimals})
        loadedRedeemApproved()
    except:
        failedRedeemApproved()
        errorTerminationLog()
        raise
    return redeemApprovedDF

# Rejected redemption requests - RedeemRejected.csv - Control requests that were rejected
def redeemRejectedLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Redeem_Currency_Code","Redeem_Value","Rejected_ID"]
    try:
        redeemRejectedDF = pandas.read_csv('RedeemRejected.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        # round currency
        redeemRejectedDF = redeemRejectedDF.round({'Redeem_Value': currencyDecimals})
        # round points
        redeemRejectedDF = redeemRejectedDF.round({'Points': pointsDecimals})
        loadedRedeemRejected()
    except:
        failedRedeemRejected()
        errorTerminationLog()
        raise
    return redeemRejectedDF

# Load list redeemable file
def loadListRedeemable():
    try:
        # load list of redeemable users
        cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Redeem_Currency_Code","Redeem_Value"]
        listRedeemableDF = pandas.read_csv('ListRedeemable.csv', usecols=cols, index_col=False, dtype={'Corp_Code':'object', 'Program_Code':'object', 'User_Code': 'object'})        
        # round currency
        listRedeemableDF = listRedeemableDF.round({'Redeem_Value': currencyDecimals})
        # round points
        listRedeemableDF = listRedeemableDF.round({'Points': pointsDecimals})

        cols = ["Corp_Code","Program_Code","User_Code","Points","Redeem_Currency_Code","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Redeem_Value","Date_Day","Date_Month","Date_Year","Token_Code","Token_Sent","Points2","Currency_Name"]        
        redeemableSentDF = pandas.read_csv('ReedemableSent.csv', usecols=cols, index_col=False, dtype={'Corp_Code':'object', 'Program_Code':'object', 'User_Code': 'object', 'Token_Sent':'int64'})        
        # round currency
        redeemableSentDF = redeemableSentDF.round({'Redeem_Value': currencyDecimals})
        # round points
        redeemableSentDF = redeemableSentDF.round({'Points': pointsDecimals})

        loadedListRedeemable()
    except:
        failedListRedeemable()
        errorTerminationLog()
        raise
    return listRedeemableDF, redeemableSentDF

# Processing routine

# IN ROADMAP
# WRITE ROUTINE TO ACTIVATE/DEACTIVATE PROGRAMS
# WRITE ROUTINE TO UPDATE PROGRAMS

# Merge program setup with its attributes
def programSetupMerge(programSetupDF, programAttribDF):
    try:
        programSetupAttributesDF = programSetupDF.merge(programAttribDF[['Program_Code', 'Active_Program', 'Redeem_Currency_Code', 'Currency_per_Points', 'Redeem_Min_points', 'Renew_Expiry_On_Purchase']], how='left')
        successMergeProgramSetup()
    except:
        failMergeProgramSetup()
        errorTerminationLog()
        raise
    return programSetupAttributesDF

# Add new users based on AddUserProfile.csv batch file
def addUserProfile(userProfileDF, addUserDF, welcomeUserQueueDF):
    try:
        if addUserDF.empty == False:

            # enforce boolean attributes
            addUserDF['Active_User'][(addUserDF['Active_User'] != 1)] = 0
            addUserDF['Active_Email'][(addUserDF['Active_Email'] != 1)] = 0
            addUserDF['Active_Mobile'][(addUserDF['Active_Mobile'] != 1)] = 0

            # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
            addUserDF['Active_Email'][(addUserDF['User_Email'].notnull() == False)] = 0
            addUserDF['Active_Mobile'][(addUserDF['User_Mobile_Area_Code'].notnull() == False)] = 0
            addUserDF['Active_Mobile'][(addUserDF['User_Mobile_Phone_Number'].notnull() == False)] = 0

            # attribute new User Code
            UserCodeList = userProfileDF['User_Code'].astype(int)
            currentUserCode = UserCodeList.max() + 1
            addUserDF['User_Code'] = numpy.arange(len(addUserDF)) + currentUserCode

            # get fields to match User Profile
            addUserDF = addUserDF[["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]]

            # join new users to existing users
            userProfileDF = userProfileDF.append(addUserDF)

            # generate welcome queue
            if sendWelcomeEmail == 1 | sendWelcomeSMS == 1:
                welcomeUserQueueDF = welcomeUserQueueDF.append(addUserDF)
            else:
                welcomeUserQueueDF = pandas.DataFrame(columns=welcomeUserQueueDF.columns)
            
            # empty out add users table
            addUserDF = pandas.DataFrame(columns=addUserDF.columns)
            
        successAddUserProfile()
    except:
        failAddUserProfile()
        errorTerminationLog()
        raise
    return userProfileDF, addUserDF, welcomeUserQueueDF

# Update existing users based on UpdateUserProfile.csv batch file
def updateUserProfile(userProfileDF, updateUserDF, wrapperExternalAccountDF, wrapperTaxIDDF):
    try:
        if updateUserDF.empty == False:
           
            # enforce boolean attributes
            updateUserDF['Active_User'][(updateUserDF['Active_User'] != 1)] = 0
            updateUserDF['Active_Email'][(updateUserDF['Active_Email'] != 1)] = 0
            updateUserDF['Active_Mobile'][(updateUserDF['Active_Mobile'] != 1)] = 0

            # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
            updateUserDF['Active_Email'][(updateUserDF['User_Email'].notnull() == False)] = 0
            updateUserDF['Active_Mobile'][(updateUserDF['User_Mobile_Area_Code'].notnull() == False)] = 0
            updateUserDF['Active_Mobile'][(updateUserDF['User_Mobile_Phone_Number'].notnull() == False)] = 0

            # External Account to User ID conversion
            updateUserDF = updateUserDF.merge(wrapperExternalAccountDF[['External_Account_Code','User_Code2']], how='left')
            updateUserDF = updateUserDF.merge(wrapperTaxIDDF[['Tax_ID','User_Code3']], how='left')
            updateUserDF['User_Code'][(updateUserDF['User_Code'].notnull() == False)] = updateUserDF['User_Code2']
            updateUserDF['User_Code'][(updateUserDF['User_Code'].notnull() == False)] = updateUserDF['User_Code3']
            del updateUserDF['User_Code2']
            del updateUserDF['User_Code3']

            # remove entries with no user accounts
            updateUserDF['User_Code'].replace('', numpy.nan, inplace=True)
            updateUserDF.dropna(subset=['User_Code'], inplace=True)

            # check if user really exists
            updateUserDF.rename(columns={'Active_User': 'Active_User2'}, inplace=True)
            updateUserDF = updateUserDF.merge(userProfileDF[['User_Code','Active_User']], how='left')

            # remove users that do not already exist
            updateUserDF['Active_User'].replace('', numpy.nan, inplace=True)
            updateUserDF.dropna(subset=['Active_User'], inplace=True)
            del updateUserDF['Active_User']
            updateUserDF.rename(columns={'Active_User2': 'Active_User'}, inplace=True)

            # get fields to match User Profile
            updateUserDF = updateUserDF[["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]]

            # join updated list with user profile
            userProfileDF = userProfileDF.append(updateUserDF)

            # remove original entry from user profile
            userProfileDF = userProfileDF.drop_duplicates(subset=['User_Code'], keep='last')

            # empty out update users table
            updateUserDF = pandas.DataFrame(columns=updateUserDF.columns)
            
        successUpdateUserProfile()
    except:
        failUpdateUserProfile()
        errorTerminationLog()
        raise
    return userProfileDF, updateUserDF

# Calculate points to be added based on LoadPoints.csv batch file
def addPointsBank(loadPointsDF, programSetupAttributesDF, pointsBankDF, addedPointsDF, programAttribDF, userProfileDF):
    try:
        if loadPointsDF.empty == False:           
            # merge batch file to load points with business rules
            loadPointsDFStep1 = loadPointsDF.merge(programSetupAttributesDF[['Corp_Code','Program_Code','Currency_Code','Active_Program','Points_per_Currency','Expiration_Days']], how='left')

            # merge batch file with user table
            loadPointsDFStep1 = loadPointsDFStep1.merge(userProfileDF[['User_Code','Active_User']], how='left')

            # calculate points for active programs; inactive programs will come zeroed out
            loadPointsDFStep1['Points'] = loadPointsDFStep1['Points_per_Currency'] * loadPointsDFStep1['Value'] * loadPointsDFStep1['Active_Program'] * loadPointsDFStep1['Active_User']
            # round points
            loadPointsDFStep1 = loadPointsDFStep1.round({'Points': pointsDecimals})
        
            # calculate expiration date based on program setup
            loadPointsDFStep1['Date_Datetime'] = pandas.to_datetime(loadPointsDFStep1["Date_Year"].astype(str) + "-" + loadPointsDFStep1["Date_Month"].astype(str) + "-" + loadPointsDFStep1["Date_Day"].astype(str))
            loadPointsDFStep1['Expiry_Datetime'] = loadPointsDFStep1['Date_Datetime'] + pandas.to_timedelta(loadPointsDFStep1['Expiration_Days'], unit="D")
            loadPointsDFStep1['Expiry_Date_Day'] = pandas.DatetimeIndex(loadPointsDFStep1['Expiry_Datetime']).day
            loadPointsDFStep1['Expiry_Date_Month'] = pandas.DatetimeIndex(loadPointsDFStep1['Expiry_Datetime']).month
            loadPointsDFStep1['Expiry_Date_Year'] = pandas.DatetimeIndex(loadPointsDFStep1['Expiry_Datetime']).year

            # assign Added ID to points to be added
            AddedIDList = addedPointsDF['Added_ID']
            currentAddedID = AddedIDList.max() + 1
            loadPointsDFStep1['Added_ID'] = numpy.arange(len(loadPointsDFStep1)) + currentAddedID
        
            # get fields to match points bank
            loadPointsDFStep2 = loadPointsDFStep1[['Corp_Code','Program_Code','User_Code','Points','Date_Day','Date_Month','Date_Year','Expiry_Date_Day','Expiry_Date_Month','Expiry_Date_Year']]

            # join with points bank
            pointsBankDFStep1 = pointsBankDF.append(loadPointsDFStep2)

            # get fields to match added points
            loadPointsDFStep3 = loadPointsDFStep1[['Corp_Code','Program_Code','User_Code','Points','Currency_Code','Value','Points_per_Currency','Date_Day','Date_Month','Date_Year','Expiry_Date_Day','Expiry_Date_Month','Expiry_Date_Year','Added_ID']]

            # join with added points
            addedPointsDFStep1 = addedPointsDF.append(loadPointsDFStep3)

            # renew expiration date if renew condition on use is on
            pointsBankDFStep1['Expiry_Datetime'] = pandas.to_datetime(pointsBankDFStep1["Expiry_Date_Year"].astype(str) + "-" + pointsBankDFStep1["Expiry_Date_Month"].astype(str) + "-" + pointsBankDFStep1["Expiry_Date_Day"].astype(str))
            pointsBankDFStep1['Expiry_Datetime_Max'] = pointsBankDFStep1.groupby(['User_Code'])['Expiry_Datetime'].transform(max)
            pointsBankDFStep1 = pointsBankDFStep1.merge(programAttribDF[['Program_Code','Renew_Expiry_On_Purchase']], how='left')
            pointsBankDFStep1['Expiry_Date_Day_Max'] = pandas.DatetimeIndex(pointsBankDFStep1['Expiry_Datetime_Max']).day
            pointsBankDFStep1['Expiry_Date_Month_Max'] = pandas.DatetimeIndex(pointsBankDFStep1['Expiry_Datetime_Max']).month
            pointsBankDFStep1['Expiry_Date_Year_Max'] = pandas.DatetimeIndex(pointsBankDFStep1['Expiry_Datetime_Max']).year
            pointsBankDFStep1['Expiry_Date_Day'][(pointsBankDFStep1['Renew_Expiry_On_Purchase'] == 1)] = pointsBankDFStep1['Expiry_Date_Day_Max']
            pointsBankDFStep1['Expiry_Date_Month'][(pointsBankDFStep1['Renew_Expiry_On_Purchase'] == 1)] = pointsBankDFStep1['Expiry_Date_Month_Max']
            pointsBankDFStep1['Expiry_Date_Year'][(pointsBankDFStep1['Renew_Expiry_On_Purchase'] == 1)] = pointsBankDFStep1['Expiry_Date_Year_Max']
            del pointsBankDFStep1['Expiry_Datetime']
            del pointsBankDFStep1['Expiry_Datetime_Max']
            del pointsBankDFStep1['Expiry_Date_Day_Max']
            del pointsBankDFStep1['Expiry_Date_Month_Max']
            del pointsBankDFStep1['Expiry_Date_Year_Max']

            # clean-up entries that provided zero points
            pointsBankDFStep1 = pointsBankDFStep1.loc[pointsBankDFStep1['Points'] > 0]

            # empty load points
            loadPointsDFStep1 = pandas.DataFrame(columns=loadPointsDF.columns)
        
        else:
            pointsBankDFStep1 = pointsBankDF
            addedPointsDFStep1 = addedPointsDF
            loadPointsDFStep1 = loadPointsDF

        successAddPointsBank()
    except:
        failAddPointsBank()
        errorTerminationLog()
        raise
    return pointsBankDFStep1, addedPointsDFStep1, loadPointsDFStep1

# Remove expired points from points bank
def removeExpiredPoints(pointsBankDF,expiredPointsDF):
    try:
        if pointsBankDF.empty == False:
            # tag expired points
            pointsBankDFStep1 = pointsBankDF
            pointsBankDFStep1['Expiry_Datetime'] = pandas.to_datetime(pointsBankDFStep1["Expiry_Date_Year"].astype(str) + "-" + pointsBankDFStep1["Expiry_Date_Month"].astype(str) + "-" + pointsBankDFStep1["Expiry_Date_Day"].astype(str))
            pointsBankDFStep1.loc[pointsBankDFStep1['Expiry_Datetime'] <= datetime.now(), 'Expired'] = 1
            pointsBankDFStep1.loc[pointsBankDFStep1['Expiry_Datetime'] > datetime.now(), 'Expired'] = 0

            # break into not expired and newly expired
            pointsBankDFStep1_notexpired = pointsBankDFStep1[pointsBankDFStep1['Expired'] == 0]
            del pointsBankDFStep1_notexpired['Expiry_Datetime']
            del pointsBankDFStep1_notexpired['Expired']
            pointsBankDFStep1_expired = pointsBankDFStep1[pointsBankDFStep1['Expired'] == 1] 
            del pointsBankDFStep1_expired['Expiry_Datetime']
            del pointsBankDFStep1_expired['Expired']

            # assign Expiry ID to newly expired points
            expiryIDList = expiredPointsDF['Expiry_ID']
            currentExpiryID = expiryIDList.max() + 1
            pointsBankDFStep1_expired['Expiry_ID'] = numpy.arange(len(pointsBankDFStep1_expired)) + currentExpiryID

            # join previously expired points with newly expired points
            pointsBankDFStep2_expired = expiredPointsDF.append(pointsBankDFStep1_expired)
        else:
            pointsBankDFStep1_notexpired = pointsBankDF
            pointsBankDFStep2_expired = expiredPointsDF
                
        successRemoveExpiredPoints()
    except:
        failRemoveExpiredPoints()
        errorTerminationLog()
        raise
    return pointsBankDFStep1_notexpired, pointsBankDFStep2_expired

# Attemp to redeem points - may be approved or rejected
def redeemPoints(redeemPointsDF,pointsBankDF,redeemApprovedDF,redeemRejectedDF,programSetupAttributesDF,userProfileDF):
    try:
        if redeemPointsDF.empty == False:
            # consolidate redemption requests per user
            redeemPointsDFStep1 = redeemPointsDF.groupby(['Corp_Code','Program_Code','User_Code'], as_index=False).sum()
            redeemPointsDFStep1.rename(columns={'Points': 'Redeem_Points'}, inplace=True)

            # consolidate points bank per user
            pointsBankDFStep1 = pointsBankDF
            pointsBankDFStep1 = pointsBankDFStep1.groupby(['Corp_Code','Program_Code','User_Code'], as_index=False).sum()
            pointsBankDFStep1.rename(columns={'Points': 'Available_Points'}, inplace=True)

            # join points information from points bank
            redeemPointsDFStep1.set_index(['Corp_Code','Program_Code','User_Code'])
            pointsBankDFStep1.set_index(['Corp_Code','Program_Code','User_Code'])
            redeemPointsDFStep2 = redeemPointsDFStep1.merge(pointsBankDFStep1[['Corp_Code','Program_Code','User_Code','Available_Points']], how='left')

            # get active program and active user
            redeemPointsDFStep2 = redeemPointsDFStep2.merge(programSetupAttributesDF[['Corp_Code','Program_Code','Active_Program','Redeem_Currency_Code','Currency_per_Points','Redeem_Min_points']], how='left')
            redeemPointsDFStep2 = redeemPointsDFStep2.drop_duplicates()
            redeemPointsDFStep2 = redeemPointsDFStep2.merge(userProfileDF[['User_Code','Active_User']], how='left')
      
            # approve or reject redemption requests
            redeemPointsDFStep2['Points_Ratio'] = redeemPointsDFStep2['Redeem_Points'].astype(float) / redeemPointsDFStep2['Available_Points'].astype(float)
            redeemPointsDFStep2['Redeem_Approve'] = 0
            redeemPointsDFStep2['Redeem_Approve'][(redeemPointsDFStep2['Points_Ratio'] > 0) & (redeemPointsDFStep2['Points_Ratio'] <= 1) & (redeemPointsDFStep2['Active_Program'] == 1) & (redeemPointsDFStep2['Active_User'] == 1) & (redeemPointsDFStep2['Redeem_Points'] >= redeemPointsDFStep2['Redeem_Min_points'])] = 1
            redeemPointsDFStep2['Redeem_Value'] = redeemPointsDFStep2['Redeem_Points'].astype(float) * redeemPointsDFStep2['Currency_per_Points'].astype(float)
            # round currency
            redeemPointsDFStep2 = redeemPointsDFStep2.round({'Redeem_Value': currencyDecimals})

            # prepare table format
            redeemPointsDFStep3 = redeemPointsDFStep2
            del redeemPointsDFStep3['Available_Points']
            del redeemPointsDFStep3['Active_Program']
            del redeemPointsDFStep3['Active_User']
            del redeemPointsDFStep3['Currency_per_Points']
            del redeemPointsDFStep3['Redeem_Min_points']
            redeemPointsDFStep3.rename(columns={'Redeem_Points': 'Points'}, inplace=True)
            redeemPointsDFStep3['Now_Datetime'] = datetime.now()
            redeemPointsDFStep3['Date_Day'] = pandas.DatetimeIndex(redeemPointsDFStep3['Now_Datetime']).day
            redeemPointsDFStep3['Date_Month'] = pandas.DatetimeIndex(redeemPointsDFStep3['Now_Datetime']).month
            redeemPointsDFStep3['Date_Year'] = pandas.DatetimeIndex(redeemPointsDFStep3['Now_Datetime']).year
            del redeemPointsDFStep3['Now_Datetime']
            redeemPointsDFStep3 = redeemPointsDFStep3.reset_index(drop=True)

            # break into approved and rejected
            redeemPointsDFStep3_approved = redeemPointsDFStep3[redeemPointsDFStep3['Redeem_Approve'] == 1]
            del redeemPointsDFStep3_approved['Redeem_Approve']
            redeemPointsDFStep3_rejected = redeemPointsDFStep3[redeemPointsDFStep3['Redeem_Approve'] == 0]
            del redeemPointsDFStep3_rejected['Redeem_Approve']

            # move approved requests to approved control
            approvalIDList = redeemApprovedDF['Approval_ID']
            currentApprovalID = approvalIDList.max() + 1
            redeemPointsDFStep3_approved['Approval_ID'] = numpy.arange(len(redeemPointsDFStep3_approved)) + currentApprovalID
            redeemApprovedDFStep1 = redeemApprovedDF.append(redeemPointsDFStep3_approved)
            del redeemApprovedDFStep1['Points_Ratio']

            # move rejected to rejected control
            rejectedIDList = redeemRejectedDF['Rejected_ID']
            currentRejectedID = rejectedIDList.max() + 1
            redeemPointsDFStep3_rejected['Rejected_ID'] = numpy.arange(len(redeemPointsDFStep3_rejected)) + currentRejectedID
            redeemRejectedDFStep1 = redeemRejectedDF.append(redeemPointsDFStep3_rejected)
            del redeemRejectedDFStep1['Points_Ratio']

            # deduct points from points bank
            pointsBankDFStep2 = pointsBankDF
            pointsBankDFStep2 = pointsBankDFStep2.merge(redeemPointsDFStep3_approved[['User_Code','Points_Ratio']], how='left')
            pointsBankDFStep2 = pointsBankDFStep2.fillna(0)
            pointsBankDFStep2['Points_After_Redeem'] = pointsBankDFStep2['Points'] * (1 - pointsBankDFStep2['Points_Ratio'])
            del pointsBankDFStep2['Points']
            del pointsBankDFStep2['Points_Ratio']
            pointsBankDFStep2.rename(columns={'Points_After_Redeem': 'Points'}, inplace=True)
            # round points
            pointsBankDFStep2 = pointsBankDFStep2.round({'Points': pointsDecimals})
            pointsBankDFStep2 = pointsBankDFStep2[['Corp_Code','Program_Code','User_Code','Points','Date_Day','Date_Month','Date_Year','Expiry_Date_Day','Expiry_Date_Month','Expiry_Date_Year']]

            # empty redemption request
            redeemPointsDFStep4 = redeemPointsDF
            redeemPointsDFStep4 = pandas.DataFrame(columns=redeemPointsDFStep4.columns)
        else:
            redeemPointsDFStep4 = redeemPointsDF
            pointsBankDFStep2 = pointsBankDF
            redeemApprovedDFStep1 = redeemApprovedDF
            redeemRejectedDFStep1 = redeemRejectedDF
              
            successRedeemPointsBank()
    except:
        failRedeemPointsBank()
        errorTerminationLog()
        raise
    return redeemPointsDFStep4, pointsBankDFStep2, redeemApprovedDFStep1, redeemRejectedDFStep1

# Create outgoing file for Added Points
def outAddedPoints(addedPointsDF, outgoingBatchCut, userProfileDF):
    try:
        addedPointsDFStep1 = addedPointsDF
        nowDatetime = datetime.now() - timedelta(days=1)
        addedPointsDFStep1['Batch_Datetime'] = nowDatetime
        addedPointsDFStep1['Batch_Day'] = pandas.DatetimeIndex(addedPointsDFStep1['Batch_Datetime']).day
        addedPointsDFStep1['Batch_Month'] = pandas.DatetimeIndex(addedPointsDFStep1['Batch_Datetime']).month
        addedPointsDFStep1['Batch_Year'] = pandas.DatetimeIndex(addedPointsDFStep1['Batch_Datetime']).year
        addedPointsDFStep1['Export'] = 0

        if outgoingBatchCut == "day":
            addedPointsDFStep1['Export'][(addedPointsDFStep1['Batch_Day'] == addedPointsDFStep1['Date_Day']) & (addedPointsDFStep1['Batch_Month'] == addedPointsDFStep1['Date_Month']) & (addedPointsDFStep1['Batch_Year'] == addedPointsDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "month":
            addedPointsDFStep1['Export'][(addedPointsDFStep1['Batch_Month'] == addedPointsDFStep1['Date_Month']) & (addedPointsDFStep1['Batch_Year'] == addedPointsDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "year":
            addedPointsDFStep1['Export'][(addedPointsDFStep1['Batch_Year'] == addedPointsDFStep1['Date_Year'])] = 1
        else:
            addedPointsDFStep1['Export'] = 1

        addedPointsDFStep2 = addedPointsDFStep1[addedPointsDFStep1['Export'] == 1]
        del addedPointsDFStep2['Batch_Datetime']
        del addedPointsDFStep2['Export']

        # Add Tax_ID and External Account Code
        addedPointsDFStep2 = addedPointsDFStep2.merge(userProfileDF[['User_Code', 'Tax_ID', 'External_Account_Code']], how='left')

        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise
    return addedPointsDFStep2

# Create outgoing file for Expired Points
def outExpiredPoints(expiredPointsDF, outgoingBatchCut, userProfileDF):
    try:
        expiredPointsDFStep1 = expiredPointsDF
        nowDatetime = datetime.now() - timedelta(days=1)
        expiredPointsDFStep1['Batch_Datetime'] = nowDatetime
        expiredPointsDFStep1['Batch_Day'] = pandas.DatetimeIndex(expiredPointsDFStep1['Batch_Datetime']).day
        expiredPointsDFStep1['Batch_Month'] = pandas.DatetimeIndex(expiredPointsDFStep1['Batch_Datetime']).month
        expiredPointsDFStep1['Batch_Year'] = pandas.DatetimeIndex(expiredPointsDFStep1['Batch_Datetime']).year
        expiredPointsDFStep1['Export'] = 0

        if outgoingBatchCut == "day":
            expiredPointsDFStep1['Export'][(expiredPointsDFStep1['Batch_Day'] == expiredPointsDFStep1['Date_Day']) & (expiredPointsDFStep1['Batch_Month'] == expiredPointsDFStep1['Date_Month']) & (expiredPointsDFStep1['Batch_Year'] == expiredPointsDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "month":
            expiredPointsDFStep1['Export'][(expiredPointsDFStep1['Batch_Month'] == expiredPointsDFStep1['Date_Month']) & (expiredPointsDFStep1['Batch_Year'] == expiredPointsDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "year":
            expiredPointsDFStep1['Export'][(expiredPointsDFStep1['Batch_Year'] == expiredPointsDFStep1['Date_Year'])] = 1
        else:
            expiredPointsDFStep1['Export'] = 1

        expiredPointsDFStep2 = expiredPointsDFStep1[expiredPointsDFStep1['Export'] == 1]
        del expiredPointsDFStep2['Batch_Datetime']
        del expiredPointsDFStep2['Export']

        # Add Tax_ID and External Account Code
        expiredPointsDFStep2 = expiredPointsDFStep2.merge(userProfileDF[['User_Code', 'Tax_ID', 'External_Account_Code']], how='left')

        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise
    return expiredPointsDFStep2

# Create outgoing file for approved redemptions
def outRedeemApproved(redeemApprovedDF, outgoingBatchCut, userProfileDF):
    try:
        redeemApprovedDFStep1 = redeemApprovedDF
        nowDatetime = datetime.now() - timedelta(days=1)
        redeemApprovedDFStep1['Batch_Datetime'] = nowDatetime
        redeemApprovedDFStep1['Batch_Day'] = pandas.DatetimeIndex(redeemApprovedDFStep1['Batch_Datetime']).day
        redeemApprovedDFStep1['Batch_Month'] = pandas.DatetimeIndex(redeemApprovedDFStep1['Batch_Datetime']).month
        redeemApprovedDFStep1['Batch_Year'] = pandas.DatetimeIndex(redeemApprovedDFStep1['Batch_Datetime']).year
        redeemApprovedDFStep1['Export'] = 0

        if outgoingBatchCut == "day":
            redeemApprovedDFStep1['Export'][(redeemApprovedDFStep1['Batch_Day'] == redeemApprovedDFStep1['Date_Day']) & (redeemApprovedDFStep1['Batch_Month'] == redeemApprovedDFStep1['Date_Month']) & (redeemApprovedDFStep1['Batch_Year'] == redeemApprovedDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "month":
            redeemApprovedDFStep1['Export'][(redeemApprovedDFStep1['Batch_Month'] == redeemApprovedDFStep1['Date_Month']) & (redeemApprovedDFStep1['Batch_Year'] == redeemApprovedDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "year":
            redeemApprovedDFStep1['Export'][(redeemApprovedDFStep1['Batch_Year'] == redeemApprovedDFStep1['Date_Year'])] = 1
        else:
            redeemApprovedDFStep1['Export'] = 1

        redeemApprovedDFStep2 = redeemApprovedDFStep1[redeemApprovedDFStep1['Export'] == 1]
        del redeemApprovedDFStep2['Batch_Datetime']
        del redeemApprovedDFStep2['Export']

        # Add Tax_ID and External Account Code
        redeemApprovedDFStep2 = redeemApprovedDFStep2.merge(userProfileDF[['User_Code', 'Tax_ID', 'External_Account_Code']], how='left')

        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise
    return redeemApprovedDFStep2

# Create outgoing file for rejected redemptions
def outRedeemRejected(redeemRejectedDF, outgoingBatchCut, userProfileDF):
    try:
        redeemRejectedDFStep1 = redeemRejectedDF
        nowDatetime = datetime.now() - timedelta(days=1)
        redeemRejectedDFStep1['Batch_Datetime'] = nowDatetime
        redeemRejectedDFStep1['Batch_Day'] = pandas.DatetimeIndex(redeemRejectedDFStep1['Batch_Datetime']).day
        redeemRejectedDFStep1['Batch_Month'] = pandas.DatetimeIndex(redeemRejectedDFStep1['Batch_Datetime']).month
        redeemRejectedDFStep1['Batch_Year'] = pandas.DatetimeIndex(redeemRejectedDFStep1['Batch_Datetime']).year
        redeemRejectedDFStep1['Export'] = 0

        if outgoingBatchCut == "day":
            redeemRejectedDFStep1['Export'][(redeemRejectedDFStep1['Batch_Day'] == redeemRejectedDFStep1['Date_Day']) & (redeemRejectedDFStep1['Batch_Month'] == redeemRejectedDFStep1['Date_Month']) & (redeemRejectedDFStep1['Batch_Year'] == redeemRejectedDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "month":
            redeemRejectedDFStep1['Export'][(redeemRejectedDFStep1['Batch_Month'] == redeemRejectedDFStep1['Date_Month']) & (redeemRejectedDFStep1['Batch_Year'] == redeemRejectedDFStep1['Date_Year'])] = 1
        elif outgoingBatchCut == "year":
            redeemRejectedDFStep1['Export'][(redeemRejectedDFStep1['Batch_Year'] == redeemRejectedDFStep1['Date_Year'])] = 1
        else:
            redeemRejectedDFStep1['Export'] = 1

        redeemRejectedDFStep2 = redeemRejectedDFStep1[redeemRejectedDFStep1['Export'] == 1]
        del redeemRejectedDFStep2['Batch_Datetime']
        del redeemRejectedDFStep2['Export']

        # Add Tax_ID and External Account Code
        redeemRejectedDFStep2 = redeemRejectedDFStep2.merge(userProfileDF[['User_Code', 'Tax_ID', 'External_Account_Code']], how='left')

        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise
    return redeemRejectedDFStep2

# Create list of redeemable points
def listRedeemable(pointsBankDF, programAttribDF, userProfileDF, programSetupAttributesDF):
    try:
        # consolidate points bank per user
        pointsBankDFStep1 = pointsBankDF
        pointsBankDFStep2 = pointsBankDFStep1.groupby(['Corp_Code','Program_Code','User_Code'], as_index=False).sum()

        # get active program and active user
        pointsBankDFStep2 = pointsBankDFStep2.merge(programSetupAttributesDF[['Corp_Code','Program_Code','Active_Program','Redeem_Currency_Code','Currency_per_Points','Redeem_Min_points']], how='left')
        pointsBankDFStep2 = pointsBankDFStep2.drop_duplicates()
        pointsBankDFStep2 = pointsBankDFStep2.merge(userProfileDF[['User_Code','Active_User','User_Email','User_Mobile_Country_Code','User_Mobile_Area_Code','User_Mobile_Phone_Number','Active_Email','Active_Mobile']], how='left')

        # list available
        pointsBankDFStep2['Redeemable'] = 0
        pointsBankDFStep2['Redeemable'][(pointsBankDFStep2['Points'] > 0) & (pointsBankDFStep2['Active_Program'] == 1) & (pointsBankDFStep2['Active_User'] == 1) & (pointsBankDFStep2['Points'] >= pointsBankDFStep2['Redeem_Min_points'])] = 1
        pointsBankDFStep2['Redeem_Value'] = pointsBankDFStep2['Points'].astype(float) * pointsBankDFStep2['Currency_per_Points'].astype(float)

        # prepare table format
        pointsBankDFStep3 = pointsBankDFStep2
        del pointsBankDFStep3['Active_Program']
        del pointsBankDFStep3['Active_User']
        del pointsBankDFStep3['Currency_per_Points']
        del pointsBankDFStep3['Redeem_Min_points']
        pointsBankDFStep3['Now_Datetime'] = datetime.now()
        pointsBankDFStep3['Date_Day'] = pandas.DatetimeIndex(pointsBankDFStep3['Now_Datetime']).day
        pointsBankDFStep3['Date_Month'] = pandas.DatetimeIndex(pointsBankDFStep3['Now_Datetime']).month
        pointsBankDFStep3['Date_Year'] = pandas.DatetimeIndex(pointsBankDFStep3['Now_Datetime']).year
        del pointsBankDFStep3['Now_Datetime']
        pointsBankDFStep3 = pointsBankDFStep3.reset_index(drop=True)

        # select only redeemable
        pointsBankDFStep4 = pointsBankDFStep3[pointsBankDFStep3['Redeemable'] == 1]
        del pointsBankDFStep4['Redeemable']
        # round currency
        pointsBankDFStep4 = pointsBankDFStep4.round({'Redeem_Value': currencyDecimals})
        # round points
        pointsBankDFStep4 = pointsBankDFStep4.round({'Points': pointsDecimals})

        successListRedeemable()
    except:
        failListRedeemable()
        errorTerminationLog()
        raise
    return pointsBankDFStep4

# Back-up files - runs before processing
def batchBackup():
    try:
        if not os.path.exists('backup_previous_batch'):
            os.makedirs('backup_previous_batch')
        if not os.path.exists('backup_previous_batch/Incoming'):
            os.makedirs('backup_previous_batch/Incoming')
        if not os.path.exists('backup_previous_batch/Outgoing'):
            os.makedirs('backup_previous_batch/Outgoing')
        # core files
        shutil.copyfile('ProgramSetup.csv', 'backup_previous_batch/ProgramSetup.csv')
        shutil.copyfile('CorpNames.csv', 'backup_previous_batch/CorpNames.csv')
        shutil.copyfile('CountryCodes.csv', 'backup_previous_batch/CountryCodes.csv')
        shutil.copyfile('CurrencyNames.csv', 'backup_previous_batch/CurrencyNames.csv')
        shutil.copyfile('ProductNames.csv', 'backup_previous_batch/ProductNames.csv')
        shutil.copyfile('ProgramNames.csv', 'backup_previous_batch/ProgramNames.csv')
        shutil.copyfile('ProgramAttrib.csv', 'backup_previous_batch/ProgramAttrib.csv')
        shutil.copyfile('UserProfile.csv', 'backup_previous_batch/UserProfile.csv')
        shutil.copyfile('WelcomeUserQueue.csv', 'backup_previous_batch/WelcomeUserQueue.csv')
        shutil.copyfile('PointsBank.csv', 'backup_previous_batch/PointsBank.csv')
        shutil.copyfile('ExpiredPoints.csv', 'backup_previous_batch/ExpiredPoints.csv')
        shutil.copyfile('AddedPoints.csv', 'backup_previous_batch/AddedPoints.csv')
        shutil.copyfile('RedeemApproved.csv', 'backup_previous_batch/RedeemApproved.csv')
        shutil.copyfile('RedeemRejected.csv', 'backup_previous_batch/RedeemRejected.csv')
        # incoming files
        shutil.copyfile(incomingbatchFileDirectory + 'LoadPoints.csv', 'backup_previous_batch/Incoming/LoadPoints.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'RedeemPoints.csv', 'backup_previous_batch/Incoming/RedeemPoints.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'AddUserProfile.csv', 'backup_previous_batch/Incoming/AddUserProfile.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'UpdateUserProfile.csv', 'backup_previous_batch/Incoming/UpdateUserProfile.csv')
        # outgoing files
        if os.path.isfile(outgoingbatchFileDirectory + 'OutAddedPoints.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutAddedPoints.csv', 'backup_previous_batch/Outgoing/OutAddedPoints.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutExpiredPoints.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutExpiredPoints.csv', 'backup_previous_batch/Outgoing/OutExpiredPoints.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutRedeemApproved.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutRedeemApproved.csv', 'backup_previous_batch/Outgoing/OutRedeemApproved.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutRedeemRejected.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutRedeemRejected.csv', 'backup_previous_batch/Outgoing/OutRedeemRejected.csv')
        successBatchBackup()
    except:
        failBatchBackup()
        errorTerminationLog()
        raise

# Export routine - runs after processing
def batchExport(programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF, userProfileDF, welcomeUserQueueDF, pointsBankDF, expiredPointsDF, addedPointsDF, redeemApprovedDF, redeemRejectedDF, listRedeemableDF, loadPointsDF, redeemPointsDF, addUserDF, updateUserDF, outAddedPointsDF, outExpiredPointsDF, outRedeemApprovedDF, outRedeemRejectedDF):
    try:
        # core files
        programSetupDF.to_csv("ProgramSetup.csv", index = False)
        corpNamesDF.to_csv("CorpNames.csv", index = False)
        countryCodesDF.to_csv("CountryCodes.csv", index = False)
        currencyNamesDF.to_csv("CurrencyNames.csv", index = False)
        productNamesDF.to_csv("ProductNames.csv", index = False)
        programNamesDF.to_csv("ProgramNames.csv", index = False)
        programAttribDF.to_csv("ProgramAttrib.csv", index = False)
        userProfileDF.to_csv("UserProfile.csv", index = False)
        welcomeUserQueueDF.to_csv("WelcomeUserQueue.csv", index = False)
        pointsBankDF.to_csv("PointsBank.csv", index = False)
        expiredPointsDF.to_csv("ExpiredPoints.csv", index = False)
        addedPointsDF.to_csv("AddedPoints.csv", index = False)
        redeemApprovedDF.to_csv("RedeemApproved.csv", index = False)
        redeemRejectedDF.to_csv("RedeemRejected.csv", index = False)
        listRedeemableDF.to_csv("ListRedeemable.csv", index = False)
        # incoming files
        loadPointsDF.to_csv(incomingbatchFileDirectory + "LoadPoints.csv", index = False)
        redeemPointsDF.to_csv(incomingbatchFileDirectory + "RedeemPoints.csv", index = False)
        addUserDF.to_csv(incomingbatchFileDirectory + "AddUserProfile.csv", index = False)
        updateUserDF.to_csv(incomingbatchFileDirectory + "UpdateUserProfile.csv", index = False)
        # outgoing files
        outAddedPointsDF.to_csv(outgoingbatchFileDirectory + "OutAddedPoints.csv", index = False)
        outExpiredPointsDF.to_csv(outgoingbatchFileDirectory + "OutExpiredPoints.csv", index = False)
        outRedeemApprovedDF.to_csv(outgoingbatchFileDirectory + "OutRedeemApproved.csv", index = False)
        outRedeemRejectedDF.to_csv(outgoingbatchFileDirectory + "OutRedeemRejected.csv", index = False)
        # export core files to outgoing
        programSetupDF.to_csv(outgoingbatchFileDirectory + "ProgramSetup.csv", index = False)
        corpNamesDF.to_csv(outgoingbatchFileDirectory + "CorpNames.csv", index = False)
        countryCodesDF.to_csv(outgoingbatchFileDirectory + "CountryCodes.csv", index = False)
        currencyNamesDF.to_csv(outgoingbatchFileDirectory + "CurrencyNames.csv", index = False)
        productNamesDF.to_csv(outgoingbatchFileDirectory + "ProductNames.csv", index = False)
        programNamesDF.to_csv(outgoingbatchFileDirectory + "ProgramNames.csv", index = False)
        programAttribDF.to_csv(outgoingbatchFileDirectory + "ProgramAttrib.csv", index = False)
        userProfileDF.to_csv(outgoingbatchFileDirectory + "UserProfile.csv", index = False)
        welcomeUserQueueDF.to_csv(outgoingbatchFileDirectory + "WelcomeUserQueue.csv", index = False)
        pointsBankDF.to_csv(outgoingbatchFileDirectory + "PointsBank.csv", index = False)
        listRedeemableDF.to_csv(outgoingbatchFileDirectory + "ListRedeemable.csv", index = False)

        successBatchExport()
    except:
        failBatchExport()
        errorTerminationLog()
        raise