# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-15
# Points Engine - PostgreSQL version

from poorman_back_end import *
from poorman_postgresql import *
from poorman_postgresql_migrate import *
from poorman_postgresql_read import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# Import routine

# Program Setup - Configuration of loyalty programs
def programSetupLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # enforce boolean attributes
        SQLCommand = "UPDATE poorman.programattrib SET Active_Program = 0 WHERE Active_Program <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "UPDATE poorman.programattrib SET Renew_Expiry_On_Purchase = 0 WHERE Renew_Expiry_On_Purchase <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedProgramSetup()
    except:
        failedProgramSetup()
        errorTerminationLog()
        raise

# User Profile - Data on users of loyalty programs
def userProfileLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # enforce boolean attributes
        SQLCommand = "UPDATE poorman.userprofile SET Active_User = 0 WHERE Active_User <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.userprofile SET Active_Email = 0 WHERE Active_Email <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.userprofile SET Active_Mobile = 0 WHERE Active_Mobile <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
        SQLCommand = "UPDATE poorman.userprofile SET Active_Email = 0 WHERE User_Email IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.userprofile SET Active_Mobile = 0 WHERE User_Mobile_Area_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.userprofile SET Active_Mobile = 0 WHERE User_Mobile_Phone_Number IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedUserProfile()
    except:
        failedUserProfile()
        errorTerminationLog()
        raise

# Wrapper - external accounts to user code
def wrapperExternalAccount():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        
        # External Account Wrapper
        SQLCommand = "DROP TABLE IF EXISTS poorman.wrapperexternalaccount"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "CREATE TABLE poorman.wrapperexternalaccount AS SELECT User_Code, External_Account_Code, Tax_ID FROM poorman.userprofile"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DELETE FROM poorman.wrapperexternalaccount a USING poorman.wrapperexternalaccount b WHERE a.User_Code < b.User_Code AND a.External_Account_Code = b.External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.wrapperexternalaccount RENAME User_Code TO User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DELETE FROM poorman.wrapperexternalaccount WHERE External_Account_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Tax ID Wrapper
        SQLCommand = "DROP TABLE IF EXISTS poorman.wrappertaxid"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "CREATE TABLE poorman.wrappertaxid AS SELECT User_Code, External_Account_Code, Tax_ID FROM poorman.userprofile"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DELETE FROM poorman.wrappertaxid a USING poorman.wrappertaxid b WHERE a.User_Code < b.User_Code AND a.Tax_ID = b.Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.wrappertaxid RENAME User_Code TO User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DELETE FROM poorman.wrappertaxid WHERE Tax_ID IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        sucessWrapperExternalAccount()
    except:
        failedWrapperExternalAccount()
        errorTerminationLog()
        raise

# Welcome User - queue of users to get welcome
def welcomeUserQueue():
    try:
        successWelcomeQueue()
    except:
        failWelcomeQueue()
        errorTerminationLog()
        raise

# Add User - Batch file to add new user
def addUser():
    cols = ["Corp_Code","Program_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        addUserDF = pandas.read_csv(incomingbatchFileDirectory + 'AddUserProfile.csv', usecols=cols, index_col=False, dtype={'User_Mobile_Country_Code':'object', 'User_Mobile_Area_Code':'object', 'User_Mobile_Phone_Number':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})        
        migrateAddUserPostgreSQL(addUserDF)
        loadedAddUser()
    except:
        failedAddUser()
        errorTerminationLog()
        raise

# Update User - Batch file to update existing users
def updateUser():
    cols = ["Corp_Code","Program_Code","User_Code","Active_User","User_Email","User_Mobile_Country_Code","User_Mobile_Area_Code","User_Mobile_Phone_Number","Active_Email","Active_Mobile","Tax_ID","External_Account_Code"]
    try:
        updateUserDF = pandas.read_csv(incomingbatchFileDirectory + 'UpdateUserProfile.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'User_Mobile_Country_Code':'object', 'User_Mobile_Area_Code':'object', 'User_Mobile_Phone_Number':'object','External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object'})  
        migrateUpdateUserPostgreSQL(updateUserDF)
        loadedUpdateUser()
    except:
        failedUpdateUser()
        errorTerminationLog()
        raise

# Points Bank - Current status of points
def pointsBankLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # remove zero and negative points
        SQLCommand = "DELETE FROM poorman.pointsbank WHERE Points <= 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        # round points
        SQLCommand = "UPDATE poorman.pointsbank SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedPointsBank()
    except:
        failedPointsBank()
        errorTerminationLog()
        raise

# Load Points - Batch file to load new points
def loadPointsLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Currency_Code","Value","Date_Day","Date_Month","Date_Year","Tax_ID","External_Account_Code"]
    try:
        loadPointsDF = pandas.read_csv(incomingbatchFileDirectory + 'LoadPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        migrateLoadPointsPostgreSQL(loadPointsDF)

        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round currency
        SQLCommand = "UPDATE poorman.loadpoints SET Value = round(cast(Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove zero and negative values
        SQLCommand = "DELETE FROM poorman.loadpoints WHERE Value <= 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        # External Account to User ID conversion
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD User_Code2 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD User_Code3 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints as a SET User_Code2 = b.User_Code2 FROM poorman.wrapperexternalaccount as b WHERE a.External_Account_Code = b.External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints as a SET User_Code3 = b.User_Code3 FROM poorman.wrappertaxid as b WHERE a.Tax_ID = b.Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET User_Code = User_Code2 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET User_Code = User_Code3 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove entries with no user accounts
        SQLCommand = "DELETE FROM poorman.loadpoints WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand) 

        postgreSQLClose(conn, cur)
        loadedLoadPoints()
    except:
        failedLoadPoints()
        errorTerminationLog()
        raise

# Redeem Points - Batch file to redeem points
def redeemPointsLoad():
    cols = ["Corp_Code","Program_Code","User_Code","Points","Date_Day","Date_Month","Date_Year","Tax_ID","External_Account_Code"]
    try:
        redeemPointsDF = pandas.read_csv(incomingbatchFileDirectory + 'RedeemPoints.csv', usecols=cols, index_col=False, dtype={'User_Code':'object', 'External_Account_Code':'object', 'Tax_ID':'object', 'Corp_Code':'object', 'Program_Code':'object', 'Date_Day':'object', 'Date_Month':'object', 'Date_Year':'object'})
        migrateRedeemPointsPostgreSQL(redeemPointsDF)

        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round points
        SQLCommand = "UPDATE poorman.redeempoints SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # External Account to User ID conversion
        SQLCommand = "ALTER TABLE poorman.redeempoints DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.redeempoints ADD User_Code2 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints ADD User_Code3 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints as a SET User_Code2 = b.User_Code2 FROM poorman.wrapperexternalaccount as b WHERE a.External_Account_Code = b.External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints as a SET User_Code3 = b.User_Code3 FROM poorman.wrappertaxid as b WHERE a.Tax_ID = b.Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints SET User_Code = User_Code2 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints SET User_Code = User_Code3 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove entries with no user accounts
        SQLCommand = "DELETE FROM poorman.redeempoints WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand) 

        postgreSQLClose(conn, cur)        
        loadedRedeemPoints()
    except:
        failedRedeemPoints()
        errorTerminationLog()
        raise

# Expired Points - Control points moved to expired
def expiredPointsLoad(): 
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round points
        SQLCommand = "UPDATE poorman.expiredpoints SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        postgreSQLClose(conn, cur) 
        loadedExpiredPoints()
    except:
        failedExpiredPoints()
        errorTerminationLog()
        raise

# Added Points - Control points added to points bank
def addedPointsLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        
        # round points
        SQLCommand = "UPDATE poorman.addedpoints SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        postgreSQLClose(conn, cur)
        loadedAddedPoints()
    except:
        failedAddedPoints()
        errorTerminationLog()
        raise

# Approved redemption requests - Control requests that were approved
def redeemApprovedLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round currency
        SQLCommand = "UPDATE poorman.redeemapproved SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        # round points
        SQLCommand = "UPDATE poorman.redeemapproved SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedRedeemApproved()
    except:
        failedRedeemApproved()
        errorTerminationLog()
        raise

# Rejected redemption requests - Control requests that were rejected
def redeemRejectedLoad():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round currency
        SQLCommand = "UPDATE poorman.redeemrejected SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        # round points
        SQLCommand = "UPDATE poorman.redeemrejected SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedRedeemRejected()
    except:
        failedRedeemRejected()
        errorTerminationLog()
        raise

# Load list redeemable file
def loadListRedeemable():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # round currency
        SQLCommand = "UPDATE poorman.listredeemable SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        # round points
        SQLCommand = "UPDATE poorman.listredeemable SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # round currency
        SQLCommand = "UPDATE poorman.redeemablesent SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        # round points
        SQLCommand = "UPDATE poorman.redeemablesent SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        loadedListRedeemable()
    except:
        failedListRedeemable()
        errorTerminationLog()
        raise

# Processing routine

# IN ROADMAP
# WRITE ROUTINE TO ACTIVATE/DEACTIVATE PROGRAMS
# WRITE ROUTINE TO UPDATE PROGRAMS

# Merge program setup with its attributes
def programSetupMerge():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        
        SQLCommand = "DROP TABLE IF EXISTS poorman.programsetupattrib"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.programsetupattrib AS SELECT a.*, b.Active_Program, b.Redeem_Currency_Code, b.Currency_per_Points, b.Redeem_Min_points, b.Renew_Expiry_On_Purchase FROM poorman.programsetup AS a, poorman.programattrib as b WHERE a.Program_Code = b.Program_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
               
        postgreSQLClose(conn, cur)
        successMergeProgramSetup()
    except:
        failMergeProgramSetup()
        errorTerminationLog()
        raise

# Add new users based on AddUserProfile batch file
def addUserProfile():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # enforce boolean attributes
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_User = 0 WHERE Active_User <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_Email = 0 WHERE Active_Email <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_Mobile = 0 WHERE Active_Mobile <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_Email = 0 WHERE User_Email IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_Mobile = 0 WHERE User_Mobile_Area_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.adduserprofile SET Active_Mobile = 0 WHERE User_Mobile_Phone_Number IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # attribute new User Code
        # get fields to match User Profile
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxusercode"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxusercode AS SELECT MAX(User_Code) AS Max_User_Code FROM poorman.userprofile"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.adduserprofile2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.adduserprofile2 AS SELECT a.Corp_Code, a.Program_Code, b.Max_User_Code + ROW_NUMBER() OVER () AS User_Code, a.Active_User, a.User_Email, a.User_Mobile_Country_Code, a.User_Mobile_Area_Code, a.User_Mobile_Phone_Number, a.Active_Email, a.Active_Mobile, a.Tax_ID, a.External_Account_Code FROM poorman.adduserprofile AS a, poorman.maxusercode AS b"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # join new users to existing users
        SQLCommand = "INSERT INTO poorman.userprofile (SELECT * FROM poorman.adduserprofile2)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # generate welcome queue
        if sendWelcomeEmail == 1 | sendWelcomeSMS == 1:
            SQLCommand = "INSERT INTO poorman.welcomeuserqueue (SELECT * FROM poorman.adduserprofile2)"
            postgreSQLExecuteCommand(cur, SQLCommand)
            
        # empty out add users table
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxusercode"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.adduserprofile2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DELETE FROM poorman.adduserprofile"
        postgreSQLExecuteCommand(cur, SQLCommand)
            
        postgreSQLClose(conn, cur)
        successAddUserProfile()
    except:
        failAddUserProfile()
        errorTerminationLog()
        raise

# Update existing users based on UpdateUserProfile batch file
def updateUserProfile():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
           
        # enforce boolean attributes
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_User = 0 WHERE Active_User <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_Email = 0 WHERE Active_Email <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_Mobile = 0 WHERE Active_Mobile <> 1"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # deactivate e-mail if no e-mail in profile and deactivate mobile if no phone in profile
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_Email = 0 WHERE User_Email IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_Mobile = 0 WHERE User_Mobile_Area_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET Active_Mobile = 0 WHERE User_Mobile_Phone_Number IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # External Account to User ID conversion
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.updateuserprofile ADD User_Code2 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.updateuserprofile ADD User_Code3 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile as a SET User_Code2 = b.User_Code2 FROM poorman.wrapperexternalaccount as b WHERE a.External_Account_Code = b.External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile as a SET User_Code3 = b.User_Code3 FROM poorman.wrappertaxid as b WHERE a.Tax_ID = b.Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET User_Code = User_Code2 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile SET User_Code = User_Code3 WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code3"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove entries with no user accounts
        SQLCommand = "DELETE FROM poorman.updateuserprofile WHERE User_Code IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # check if user really exists
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.updateuserprofile ADD User_Code2 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.updateuserprofile as a SET User_Code2 = b.User_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # remove users that do not already exist
        SQLCommand = "DELETE FROM poorman.updateuserprofile WHERE User_Code2 IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand) 
        SQLCommand = "ALTER TABLE poorman.updateuserprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)  

        # remove original entry from user profile
        SQLCommand = "ALTER TABLE poorman.userprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.userprofile ADD User_Code2 int8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.userprofile as a SET User_Code2 = b.User_Code FROM poorman.updateuserprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)    
        SQLCommand = "DELETE FROM poorman.userprofile WHERE User_Code2 IS NOT NULL"
        postgreSQLExecuteCommand(cur, SQLCommand) 
        SQLCommand = "ALTER TABLE poorman.userprofile DROP COLUMN IF EXISTS User_Code2"
        postgreSQLExecuteCommand(cur, SQLCommand)  
 
        # join updated list with user profile
        SQLCommand = "INSERT INTO poorman.userprofile (SELECT * FROM poorman.updateuserprofile)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # empty out update users table
        SQLCommand = "DELETE FROM poorman.updateuserprofile"
        postgreSQLExecuteCommand(cur, SQLCommand)
            
        postgreSQLClose(conn, cur)
        successUpdateUserProfile()
    except:
        failUpdateUserProfile()
        errorTerminationLog()
        raise

# Calculate points to be added based on LoadPoints batch file
def addPointsBank():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # merge batch file to load points with business rules
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Active_Program"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Active_Program int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Points_per_Currency"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Points_per_Currency float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiration_Days"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Expiration_Days int8"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "UPDATE poorman.loadpoints as a SET Active_Program = b.Active_Program FROM poorman.programsetupattrib as b WHERE a.Program_Code = b.Program_Code AND a.Currency_Code = b.Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints as a SET Points_per_Currency = b.Points_per_Currency FROM poorman.programsetupattrib as b WHERE a.Program_Code = b.Program_Code AND a.Currency_Code = b.Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints as a SET Expiration_Days = b.Expiration_Days FROM poorman.programsetupattrib as b WHERE a.Program_Code = b.Program_Code AND a.Currency_Code = b.Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # merge batch file with user table
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Active_User"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Active_User int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints as a SET Active_User = b.Active_User FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # calculate points for active programs; inactive programs will come zeroed out
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Points"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "UPDATE poorman.loadpoints SET Points = (Points_per_Currency * Value * Active_Program * Active_User)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # round points
        SQLCommand = "UPDATE poorman.loadpoints SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        # calculate expiration date based on program setup
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Date_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Date_Datetime date"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Expiry_Datetime date"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Day"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Expiry_Date_Day int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Month"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Expiry_Date_Month int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Year"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Expiry_Date_Year int"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "UPDATE poorman.loadpoints SET Date_Datetime = TO_DATE(CONCAT(Date_Year::text, LPAD(Date_Month::text, 2, '0'), LPAD(Date_Day::text, 2, '0')),'YYYYMMDD')"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET Expiry_Datetime = date_datetime + (Expiration_Days * interval '1 day')"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET Expiry_Date_Day = EXTRACT (DAY FROM Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET Expiry_Date_Month = EXTRACT (MONTH FROM Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.loadpoints SET Expiry_Date_Year = EXTRACT (YEAR FROM Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # assign Added ID to points to be added
        # get fields to match added points
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Added_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints ADD Added_ID int8"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "DROP TABLE IF EXISTS poorman.maxaddedid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxaddedid AS SELECT MAX(Added_ID) AS Max_Added_ID FROM poorman.addedpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.loadpoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.loadpoints2 AS SELECT a.Corp_Code, a.Program_Code, a.User_Code, a.Points, a.Currency_Code, a.Value, a.Points_per_Currency, a.Date_Day, a.Date_Month, a.Date_Year, a.Expiry_Date_Day, a.Expiry_Date_Month, a.Expiry_Date_Year, b.Max_Added_ID + ROW_NUMBER() OVER () AS Added_ID FROM poorman.loadpoints as A, poorman.maxaddedid as B"
        postgreSQLExecuteCommand(cur, SQLCommand)
        
        # get fields to match points bank
        SQLCommand = "DROP TABLE IF EXISTS poorman.loadpoints3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.loadpoints3 AS SELECT Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year FROM poorman.loadpoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # join with points bank
        SQLCommand = "INSERT INTO poorman.pointsbank (SELECT * FROM poorman.loadpoints3)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # join with added points
        SQLCommand = "INSERT INTO poorman.addedpoints (SELECT * FROM poorman.loadpoints2)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # renew expiration date if renew condition on use is on
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Datetime date"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expiry_Datetime = TO_DATE(CONCAT(Expiry_Date_Year::text, LPAD(Expiry_Date_Month::text, 2, '0'), LPAD(Expiry_Date_Day::text, 2, '0')),'YYYYMMDD')"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxexpirydate"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxexpirydate AS SELECT User_Code, MAX(Expiry_Datetime) AS Expiry_Datetime_Max FROM poorman.pointsbank group by User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)    
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime_Max"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Datetime_Max date"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "UPDATE poorman.pointsbank as a SET Expiry_Datetime_Max = b.Expiry_Datetime_Max FROM poorman.maxexpirydate as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Renew_Expiry_On_Purchase"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Renew_Expiry_On_Purchase int"
        postgreSQLExecuteCommand(cur, SQLCommand)            
        SQLCommand = "UPDATE poorman.pointsbank as a SET Renew_Expiry_On_Purchase = b.Renew_Expiry_On_Purchase FROM poorman.programattrib as b WHERE a.Program_Code = b.Program_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Updated_Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Updated_Expiry_Datetime date"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Updated_Expiry_Datetime = ( CASE WHEN (Renew_Expiry_On_Purchase = 1) THEN Expiry_Datetime_Max ELSE (Expiry_Datetime) END )"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Date_Day"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Date_Day int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Date_Month"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Date_Month int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Date_Year"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Date_Year int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expiry_Date_Day = EXTRACT (DAY FROM Updated_Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expiry_Date_Month = EXTRACT (MONTH FROM Updated_Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expiry_Date_Year = EXTRACT (YEAR FROM Updated_Expiry_Datetime)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime_Max"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Renew_Expiry_On_Purchase"
        postgreSQLExecuteCommand(cur, SQLCommand)  
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Updated_Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # clean-up entries that provided zero points
        SQLCommand = "DELETE FROM poorman.pointsbank WHERE Points <= 0"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # empty load points
        SQLCommand = "DROP TABLE IF EXISTS poorman.loadpoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.loadpoints3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxaddedid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxexpirydate"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DELETE FROM poorman.loadpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Active_Program"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Points_per_Currency"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiration_Days"
        postgreSQLExecuteCommand(cur, SQLCommand)    
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Active_User"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Points"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Date_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)  
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Day"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Month"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Expiry_Date_Year"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.loadpoints DROP COLUMN IF EXISTS Added_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successAddPointsBank()
    except:
        failAddPointsBank()
        errorTerminationLog()
        raise

# Remove expired points from points bank
def removeExpiredPoints():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # tag expired points
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expiry_Datetime date"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expired"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Expired int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expiry_Datetime = TO_DATE(CONCAT(Expiry_Date_Year::text, LPAD(Expiry_Date_Month::text, 2, '0'), LPAD(Expiry_Date_Day::text, 2, '0')),'YYYYMMDD')"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Expired = ( CASE WHEN (Expiry_Datetime < now()) THEN 1 ELSE 0 END )"
        postgreSQLExecuteCommand(cur, SQLCommand)     

        # break into not expired and newly expired
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.pointsbank2 AS SELECT * FROM poorman.pointsbank WHERE Expired = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DELETE FROM poorman.pointsbank WHERE Expired = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Expired"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank2 DROP COLUMN IF EXISTS Expiry_Datetime"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank2 DROP COLUMN IF EXISTS Expired"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # assign Expiry ID to newly expired points
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxexpiryid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxexpiryid AS SELECT MAX(Expiry_ID) AS Max_Expiry_ID FROM poorman.expiredpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.pointsbank3 AS SELECT a.*, b.Max_Expiry_ID + ROW_NUMBER() OVER () AS Expiry_ID FROM poorman.pointsbank2 AS a, poorman.maxexpiryid AS b"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # join previously expired points with newly expired points
        SQLCommand = "INSERT INTO poorman.expiredpoints (SELECT * FROM poorman.pointsbank3)"
        postgreSQLExecuteCommand(cur, SQLCommand)
 
        # clean-up
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxexpiryid"
        postgreSQLExecuteCommand(cur, SQLCommand)
                
        postgreSQLClose(conn, cur)
        successRemoveExpiredPoints()
    except:
        failRemoveExpiredPoints()
        errorTerminationLog()
        raise

# Attemp to redeem points - may be approved or rejected
def redeemPoints():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # consolidate redemption requests per user
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeempoints2 AS SELECT Corp_Code, Program_Code, User_Code, SUM(Points) AS Redeem_Points FROM poorman.redeempoints GROUP BY Corp_Code, Program_Code, User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # consolidate points bank per user
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.pointsbank2 AS SELECT Corp_Code, Program_Code, User_Code, SUM(Points) AS Available_Points FROM poorman.pointsbank GROUP BY Corp_Code, Program_Code, User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # join points information from points bank
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Available_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Available_Points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 as a SET Available_Points = b.Available_Points FROM poorman.pointsbank2 as b WHERE a.Corp_Code = b.Corp_Code AND a.Program_Code = b.Program_Code AND a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # get active program and active user
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Active_Program"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Active_Program int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Redeem_Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Redeem_Currency_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Currency_per_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Currency_per_Points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Redeem_Min_points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Redeem_Min_points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 as a SET Active_Program = b.Active_Program, Redeem_Currency_Code = b.Redeem_Currency_Code, Currency_per_Points = b.Currency_per_Points, Redeem_Min_points = b.Redeem_Min_points FROM poorman.programsetupattrib as b WHERE a.Corp_Code = b.Corp_Code AND a.Program_Code = b.Program_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Active_User"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Active_User int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 as a SET Active_User = b.Active_User FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
    
        # approve or reject redemption requests
        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Points_Ratio"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Points_Ratio float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 as a SET Points_Ratio = Redeem_Points / Available_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 as a SET Points_Ratio = 0 WHERE Points_Ratio IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Redeem_Approve"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Redeem_Approve int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 SET Redeem_Approve = ( CASE WHEN (Points_Ratio > 0 AND Points_Ratio <= 1 AND Active_Program = 1 AND Active_User = 1 AND Redeem_Points > Redeem_Min_points) THEN 1 ELSE 0 END )"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.redeempoints2 DROP COLUMN IF EXISTS Redeem_Value"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints2 ADD Redeem_Value float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.redeempoints2 SET Redeem_Value = Redeem_Points * Currency_per_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # round currency
        SQLCommand = "UPDATE poorman.redeempoints2 SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # prepare table format
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeempoints3 AS SELECT Corp_Code, Program_Code, User_Code, Redeem_Points AS Points, EXTRACT (DAY FROM NOW()) AS Date_Day, EXTRACT (MONTH FROM NOW()) AS Date_Month, EXTRACT (YEAR FROM NOW()) AS Date_Year, Redeem_Currency_Code, Redeem_Value, Redeem_Approve, Points_Ratio FROM poorman.redeempoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # break into approved and rejected
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3_approved"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeempoints3_approved AS SELECT * FROM poorman.redeempoints3 WHERE Redeem_Approve = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DELETE FROM poorman.redeempoints3 WHERE Redeem_Approve = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3_rejected"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints3 RENAME TO redeempoints3_rejected"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.redeempoints3_approved DROP COLUMN IF EXISTS Redeem_Approve"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints3_rejected DROP COLUMN IF EXISTS Redeem_Approve"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # move approved requests to approved control
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxapprovalid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxapprovalid AS SELECT MAX(Approval_ID) AS Max_Approval_ID FROM poorman.redeemapproved"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints4_approved"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeempoints4_approved AS SELECT a.*, b.Max_Approval_ID + ROW_NUMBER() OVER () AS Approval_ID FROM poorman.redeempoints3_approved AS a, poorman.maxapprovalid AS b"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints4_approved DROP COLUMN IF EXISTS Points_Ratio"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "INSERT INTO poorman.redeemapproved (SELECT * FROM poorman.redeempoints4_approved)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # move rejected to rejected control
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxrejectedid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.maxrejectedid AS SELECT MAX(Rejected_ID) AS Max_Rejected_ID FROM poorman.redeemrejected"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints4_rejected"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.redeempoints4_rejected AS SELECT a.*, b.Max_Rejected_ID + ROW_NUMBER() OVER () AS Rejected_ID FROM poorman.redeempoints3_rejected AS a, poorman.maxrejectedid AS b"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.redeempoints4_rejected DROP COLUMN IF EXISTS Points_Ratio"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "INSERT INTO poorman.redeemrejected (SELECT * FROM poorman.redeempoints4_rejected)"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # deduct points from points bank
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Points_Ratio"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank ADD Points_Ratio float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank as a SET Points_Ratio = b.Points_Ratio FROM poorman.redeempoints3_approved as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank as a SET Points_Ratio = 0 WHERE Points_Ratio IS NULL"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.pointsbank SET Points = Points * (1.0000 - Points_Ratio)"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.pointsbank DROP COLUMN IF EXISTS Points_Ratio"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # round points
        SQLCommand = "UPDATE poorman.pointsbank SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # empty redemption request
        SQLCommand = "DROP TABLE IF EXISTS poorman.pointsbank2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints2"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3_approved"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints3_rejected"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints4_approved"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.redeempoints4_rejected"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxapprovalid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DROP TABLE IF EXISTS poorman.maxrejectedid"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "DELETE FROM poorman.redeempoints"
        postgreSQLExecuteCommand(cur, SQLCommand)
              
        postgreSQLClose(conn, cur)
        successRedeemPointsBank()
    except:
        failRedeemPointsBank()
        errorTerminationLog()
        raise

# Create outgoing file for Added Points
def outAddedPoints():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        SQLCommand = "DROP TABLE IF EXISTS poorman.outaddedpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "CREATE TABLE poorman.outaddedpoints AS SELECT *, EXTRACT (DAY FROM NOW() - interval '1 day') AS Batch_Day, EXTRACT (MONTH FROM NOW()) AS Batch_Month, EXTRACT (YEAR FROM NOW()) AS Batch_Year FROM poorman.addedpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)                
        SQLCommand = "ALTER TABLE poorman.outaddedpoints DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outaddedpoints ADD Export int"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        if outgoingBatchCut == "day":
            SQLCommand = "UPDATE poorman.outaddedpoints SET Export = ( CASE WHEN (Date_Day = Batch_Day AND Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "month":
            SQLCommand = "UPDATE poorman.outaddedpoints SET Export = ( CASE WHEN (Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "year":
            SQLCommand = "UPDATE poorman.outaddedpoints SET Export = ( CASE WHEN (Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        else:
            SQLCommand = "UPDATE poorman.outaddedpoints SET Export = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
      
        SQLCommand = "DELETE FROM poorman.outaddedpoints WHERE Export = 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outaddedpoints DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Add Tax_ID and External Account Code
        SQLCommand = "ALTER TABLE poorman.outaddedpoints DROP COLUMN IF EXISTS Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outaddedpoints ADD Tax_ID varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.outaddedpoints DROP COLUMN IF EXISTS External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outaddedpoints ADD External_Account_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outaddedpoints as a SET Tax_ID = b.Tax_ID FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outaddedpoints as a SET External_Account_Code = b.External_Account_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise

# Create outgoing file for Expired Points
def outExpiredPoints():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        SQLCommand = "DROP TABLE IF EXISTS poorman.outexpiredpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "CREATE TABLE poorman.outexpiredpoints AS SELECT *, EXTRACT (DAY FROM NOW() - interval '1 day') AS Batch_Day, EXTRACT (MONTH FROM NOW()) AS Batch_Month, EXTRACT (YEAR FROM NOW()) AS Batch_Year FROM poorman.expiredpoints"
        postgreSQLExecuteCommand(cur, SQLCommand)                
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints ADD Export int"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        if outgoingBatchCut == "day":
            SQLCommand = "UPDATE poorman.outexpiredpoints SET Export = ( CASE WHEN (Date_Day = Batch_Day AND Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "month":
            SQLCommand = "UPDATE poorman.outexpiredpoints SET Export = ( CASE WHEN (Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "year":
            SQLCommand = "UPDATE poorman.outexpiredpoints SET Export = ( CASE WHEN (Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        else:
            SQLCommand = "UPDATE poorman.outexpiredpoints SET Export = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
      
        SQLCommand = "DELETE FROM poorman.outexpiredpoints WHERE Export = 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Add Tax_ID and External Account Code
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints DROP COLUMN IF EXISTS Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints ADD Tax_ID varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints DROP COLUMN IF EXISTS External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outexpiredpoints ADD External_Account_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outexpiredpoints as a SET Tax_ID = b.Tax_ID FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outexpiredpoints as a SET External_Account_Code = b.External_Account_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise

# Create outgoing file for approved redemptions
def outRedeemApproved():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        SQLCommand = "DROP TABLE IF EXISTS poorman.outredeemapproved"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "CREATE TABLE poorman.outredeemapproved AS SELECT *, EXTRACT (DAY FROM NOW() - interval '1 day') AS Batch_Day, EXTRACT (MONTH FROM NOW()) AS Batch_Month, EXTRACT (YEAR FROM NOW()) AS Batch_Year FROM poorman.redeemapproved"
        postgreSQLExecuteCommand(cur, SQLCommand)                
        SQLCommand = "ALTER TABLE poorman.outredeemapproved DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemapproved ADD Export int"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        if outgoingBatchCut == "day":
            SQLCommand = "UPDATE poorman.outredeemapproved SET Export = ( CASE WHEN (Date_Day = Batch_Day AND Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "month":
            SQLCommand = "UPDATE poorman.outredeemapproved SET Export = ( CASE WHEN (Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "year":
            SQLCommand = "UPDATE poorman.outredeemapproved SET Export = ( CASE WHEN (Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        else:
            SQLCommand = "UPDATE poorman.outredeemapproved SET Export = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
      
        SQLCommand = "DELETE FROM poorman.outredeemapproved WHERE Export = 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemapproved DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Add Tax_ID and External Account Code
        SQLCommand = "ALTER TABLE poorman.outredeemapproved DROP COLUMN IF EXISTS Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemapproved ADD Tax_ID varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.outredeemapproved DROP COLUMN IF EXISTS External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemapproved ADD External_Account_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outredeemapproved as a SET Tax_ID = b.Tax_ID FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outredeemapproved as a SET External_Account_Code = b.External_Account_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise

# Create outgoing file for rejected redemptions
def outRedeemRejected():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        SQLCommand = "DROP TABLE IF EXISTS poorman.outredeemrejected"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "CREATE TABLE poorman.outredeemrejected AS SELECT *, EXTRACT (DAY FROM NOW() - interval '1 day') AS Batch_Day, EXTRACT (MONTH FROM NOW()) AS Batch_Month, EXTRACT (YEAR FROM NOW()) AS Batch_Year FROM poorman.redeemrejected"
        postgreSQLExecuteCommand(cur, SQLCommand)                
        SQLCommand = "ALTER TABLE poorman.outredeemrejected DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemrejected ADD Export int"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        if outgoingBatchCut == "day":
            SQLCommand = "UPDATE poorman.outredeemrejected SET Export = ( CASE WHEN (Date_Day = Batch_Day AND Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "month":
            SQLCommand = "UPDATE poorman.outredeemrejected SET Export = ( CASE WHEN (Date_Month = Batch_Month AND Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        elif outgoingBatchCut == "year":
            SQLCommand = "UPDATE poorman.outredeemrejected SET Export = ( CASE WHEN (Date_Year = Batch_YEAR) THEN 1 ELSE 0 END )"
        else:
            SQLCommand = "UPDATE poorman.outredeemrejected SET Export = 1"
        postgreSQLExecuteCommand(cur, SQLCommand)
      
        SQLCommand = "DELETE FROM poorman.outredeemrejected WHERE Export = 0"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemrejected DROP COLUMN IF EXISTS Export"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # Add Tax_ID and External Account Code
        SQLCommand = "ALTER TABLE poorman.outredeemrejected DROP COLUMN IF EXISTS Tax_ID"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemrejected ADD Tax_ID varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)   
        SQLCommand = "ALTER TABLE poorman.outredeemrejected DROP COLUMN IF EXISTS External_Account_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.outredeemrejected ADD External_Account_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outredeemrejected as a SET Tax_ID = b.Tax_ID FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.outredeemrejected as a SET External_Account_Code = b.External_Account_Code FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successOutFile()
    except:
        failOutFile()
        errorTerminationLog()
        raise

# Create list of redeemable points
def listRedeemable():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        # consolidate points bank per user
        SQLCommand = "DROP TABLE IF EXISTS poorman.listredeemable"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "CREATE TABLE poorman.listredeemable AS SELECT Corp_Code, Program_Code, User_Code, SUM(Points) AS Points, EXTRACT (DAY FROM NOW()) AS Date_Day, EXTRACT (MONTH FROM NOW()) AS Date_Month, EXTRACT (YEAR FROM NOW()) AS Date_Year FROM poorman.pointsbank GROUP BY Corp_Code, Program_Code, User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # get active program and active user
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeem_Currency_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Redeem_Currency_Code varchar"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Currency_per_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Currency_per_Points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Active_Program"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Active_Program int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeem_Min_points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Redeem_Min_points float8"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.listredeemable as a SET Redeem_Currency_Code = b.Redeem_Currency_Code, Currency_per_Points = b.Currency_per_Points, Active_Program = b.Active_Program, Redeem_Min_points = b.Redeem_Min_points FROM poorman.programattrib as b WHERE a.Program_Code = b.Program_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Active_User"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Active_User int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.listredeemable as a SET Active_User = b.Active_User FROM poorman.userprofile as b WHERE a.User_Code = b.User_Code"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # list available
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeemable"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Redeemable int"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "UPDATE poorman.listredeemable SET Redeemable = ( CASE WHEN (Points > 0 AND Active_Program = 1 AND Active_User = 1 AND Points > Redeem_Min_points ) THEN 1 ELSE 0 END )"
        postgreSQLExecuteCommand(cur, SQLCommand)

        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeem_Value"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable ADD Redeem_Value float8"
        postgreSQLExecuteCommand(cur, SQLCommand)        
        SQLCommand = "UPDATE poorman.listredeemable SET Redeem_Value = Points * Currency_per_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # select only redeemable
        SQLCommand = "DELETE FROM poorman.listredeemable WHERE Redeemable = 0"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # prepare table format
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Currency_per_Points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Active_Program"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeem_Min_points"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Active_User"
        postgreSQLExecuteCommand(cur, SQLCommand)
        SQLCommand = "ALTER TABLE poorman.listredeemable DROP COLUMN IF EXISTS Redeemable"
        postgreSQLExecuteCommand(cur, SQLCommand)

        # round currency
        SQLCommand = "UPDATE poorman.listredeemable SET Redeem_Value = round(cast(Redeem_Value as numeric)," + str(currencyDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)
        # round points
        SQLCommand = "UPDATE poorman.listredeemable SET Points = round(cast(Points as numeric)," + str(pointsDecimals) + ")"
        postgreSQLExecuteCommand(cur, SQLCommand)

        postgreSQLClose(conn, cur)
        successListRedeemable()
    except:
        failListRedeemable()
        errorTerminationLog()
        raise

# Back-up files - runs before processing
def batchBackup():
    try:
        if not os.path.exists('backup_previous_batch'):
            os.makedirs('backup_previous_batch')
        if not os.path.exists('backup_previous_batch/Incoming'):
            os.makedirs('backup_previous_batch/Incoming')
        if not os.path.exists('backup_previous_batch/Outgoing'):
            os.makedirs('backup_previous_batch/Outgoing')
        # incoming files
        shutil.copyfile(incomingbatchFileDirectory + 'LoadPoints.csv', 'backup_previous_batch/Incoming/LoadPoints.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'RedeemPoints.csv', 'backup_previous_batch/Incoming/RedeemPoints.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'AddUserProfile.csv', 'backup_previous_batch/Incoming/AddUserProfile.csv')
        shutil.copyfile(incomingbatchFileDirectory + 'UpdateUserProfile.csv', 'backup_previous_batch/Incoming/UpdateUserProfile.csv')
        # outgoing files
        if os.path.isfile(outgoingbatchFileDirectory + 'OutAddedPoints.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutAddedPoints.csv', 'backup_previous_batch/Outgoing/OutAddedPoints.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutExpiredPoints.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutExpiredPoints.csv', 'backup_previous_batch/Outgoing/OutExpiredPoints.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutRedeemApproved.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutRedeemApproved.csv', 'backup_previous_batch/Outgoing/OutRedeemApproved.csv')
        if os.path.isfile(outgoingbatchFileDirectory + 'OutRedeemRejected.csv'):
            shutil.copyfile(outgoingbatchFileDirectory + 'OutRedeemRejected.csv', 'backup_previous_batch/Outgoing/OutRedeemRejected.csv')
        successBatchBackup()
    except:
        failBatchBackup()
        errorTerminationLog()
        raise

# Export routine - runs after processing
def batchExport():
    try:
        conn, cur = postgreSQLConnect(postgreSQL_dic)

        # load updated SQL databases in memory
        addUserDF = readAddUserPostgreSQL()
        updateUserDF = readUpdateUserPostgreSQL()
        loadPointsDF = readLoadPointsPostgreSQL()
        redeemPointsDF = readRedeemPointsPostgreSQL()

        outAddedPointsDF = readoutAddedPointsPostgreSQL()
        outExpiredPointsDF = readoutExpiredPointsPostgreSQL()
        outRedeemApprovedDF = readoutRedeemApprovedPostgreSQL()
        outRedeemRejectedDF = readoutRedeemRejectedPostgreSQL()

        # incoming files
        loadPointsDF.to_csv(incomingbatchFileDirectory + "LoadPoints.csv", index = False)
        redeemPointsDF.to_csv(incomingbatchFileDirectory + "RedeemPoints.csv", index = False)
        addUserDF.to_csv(incomingbatchFileDirectory + "AddUserProfile.csv", index = False)
        updateUserDF.to_csv(incomingbatchFileDirectory + "UpdateUserProfile.csv", index = False)
        # outgoing files
        outAddedPointsDF.to_csv(outgoingbatchFileDirectory + "OutAddedPoints.csv", index = False)
        outExpiredPointsDF.to_csv(outgoingbatchFileDirectory + "OutExpiredPoints.csv", index = False)
        outRedeemApprovedDF.to_csv(outgoingbatchFileDirectory + "OutRedeemApproved.csv", index = False)
        outRedeemRejectedDF.to_csv(outgoingbatchFileDirectory + "OutRedeemRejected.csv", index = False)

        postgreSQLClose(conn, cur)
        successBatchExport()
    except:
        failBatchExport()
        errorTerminationLog()
        raise