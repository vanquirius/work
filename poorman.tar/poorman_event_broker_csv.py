# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-16
# Event broker module - csv version

from poorman_points_engine_csv import *
from poorman_email import *
from poorman_sms import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# Send welcome message to new users
def sendWelcomeQueue(welcomeUserQueueDF):
    try:
        if welcomeUserQueueDF.empty == False: 
            # get amount of rows in queue
            welcomeIndex = welcomeUserQueueDF.index
            welcomeRows = len(welcomeIndex)

            # loop through queue
            for queueNumber in range(0, welcomeRows):
                userCode = welcomeUserQueueDF.iloc[queueNumber]['User_Code']
                activeUser = welcomeUserQueueDF.iloc[queueNumber]['Active_User']
                activeUserEmail = welcomeUserQueueDF.iloc[queueNumber]['Active_Email']
                activeUserMobile = welcomeUserQueueDF.iloc[queueNumber]['Active_Mobile']

                # send e-mail
                if activeUser == 1 & activeUserEmail == 1 & sendWelcomeEmail == 1:
                    userEmail = welcomeUserQueueDF.iloc[queueNumber]['User_Email']
                    mailTo = userEmail
                    mailSubject = "Welcome User " + str(userCode) + " to Poorman's Payback!!!"
                    mailContent = "User " + str(userCode) + ", welcome to the coolest payback program on the market!"
                    sendSingleEmail(mailSubject, mailContent, mailTo)
            
                # send SMS
                if activeUser == 1 & activeUserMobile == 1 & sendWelcomeSMS == 1:
                    areaCode = welcomeUserQueueDF.iloc[queueNumber]['User_Mobile_Area_Code']
                    phoneNumber = welcomeUserQueueDF.iloc[queueNumber]['User_Mobile_Phone_Number']
                    sendSingleSMS(smsText, areaCode, phoneNumber)

            # empty out queue
            welcomeUserQueueDF = pandas.DataFrame(columns=welcomeUserQueueDF.columns)

        successSendWelcomeQueue()
    except:
        failSendWelcomeQueue()
        errorTerminationLog()
        raise
    return welcomeUserQueueDF

# Create and control mail list for users with redeemable points
def manageRedeemable(listRedeemableDF, redeemableSentDF, currencyNamesDF, userProfileDF):
    try:
        if listRedeemableDF.empty == False:
            # load new list, compare against previously sent list
            del redeemableSentDF['Points2']
            redeemableSentDF.rename(columns={'Points': 'Points2'}, inplace=True)
            listRedeemableDF = listRedeemableDF.merge(redeemableSentDF[['User_Code','Token_Code','Token_Sent','Points2']], how='left')
            currencyNamesDF.rename(columns={'Currency_Code': 'Redeem_Currency_Code'}, inplace=True)
            listRedeemableDF = listRedeemableDF.merge(currencyNamesDF[['Redeem_Currency_Code','Currency_Name']], how='left')
            listRedeemableDF = listRedeemableDF.merge(userProfileDF[['User_Code','Active_Email','Active_Mobile','User_Email','User_Mobile_Area_Code','User_Mobile_Phone_Number','User_Mobile_Country_Code']], how='left')
             
            # if there is a change in points, create a new token and set sent to 0
            # get amount of rows in queue
            listIndex = listRedeemableDF.index
            listRows = len(listIndex)

            # loop through queue
            for queueNumber in range(0, listRows):
                userCode = listRedeemableDF.iloc[queueNumber]['User_Code']
                points = listRedeemableDF.iloc[queueNumber]['Points']
                points2 = listRedeemableDF.iloc[queueNumber]['Points2']
                tokenCode = listRedeemableDF.iloc[queueNumber]['Token_Code']
                tokenSent = listRedeemableDF.iloc[queueNumber]['Token_Sent']

                if points != points2:
                    listRedeemableDF.iloc[queueNumber, listRedeemableDF.columns.get_loc('Token_Code')] = str(userCode) + "-" + str(secrets.token_urlsafe(16))
                    listRedeemableDF.iloc[queueNumber, listRedeemableDF.columns.get_loc('Token_Sent')] = 0
                                
            successManageRedeemable()
    except:
        failManageRedeemable()
        errorTerminationLog()
        raise
    return listRedeemableDF

# Send communication to users with redeemable points that have not been sent this before
def sendRedeemable(redeemableSentDF):
    try:
        if redeemableSentDF.empty == False:

            # get amount of rows in queue
            listIndex = redeemableSentDF.index
            listRows = len(listIndex)

            # loop through queue
            for queueNumber in range(0, listRows):
                userCode = redeemableSentDF.iloc[queueNumber]['User_Code']
                activeUserEmail = redeemableSentDF.iloc[queueNumber]['Active_Email']
                activeUserMobile = redeemableSentDF.iloc[queueNumber]['Active_Mobile']
                points = redeemableSentDF.iloc[queueNumber]['Points']
                value = redeemableSentDF.iloc[queueNumber]['Redeem_Value']
                currencyName = redeemableSentDF.iloc[queueNumber]['Currency_Name']
                tokenCode = redeemableSentDF.iloc[queueNumber]['Token_Code']
                tokenSent = redeemableSentDF.iloc[queueNumber]['Token_Sent']

                # send e-mail
                if (activeUserEmail == 1) & (tokenSent == 0):
                    userEmail = redeemableSentDF.iloc[queueNumber]['User_Email']
                    mailTo = userEmail
                    mailSubject = "Redeem " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " + str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals)))
                    mailContent = "User " + str(userCode) + ", you are now able to exchange " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " +  str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals))) + ". Please click on the link to make your request: " + str(domainLink) + ":" + str(redeemPort) + "/api/redeem/request?token=" + str(tokenCode)
                    sendSingleEmail(mailSubject, mailContent, mailTo)
            
                # send SMS
                if (activeUserMobile == 1) & (tokenSent == 0):
                    areaCode = redeemableSentDF.iloc[queueNumber]['User_Mobile_Area_Code']
                    phoneNumber = redeemableSentDF.iloc[queueNumber]['User_Mobile_Phone_Number']
                    smsText = "Exchange " + str('{:.0f}'.format(round(points, displayPointsDecimals))) + " points for " +  str(currencyName) + " " + str('{:.2f}'.format(round(value,currencyDecimals))) + ". Link: " + str(domainLink) + ":" + str(redeemPort) + "/api/redeem/request?token=" + str(tokenCode)
                    sendSingleSMS(smsText, areaCode, phoneNumber)

            # mark list as sent
            redeemableSentDF['Token_Sent'] = 1
           
            successSendRedeemable()
    except:
        failSendRedeemable()
        errorTerminationLog()
        raise
    return redeemableSentDF

# Back-up files - runs before processing
def batchBackup():
    try:
        if not os.path.exists('backup_previous_batch'):
            os.makedirs('backup_previous_batch')
        # core files
        shutil.copyfile('WelcomeUserQueue.csv', 'backup_previous_batch/WelcomeUserQueue.csv')
        shutil.copyfile('ReedemableSent.csv', 'backup_previous_batch/ReedemableSent.csv')
        successBatchBackup()
    except:
        failBatchBackup()
        errorTerminationLog()
        raise

# Export routine - runs after processing
def batchExport(welcomeUserQueueDF, redeemableSentDF):
    try:
        # core files
        welcomeUserQueueDF.to_csv("WelcomeUserQueue.csv", index = False)
        redeemableSentDF.to_csv("ReedemableSent.csv", index = False)
        successBatchExport()
    except:
        failBatchExport()
        errorTerminationLog()
        raise