# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-13
# PostgreSQL module to migrate existing csv data to new tables

from poorman_postgresql import *
from poorman_points_engine_csv import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# CorpNames
def migrateCorpNamesPostgreSQL(corpNamesDF):
    # wipe table clean
    tablename = "corpnames"
    fieldnames = "(Corp_Code, Corp_Name)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    corpNamesDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in corpNamesDF.index:
        corpcode = str(corpNamesDF.iloc[i]['Corp_Code'])
        corpname = str(corpNamesDF.iloc[i]['Corp_Name'])
        values = corpcode + "', '" + corpname
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');" 
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# CountryCodes
def migrateCountryCodesPostgreSQL(countryCodesDF):
    # wipe table clean
    tablename = "countrycodes"
    fieldnames = "(Country_Code, Country_Name)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    countryCodesDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in countryCodesDF.index:
        countrycode = str(countryCodesDF.iloc[i]['Country_Code'])
        countryname = str(countryCodesDF.iloc[i]['Country_Name'])
        values = countrycode + "', '" + countryname
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# CurrencyNames
def migrateCurrencyNamesPostgreSQL(currencyNamesDF):
    # wipe table clean
    tablename = "currencynames"
    fieldnames = "(Currency_Code, Currency_Name)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    currencyNamesDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in currencyNamesDF.index:
        currencycode = str(currencyNamesDF.iloc[i]['Currency_Code'])
        currencyname = str(currencyNamesDF.iloc[i]['Currency_Name'])
        values = currencycode + "', '" + currencyname
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ProductNames
def migrateProductNamesPostgreSQL(productNamesDF):
    # wipe table clean
    tablename = "productnames"
    fieldnames = "(Product_Code, Product_Name)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    productNamesDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in productNamesDF.index:
        productcode = str(productNamesDF.iloc[i]['Product_Code'])
        productname = str(productNamesDF.iloc[i]['Product_Name'])
        values = productcode + "', '" + productname
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ProgramNames
def migrateProgramNamesPostgreSQL(programNamesDF):
    # wipe table clean
    tablename = "programnames"
    fieldnames = "(Program_Code, Program_Name)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    programNamesDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in programNamesDF.index:
        programcode = str(programNamesDF.iloc[i]['Program_Code'])
        programname = str(programNamesDF.iloc[i]['Program_Name'])
        values = programcode + "', '" + programname
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ProgramSetup
def migrateProgramSetupPostgreSQL(programSetupDF):
    # wipe table clean
    tablename = "programsetup"
    fieldnames = "(Corp_Code, Country_Code, Program_Code, Currency_Code, Points_per_Currency, Expiration_Days)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    programSetupDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in programSetupDF.index:
        corpcode = str(programSetupDF.iloc[i]['Corp_Code'])
        countrycode = str(programSetupDF.iloc[i]['Country_Code'])
        programcode = str(programSetupDF.iloc[i]['Program_Code'])
        currencycode = str(programSetupDF.iloc[i]['Currency_Code'])
        pointspercurrency = str(programSetupDF.iloc[i]['Points_per_Currency'])
        expirationdays = str(programSetupDF.iloc[i]['Expiration_Days'])
        values = corpcode + "', '" + countrycode + "', '" + programcode + "', '" + currencycode + "', '" + pointspercurrency + "', '" + expirationdays
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ProgramAttrib
def migrateProgramAttribPostgreSQL(programAttribDF):
    # wipe table clean
    tablename = "programattrib"
    fieldnames = "(Program_Code, Active_Program, Redeem_Currency_Code, Currency_per_Points, Redeem_Min_points, Renew_Expiry_On_Purchase)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    programAttribDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in programAttribDF.index:
        programcode = str(programAttribDF.iloc[i]['Program_Code'])
        activeprogram = str(programAttribDF.iloc[i]['Active_Program'])
        redeemcurrencycode = str(programAttribDF.iloc[i]['Redeem_Currency_Code'])
        currencyperpoints = str(programAttribDF.iloc[i]['Currency_per_Points'])
        redeemminpoints = str(programAttribDF.iloc[i]['Redeem_Min_points'])
        renewexpiryonpurchase = str(programAttribDF.iloc[i]['Renew_Expiry_On_Purchase'])
        values = programcode + "', '" + activeprogram + "', '" + redeemcurrencycode + "', '" + currencyperpoints + "', '" + redeemminpoints + "', '" + renewexpiryonpurchase
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# UserProfile
def migrateUserProfilePostgreSQL(userProfileDF):
    # wipe table clean
    tablename = "userprofile"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    userProfileDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in userProfileDF.index:
        corpcode = str(userProfileDF.iloc[i]['Corp_Code'])
        programcode = str(userProfileDF.iloc[i]['Program_Code'])
        usercode = str(userProfileDF.iloc[i]['User_Code'])
        activeuser = str(userProfileDF.iloc[i]['Active_User'])
        useremail = str(userProfileDF.iloc[i]['User_Email'])
        usermobilecountrycode = str(userProfileDF.iloc[i]['User_Mobile_Country_Code'])
        usermobileareacode = str(userProfileDF.iloc[i]['User_Mobile_Area_Code'])
        usermobilephonenumber = str(userProfileDF.iloc[i]['User_Mobile_Phone_Number'])
        activeemail = str(userProfileDF.iloc[i]['Active_Email'])
        activemobile = str(userProfileDF.iloc[i]['Active_Mobile'])
        taxid = str(userProfileDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(userProfileDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# PointsBank
def migratePointsBankPostgreSQL(pointsBankDF):
    # wipe table clean
    tablename = "pointsbank"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    pointsBankDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in pointsBankDF.index:
        corpcode = str(pointsBankDF.iloc[i]['Corp_Code'])
        programcode = str(pointsBankDF.iloc[i]['Program_Code'])
        usercode = str(pointsBankDF.iloc[i]['User_Code'])
        points = str(pointsBankDF.iloc[i]['Points'])
        dateday = str(pointsBankDF.iloc[i]['Date_Day'])
        datemonth = str(pointsBankDF.iloc[i]['Date_Month'])
        dateyear = str(pointsBankDF.iloc[i]['Date_Year'])
        expirydateday = str(pointsBankDF.iloc[i]['Expiry_Date_Day'])
        expirydatemonth = str(pointsBankDF.iloc[i]['Expiry_Date_Month'])
        expirydateyear = str(pointsBankDF.iloc[i]['Expiry_Date_Year'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + expirydateday + "', '" + expirydatemonth + "', '" + expirydateyear
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# AddedPoints
def migrateAddedPointsPostgreSQL(addedPointsDF):
    # wipe table clean
    tablename = "addedpoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Currency_Code, Value, Points_per_Currency, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year, Added_ID)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    addedPointsDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in addedPointsDF.index:
        corpcode = str(addedPointsDF.iloc[i]['Corp_Code'])
        programcode = str(addedPointsDF.iloc[i]['Program_Code'])
        usercode = str(addedPointsDF.iloc[i]['User_Code'])
        points = str(addedPointsDF.iloc[i]['Points'])
        currencycode = str(addedPointsDF.iloc[i]['Currency_Code'])
        value = str(addedPointsDF.iloc[i]['Value'])
        pointspercurrency = str(addedPointsDF.iloc[i]['Points_per_Currency'])
        dateday = str(addedPointsDF.iloc[i]['Date_Day'])
        datemonth = str(addedPointsDF.iloc[i]['Date_Month'])
        dateyear = str(addedPointsDF.iloc[i]['Date_Year'])
        expirydateday = str(addedPointsDF.iloc[i]['Expiry_Date_Day'])
        expirydatemonth = str(addedPointsDF.iloc[i]['Expiry_Date_Month'])
        expirydateyear = str(addedPointsDF.iloc[i]['Expiry_Date_Year'])
        addedid = str(addedPointsDF.iloc[i]['Added_ID'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + currencycode + "', '" + value + "', '" + pointspercurrency + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + expirydateday + "', '" + expirydatemonth + "', '" + expirydateyear + "', '" + addedid
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ExpiredPoints
def migrateExpiredPointsPostgreSQL(expiredPointsDF):
    # wipe table clean
    tablename = "expiredpoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year, Expiry_ID)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    expiredPointsDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in expiredPointsDF.index:
        corpcode = str(expiredPointsDF.iloc[i]['Corp_Code'])
        programcode = str(expiredPointsDF.iloc[i]['Program_Code'])
        usercode = str(expiredPointsDF.iloc[i]['User_Code'])
        points = str(expiredPointsDF.iloc[i]['Points'])
        dateday = str(expiredPointsDF.iloc[i]['Date_Day'])
        datemonth = str(expiredPointsDF.iloc[i]['Date_Month'])
        dateyear = str(expiredPointsDF.iloc[i]['Date_Year'])
        expirydateday = str(expiredPointsDF.iloc[i]['Expiry_Date_Day'])
        expirydatemonth = str(expiredPointsDF.iloc[i]['Expiry_Date_Month'])
        expirydateyear = str(expiredPointsDF.iloc[i]['Expiry_Date_Year'])
        expiryid = str(expiredPointsDF.iloc[i]['Expiry_ID'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + expirydateday + "', '" + expirydatemonth + "', '" + expirydateyear + "', '" + expiryid
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# RedeemApproved
def migrateRedeemApprovedPostgreSQL(redeemApprovedDF):
    # wipe table clean
    tablename = "redeemapproved"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value, Approval_ID)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    redeemApprovedDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in redeemApprovedDF.index:
        corpcode = str(redeemApprovedDF.iloc[i]['Corp_Code'])
        programcode = str(redeemApprovedDF.iloc[i]['Program_Code'])
        usercode = str(redeemApprovedDF.iloc[i]['User_Code'])
        points = str(redeemApprovedDF.iloc[i]['Points'])
        dateday = str(redeemApprovedDF.iloc[i]['Date_Day'])
        datemonth = str(redeemApprovedDF.iloc[i]['Date_Month'])
        dateyear = str(redeemApprovedDF.iloc[i]['Date_Year'])
        redeemcurrencycode = str(redeemApprovedDF.iloc[i]['Redeem_Currency_Code'])
        redeemvalue = str(redeemApprovedDF.iloc[i]['Redeem_Value'])
        approvalid = str(redeemApprovedDF.iloc[i]['Approval_ID'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue + "', '" + approvalid
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# RedeemRejected
def migrateRedeemRejectedPostgreSQL(redeemRejectedDF):
    # wipe table clean
    tablename = "redeemrejected"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value, Rejected_ID)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    redeemRejectedDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in redeemRejectedDF.index:
        corpcode = str(redeemRejectedDF.iloc[i]['Corp_Code'])
        programcode = str(redeemRejectedDF.iloc[i]['Program_Code'])
        usercode = str(redeemRejectedDF.iloc[i]['User_Code'])
        points = str(redeemRejectedDF.iloc[i]['Points'])
        dateday = str(redeemRejectedDF.iloc[i]['Date_Day'])
        datemonth = str(redeemRejectedDF.iloc[i]['Date_Month'])
        dateyear = str(redeemRejectedDF.iloc[i]['Date_Year'])
        redeemcurrencycode = str(redeemRejectedDF.iloc[i]['Redeem_Currency_Code'])
        redeemvalue = str(redeemRejectedDF.iloc[i]['Redeem_Value'])
        rejectedid = str(redeemRejectedDF.iloc[i]['Rejected_ID'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue + "', '" + rejectedid
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# ListRedeemable
def migrateListRedeemablePostgreSQL(listRedeemableDF):
    # wipe table clean
    tablename = "listredeemable"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    listRedeemableDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in listRedeemableDF.index:
        corpcode = str(listRedeemableDF.iloc[i]['Corp_Code'])
        programcode = str(listRedeemableDF.iloc[i]['Program_Code'])
        usercode = str(listRedeemableDF.iloc[i]['User_Code'])
        points = str(listRedeemableDF.iloc[i]['Points'])
        dateday = str(listRedeemableDF.iloc[i]['Date_Day'])
        datemonth = str(listRedeemableDF.iloc[i]['Date_Month'])
        dateyear = str(listRedeemableDF.iloc[i]['Date_Year'])
        redeemcurrencycode = str(listRedeemableDF.iloc[i]['Redeem_Currency_Code'])
        redeemvalue = str(listRedeemableDF.iloc[i]['Redeem_Value'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# RedeemableSent
def migrateRedeemableSentPostgreSQL(redeemableSentDF):
    # wipe table clean
    tablename = "redeemablesent"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value, Token_Code, Token_Sent, Points2, Currency_Name, Active_Email, Active_Mobile, User_Email, User_Mobile_Area_Code, User_Mobile_Phone_Number, User_Mobile_Country_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    redeemableSentDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in redeemableSentDF.index:
        corpcode = str(redeemableSentDF.iloc[i]['Corp_Code'])
        programcode = str(redeemableSentDF.iloc[i]['Program_Code'])
        usercode = str(redeemableSentDF.iloc[i]['User_Code'])
        points = str(redeemableSentDF.iloc[i]['Points'])
        dateday = str(redeemableSentDF.iloc[i]['Date_Day'])
        datemonth = str(redeemableSentDF.iloc[i]['Date_Month'])
        dateyear = str(redeemableSentDF.iloc[i]['Date_Year'])
        redeemcurrencycode = str(redeemableSentDF.iloc[i]['Redeem_Currency_Code'])
        redeemvalue = str(redeemableSentDF.iloc[i]['Redeem_Value'])
        tokencode = str(redeemableSentDF.iloc[i]['Token_Code'])
        tokensent = str(redeemableSentDF.iloc[i]['Token_Sent'])
        points2 = str(redeemableSentDF.iloc[i]['Points2'])
        currencyname = str(redeemableSentDF.iloc[i]['Currency_Name'])
        activeemail = str(redeemableSentDF.iloc[i]['Active_Email'])
        activemobile = str(redeemableSentDF.iloc[i]['Active_Mobile'])
        useremail = str(redeemableSentDF.iloc[i]['User_Email'])
        usermobileareacode = str(redeemableSentDF.iloc[i]['User_Mobile_Area_Code'])
        usermobilephonenumber = str(redeemableSentDF.iloc[i]['User_Mobile_Phone_Number'])
        usermobilecountrycode = str(redeemableSentDF.iloc[i]['User_Mobile_Country_Code'])
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue + "', '" + tokencode + "', '" + tokensent + "', '" + points2 + "', '" + currencyname + "', '" + activeemail + "', '" + activemobile + "', '" + useremail + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + usermobilecountrycode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# WelcomeUserQueue
def migrateWelcomeUserQueuePostgreSQL(welcomeUserQueueDF):
    # wipe table clean
    tablename = "welcomeuserqueue"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    welcomeUserQueueDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in welcomeUserQueueDF.index:
        corpcode = str(welcomeUserQueueDF.iloc[i]['Corp_Code'])
        programcode = str(welcomeUserQueueDF.iloc[i]['Program_Code'])
        usercode = str(welcomeUserQueueDF.iloc[i]['User_Code'])
        activeuser = str(welcomeUserQueueDF.iloc[i]['Active_User'])
        useremail = str(welcomeUserQueueDF.iloc[i]['User_Email'])
        usermobilecountrycode = str(welcomeUserQueueDF.iloc[i]['User_Mobile_Country_Code'])
        usermobileareacode = str(welcomeUserQueueDF.iloc[i]['User_Mobile_Area_Code'])
        usermobilephonenumber = str(welcomeUserQueueDF.iloc[i]['User_Mobile_Phone_Number'])
        activeemail = str(welcomeUserQueueDF.iloc[i]['Active_Email'])
        activemobile = str(welcomeUserQueueDF.iloc[i]['Active_Mobile'])
        taxid = str(welcomeUserQueueDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(welcomeUserQueueDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# AddUserProfile
def migrateAddUserPostgreSQL(addUserDF):
    # wipe table clean
    tablename = "adduserprofile"
    fieldnames = "(Corp_Code, Program_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    addUserDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in addUserDF.index:
        corpcode = str(addUserDF.iloc[i]['Corp_Code'])
        programcode = str(addUserDF.iloc[i]['Program_Code'])
        activeuser = str(addUserDF.iloc[i]['Active_User'])
        useremail = str(addUserDF.iloc[i]['User_Email'])
        usermobilecountrycode = str(addUserDF.iloc[i]['User_Mobile_Country_Code'])
        usermobileareacode = str(addUserDF.iloc[i]['User_Mobile_Area_Code'])
        usermobilephonenumber = str(addUserDF.iloc[i]['User_Mobile_Phone_Number'])
        activeemail = str(addUserDF.iloc[i]['Active_Email'])
        activemobile = str(addUserDF.iloc[i]['Active_Mobile'])
        taxid = str(addUserDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(addUserDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        values = corpcode + "', '" + programcode + "', '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# UpdateUserProfile
def migrateUpdateUserPostgreSQL(updateUserDF):
    # wipe table clean
    tablename = "updateuserprofile"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    updateUserDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in updateUserDF.index:
        corpcode = str(updateUserDF.iloc[i]['Corp_Code'])
        programcode = str(updateUserDF.iloc[i]['Program_Code'])
        usercode = str(updateUserDF.iloc[i]['User_Code'])
        # special to handle null values (pandas calls nan, SQL does not understand)
        if usercode == "nan":
            usercode = "NULL"
        activeuser = str(updateUserDF.iloc[i]['Active_User'])
        useremail = str(updateUserDF.iloc[i]['User_Email'])
        usermobilecountrycode = str(updateUserDF.iloc[i]['User_Mobile_Country_Code'])
        usermobileareacode = str(updateUserDF.iloc[i]['User_Mobile_Area_Code'])
        usermobilephonenumber = str(updateUserDF.iloc[i]['User_Mobile_Phone_Number'])
        activeemail = str(updateUserDF.iloc[i]['Active_Email'])
        activemobile = str(updateUserDF.iloc[i]['Active_Mobile'])
        taxid = str(updateUserDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(updateUserDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        # special quote below in usercode to handle null values
        values = corpcode + "', '" + programcode + "', " + usercode + ", '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# LoadPoints
def migrateLoadPointsPostgreSQL(loadPointsDF):
    # wipe table clean
    tablename = "loadpoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Currency_Code, Value, Date_Day, Date_Month, Date_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    loadPointsDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in loadPointsDF.index:
        corpcode = str(loadPointsDF.iloc[i]['Corp_Code'])
        programcode = str(loadPointsDF.iloc[i]['Program_Code'])
        usercode = str(loadPointsDF.iloc[i]['User_Code'])
        # special to handle null values (pandas calls nan, SQL does not understand)
        if usercode == "nan":
            usercode = "NULL"
        currencycode = str(loadPointsDF.iloc[i]['Currency_Code'])
        value = str(loadPointsDF.iloc[i]['Value'])
        dateday = str(loadPointsDF.iloc[i]['Date_Day'])
        datemonth = str(loadPointsDF.iloc[i]['Date_Month'])
        dateyear = str(loadPointsDF.iloc[i]['Date_Year'])
        taxid = str(loadPointsDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(loadPointsDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        # special quote below in usercode to handle null values
        values = corpcode + "', '" + programcode + "', " + usercode + ", '" + currencycode + "', '" + value + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# RedeemPoints
def migrateRedeemPointsPostgreSQL(redeemPointsDF):
    # wipe table clean
    tablename = "redeempoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    postgreSQLExecuteCommand(cur, SQLCommand)
    redeemPointsDF.reset_index(drop=True, inplace=True)
    # populate from csv file
    for i in redeemPointsDF.index:
        corpcode = str(redeemPointsDF.iloc[i]['Corp_Code'])
        programcode = str(redeemPointsDF.iloc[i]['Program_Code'])
        usercode = str(redeemPointsDF.iloc[i]['User_Code'])
        # special to handle null values (pandas calls nan, SQL does not understand)
        if usercode == "nan":
            usercode = "NULL"
        points = str(redeemPointsDF.iloc[i]['Points'])
        dateday = str(redeemPointsDF.iloc[i]['Date_Day'])
        datemonth = str(redeemPointsDF.iloc[i]['Date_Month'])
        dateyear = str(redeemPointsDF.iloc[i]['Date_Year'])
        # special to handle null values (pandas calls nan, SQL does not understand)
        taxid = str(redeemPointsDF.iloc[i]['Tax_ID'])
        if taxid == "nan":
            taxid = "NULL"
        externalaccountcode = str(redeemPointsDF.iloc[i]['External_Account_Code'])
        if externalaccountcode == "nan":
            externalaccountcode = "NULL"
        # special quote below in usercode to handle null values
        values = corpcode + "', '" + programcode + "', " + usercode + ", '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "',  " + taxid + ", " + externalaccountcode
        SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
        postgreSQLExecuteCommand(cur, SQLCommand)
    postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# OutAddedPoints
def migrateoutAddedPointsPostgreSQL(outAddedPointsDF):
    # wipe table clean
    tablename = "outaddedpoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Currency_Code, Value, Points_per_Currency, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year, Added_ID, Batch_Day, Batch_Month, Batch_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    if outAddedPointsDF.empty == False:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        postgreSQLExecuteCommand(cur, SQLCommand)
        outAddedPointsDF.reset_index(drop=True, inplace=True)
        # populate from csv file
        for i in outAddedPointsDF.index:
            corpcode = str(outAddedPointsDF.iloc[i]['Corp_Code'])
            programcode = str(outAddedPointsDF.iloc[i]['Program_Code'])
            usercode = str(outAddedPointsDF.iloc[i]['User_Code'])
            points = str(outAddedPointsDF.iloc[i]['Points'])
            currencycode = str(outAddedPointsDF.iloc[i]['Currency_Code'])
            value = str(outAddedPointsDF.iloc[i]['Value'])
            pointspercurrency = str(outAddedPointsDF.iloc[i]['Points_per_Currency'])
            dateday = str(outAddedPointsDF.iloc[i]['Date_Day'])
            datemonth = str(outAddedPointsDF.iloc[i]['Date_Month'])
            dateyear = str(outAddedPointsDF.iloc[i]['Date_Year'])
            expirydateday = str(outAddedPointsDF.iloc[i]['Expiry_Date_Day'])
            expirydatemonth = str(outAddedPointsDF.iloc[i]['Expiry_Date_Month'])
            expirydateyear = str(outAddedPointsDF.iloc[i]['Expiry_Date_Year'])
            addedid = str(outAddedPointsDF.iloc[i]['Added_ID'])
            batchdateday = str(outAddedPointsDF.iloc[i]['Batch_Day'])
            batchdatemonth = str(outAddedPointsDF.iloc[i]['Batch_Month'])
            batchdateyear = str(outAddedPointsDF.iloc[i]['Batch_Year'])
            taxid = str(outAddedPointsDF.iloc[i]['Tax_ID'])
            if taxid == "nan":
                taxid = "NULL"
            externalaccountcode = str(outAddedPointsDF.iloc[i]['External_Account_Code'])
            if externalaccountcode == "nan":
                externalaccountcode = "NULL"
            values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + currencycode + "', '" + value + "', '" + pointspercurrency + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + expirydateday + "', '" + expirydatemonth + "', '" + expirydateyear + "', '" + addedid + "', '" + batchdateday + "', '" + batchdatemonth + "', '" + batchdateyear + "', " + taxid + ", " + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
            postgreSQLExecuteCommand(cur, SQLCommand)
        postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# OutExpiredPoints
def migrateoutExpiredPointsPostgreSQL(outExpiredPointsDF):
    # wipe table clean
    tablename = "outexpiredpoints"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Expiry_Date_Day, Expiry_Date_Month, Expiry_Date_Year, Expiry_ID, Batch_Day, Batch_Month, Batch_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    if outExpiredPointsDF.empty == False:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        postgreSQLExecuteCommand(cur, SQLCommand)
        outExpiredPointsDF.reset_index(drop=True, inplace=True)
        # populate from csv file
        for i in outExpiredPointsDF.index:
            corpcode = str(outExpiredPointsDF.iloc[i]['Corp_Code'])
            programcode = str(outExpiredPointsDF.iloc[i]['Program_Code'])
            usercode = str(outExpiredPointsDF.iloc[i]['User_Code'])
            points = str(outExpiredPointsDF.iloc[i]['Points'])
            dateday = str(outExpiredPointsDF.iloc[i]['Date_Day'])
            datemonth = str(outExpiredPointsDF.iloc[i]['Date_Month'])
            dateyear = str(outExpiredPointsDF.iloc[i]['Date_Year'])
            expirydateday = str(outExpiredPointsDF.iloc[i]['Expiry_Date_Day'])
            expirydatemonth = str(outExpiredPointsDF.iloc[i]['Expiry_Date_Month'])
            expirydateyear = str(outExpiredPointsDF.iloc[i]['Expiry_Date_Year'])
            expiryid = str(outExpiredPointsDF.iloc[i]['Expiry_ID'])
            batchdateday = str(outExpiredPointsDF.iloc[i]['Batch_Day'])
            batchdatemonth = str(outExpiredPointsDF.iloc[i]['Batch_Month'])
            batchdateyear = str(outExpiredPointsDF.iloc[i]['Batch_Year'])
            taxid = str(outExpiredPointsDF.iloc[i]['Tax_ID'])
            if taxid == "nan":
                taxid = "NULL"
            externalaccountcode = str(outExpiredPointsDF.iloc[i]['External_Account_Code'])
            if externalaccountcode == "nan":
                externalaccountcode = "NULL"
            values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + expirydateday + "', '" + expirydatemonth + "', '" + expirydateyear + "', '" + expiryid + "', '" + batchdateday + "', '" + batchdatemonth + "', '" + batchdateyear + "', " + taxid + ", " + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
            postgreSQLExecuteCommand(cur, SQLCommand)
        postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# OutRedeemApproved
def migrateoutRedeemApprovedPostgreSQL(outRedeemApprovedDF):
    # wipe table clean
    tablename = "outredeemapproved"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value, Approval_ID, Batch_Day, Batch_Month, Batch_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    if outRedeemApprovedDF.empty == False:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        postgreSQLExecuteCommand(cur, SQLCommand)
        outRedeemApprovedDF.reset_index(drop=True, inplace=True)
        # populate from csv file
        for i in outRedeemApprovedDF.index:
            corpcode = str(outRedeemApprovedDF.iloc[i]['Corp_Code'])
            programcode = str(outRedeemApprovedDF.iloc[i]['Program_Code'])
            usercode = str(outRedeemApprovedDF.iloc[i]['User_Code'])
            points = str(outRedeemApprovedDF.iloc[i]['Points'])
            dateday = str(outRedeemApprovedDF.iloc[i]['Date_Day'])
            datemonth = str(outRedeemApprovedDF.iloc[i]['Date_Month'])
            dateyear = str(outRedeemApprovedDF.iloc[i]['Date_Year'])
            redeemcurrencycode = str(outRedeemApprovedDF.iloc[i]['Redeem_Currency_Code'])
            redeemvalue = str(outRedeemApprovedDF.iloc[i]['Redeem_Value'])
            approvalid = str(outRedeemApprovedDF.iloc[i]['Approval_ID'])
            batchdateday = str(outRedeemApprovedDF.iloc[i]['Batch_Day'])
            batchdatemonth = str(outRedeemApprovedDF.iloc[i]['Batch_Month'])
            batchdateyear = str(outRedeemApprovedDF.iloc[i]['Batch_Year'])
            taxid = str(outRedeemApprovedDF.iloc[i]['Tax_ID'])
            if taxid == "nan":
                taxid = "NULL"
            externalaccountcode = str(outRedeemApprovedDF.iloc[i]['External_Account_Code'])
            if externalaccountcode == "nan":
                externalaccountcode = "NULL"
            values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue + "', '" + approvalid + "', '" + batchdateday + "', '" + batchdatemonth + "', '" + batchdateyear + "', " + taxid + ", " + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
            postgreSQLExecuteCommand(cur, SQLCommand)
        postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")

# OutRedeemRejected
def migrateoutRedeemRejectedPostgreSQL(outRedeemRejectedDF):
    # wipe table clean
    tablename = "outredeemrejected"
    fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Redeem_Currency_Code, Redeem_Value, Rejected_ID, Batch_Day, Batch_Month, Batch_Year, Tax_ID, External_Account_Code)"
    SQLCommand = "DELETE FROM poorman." + tablename
    if outRedeemRejectedDF.empty == False:
        conn, cur = postgreSQLConnect(postgreSQL_dic)
        postgreSQLExecuteCommand(cur, SQLCommand)
        outRedeemRejectedDF.reset_index(drop=True, inplace=True)
        # populate from csv file
        for i in outRedeemRejectedDF.index:
            corpcode = str(outRedeemRejectedDF.iloc[i]['Corp_Code'])
            programcode = str(outRedeemRejectedDF.iloc[i]['Program_Code'])
            usercode = str(outRedeemRejectedDF.iloc[i]['User_Code'])
            points = str(outRedeemRejectedDF.iloc[i]['Points'])
            dateday = str(outRedeemRejectedDF.iloc[i]['Date_Day'])
            datemonth = str(outRedeemRejectedDF.iloc[i]['Date_Month'])
            dateyear = str(outRedeemRejectedDF.iloc[i]['Date_Year'])
            redeemcurrencycode = str(outRedeemRejectedDF.iloc[i]['Redeem_Currency_Code'])
            redeemvalue = str(outRedeemRejectedDF.iloc[i]['Redeem_Value'])
            rejectedid = str(outRedeemRejectedDF.iloc[i]['Rejected_ID'])
            batchdateday = str(outRedeemRejectedDF.iloc[i]['Batch_Day'])
            batchdatemonth = str(outRedeemRejectedDF.iloc[i]['Batch_Month'])
            batchdateyear = str(outRedeemRejectedDF.iloc[i]['Batch_Year'])
            taxid = str(outRedeemRejectedDF.iloc[i]['Tax_ID'])
            if taxid == "nan":
                taxid = "NULL"
            externalaccountcode = str(outRedeemRejectedDF.iloc[i]['External_Account_Code'])
            if externalaccountcode == "nan":
                externalaccountcode = "NULL"
            values = corpcode + "', '" + programcode + "', '" + usercode + "', '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + redeemcurrencycode + "', '" + redeemvalue + "', '" + rejectedid + "', '" + batchdateday + "', '" + batchdatemonth + "', '" + batchdateyear + "', " + taxid + ", " + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + ");"
            postgreSQLExecuteCommand(cur, SQLCommand)
        postgreSQLClose(conn, cur)
    if verbose == 1:
        print(tablename + " migrated")