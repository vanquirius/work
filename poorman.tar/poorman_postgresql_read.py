# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-16
# PostgreSQL module to read data from tables

from poorman_postgresql import *

#######################################################################################################################################################
# Function definitions                                                                                                                                #
#######################################################################################################################################################

# CorpNames
def readCorpNamesPostgreSQL():
    tablename = "corpnames"
    fieldnames = ["Corp_Code", "Corp_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# CountryCodes
def readCountryCodesPostgreSQL():
    tablename = "countrycodes"
    fieldnames = ["Country_Code", "Country_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# CurrencyNames
def readCurrencyNamesPostgreSQL():
    tablename = "currencynames"
    fieldnames = ["Currency_Code", "Currency_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ProductNames
def readProductNamesPostgreSQL():
    tablename = "productnames"
    fieldnames = ["Product_Code", "Product_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ProgramNames
def readProgramNamesPostgreSQL():
    tablename = "programnames"
    fieldnames = ["Program_Code", "Program_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ProgramSetup
def readProgramSetupPostgreSQL():
    tablename = "programsetup"
    fieldnames = ["Corp_Code", "Country_Code", "Program_Code", "Currency_Code", "Points_per_Currency", "Expiration_Days"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ProgramAttrib
def readProgramAttribPostgreSQL():
    tablename = "programattrib"
    fieldnames = ["Program_Code", "Active_Program", "Redeem_Currency_Code", "Currency_per_Points", "Redeem_Min_points", "Renew_Expiry_On_Purchase"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# UserProfile
def readUserProfilePostgreSQL():
    tablename = "userprofile"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Active_User", "User_Email", "User_Mobile_Country_Code", "User_Mobile_Area_Code", "User_Mobile_Phone_Number", "Active_Email", "Active_Mobile", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# PointsBank
def readPointsBankPostgreSQL():
    tablename = "pointsbank"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Expiry_Date_Day", "Expiry_Date_Month", "Expiry_Date_Year"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# AddedPoints
def readAddedPointsPostgreSQL():
    tablename = "addedpoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Currency_Code", "Value", "Points_per_Currency", "Date_Day", "Date_Month", "Date_Year", "Expiry_Date_Day", "Expiry_Date_Month", "Expiry_Date_Year", "Added_ID"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ExpiredPoints
def readExpiredPointsPostgreSQL():
    tablename = "expiredpoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Expiry_Date_Day", "Expiry_Date_Month", "Expiry_Date_Year", "Expiry_ID"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# RedeemApproved
def readRedeemApprovedPostgreSQL():
    tablename = "redeemapproved"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Redeem_Currency_Code", "Redeem_Value", "Approval_ID"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# RedeemRejected
def readRedeemRejectedPostgreSQL():
    tablename = "redeemrejected"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Redeem_Currency_Code", "Redeem_Value", "Rejected_ID"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# ListRedeemable
def readListRedeemablePostgreSQL():
    tablename = "listredeemable"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Redeem_Currency_Code", "Redeem_Value"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# RedeemableSent
def readRedeemableSentPostgreSQL():
    tablename = "redeemablesent"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Redeem_Currency_Code", "User_Email", "User_Mobile_Country_Code", "User_Mobile_Area_Code", "User_Mobile_Phone_Number", "Active_Email", "Active_Mobile", "Redeem_Value", "Date_Day", "Date_Month", "Date_Year", "Token_Code", "Token_Sent", "Points2", "Currency_Name"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# WelcomeUserQueue
def readWelcomeUserQueuePostgreSQL():
    tablename = "welcomeuserqueue"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Active_User", "User_Email", "User_Mobile_Country_Code", "User_Mobile_Area_Code", "User_Mobile_Phone_Number", "Active_Email", "Active_Mobile", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# AddUserProfile
def readAddUserPostgreSQL():
    tablename = "adduserprofile"
    fieldnames = ["Corp_Code", "Program_Code", "Active_User", "User_Email", "User_Mobile_Country_Code", "User_Mobile_Area_Code", "User_Mobile_Phone_Number", "Active_Email", "Active_Mobile", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# UpdateUserProfile
def readUpdateUserPostgreSQL():
    tablename = "updateuserprofile"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Active_User", "User_Email", "User_Mobile_Country_Code", "User_Mobile_Area_Code", "User_Mobile_Phone_Number", "Active_Email", "Active_Mobile", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# LoadPoints
def readLoadPointsPostgreSQL():
    tablename = "loadpoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Currency_Code", "Value", "Date_Day", "Date_Month", "Date_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# RedeemPoints
def readRedeemPointsPostgreSQL():
    tablename = "redeempoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# OutAddedPoints
def readoutAddedPointsPostgreSQL():
    tablename = "outaddedpoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Currency_Code", "Value", "Points_per_Currency", "Date_Day", "Date_Month", "Date_Year", "Expiry_Date_Day", "Expiry_Date_Month", "Expiry_Date_Year", "Added_ID", "Batch_Day", "Batch_Month", "Batch_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# OutExpiredPoints
def readoutExpiredPointsPostgreSQL():
    tablename = "outexpiredpoints"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Expiry_Date_Day", "Expiry_Date_Month", "Expiry_Date_Year", "Expiry_ID", "Batch_Day", "Batch_Month", "Batch_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# OutRedeemApproved
def readoutRedeemApprovedPostgreSQL():
    tablename = "outredeemapproved"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Redeem_Currency_Code", "Redeem_Value", "Approval_ID", "Batch_Day", "Batch_Month", "Batch_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

# OutRedeemRejected
def readoutRedeemRejectedPostgreSQL():
    tablename = "outredeemrejected"
    fieldnames = ["Corp_Code", "Program_Code", "User_Code", "Points", "Date_Day", "Date_Month", "Date_Year", "Redeem_Currency_Code", "Redeem_Value", "Rejected_ID", "Batch_Day", "Batch_Month", "Batch_Year", "Tax_ID", "External_Account_Code"]
    conn, cur = postgreSQLConnect(postgreSQL_dic)
    SQLCommand = "SELECT * FROM poorman." + tablename + ";" 
    df = postgreSQLtoPandas(cur, SQLCommand, fieldnames)
    postgreSQLClose(conn, cur)
    return df

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################

#corpNamesDF = readCorpNamesPostgreSQL()
#countryCodesDF = readCountryCodesPostgreSQL()
#currencyNamesDF = readCurrencyNamesPostgreSQL()
#productNamesDF = readProductNamesPostgreSQL()
#programNamesDF = readProgramNamesPostgreSQL()
#programSetupDF = readProgramSetupPostgreSQL()
#programAttribDF = readProgramAttribPostgreSQL()
#userProfileDF = readUserProfilePostgreSQL()
#pointsBankDF = readPointsBankPostgreSQL()
#addedPointsDF = readAddedPointsPostgreSQL()
#expiredPointsDF = readExpiredPointsPostgreSQL()
#redeemApprovedDF = readRedeemApprovedPostgreSQL()
#redeemRejectedDF = readRedeemRejectedPostgreSQL()

#listRedeemableDF = readListRedeemablePostgreSQL()
#redeemableSentDF = readRedeemableSentPostgreSQL()
#welcomeUserQueueDF = readWelcomeUserQueuePostgreSQL()
#addUserDF = readAddUserPostgreSQL()
#updateUserDF = readUpdateUserPostgreSQL()
#loadPointsDF = readLoadPointsPostgreSQL()
#redeemPointsDF = readRedeemPointsPostgreSQL()

#outAddedPointsDF = readoutAddedPointsPostgreSQL()
#outExpiredPointsDF = readoutExpiredPointsPostgreSQL()
#outRedeemApprovedDF = readoutRedeemApprovedPostgreSQL()
#outRedeemRejectedDF = readoutRedeemRejectedPostgreSQL()