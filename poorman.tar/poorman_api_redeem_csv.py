# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-17
# API Redeem - csv version

# How to run development server (Windows/Linux):
# set FLASK_APP=poorman_api_redeem_csv.py (Windows)
# set FLASK_DEBUG=1 (Windows)
# export FLASK_APP=poorman_api_redeem_csv.py (Linux)
# export FLASK_DEBUG=1 (Linux)
# python -m flask run -p [port number]

# API server and redemption server are on different files by design
# They should be run separately so that only the redemption server is customer facing,
# while the API server is meant to exchange services with other systems

from poorman_points_engine_csv import *

import flask
from flask import request, jsonify

beginLogAPIServer

#######################################################################################################################################################
# Program                                                                                                                                             #
#######################################################################################################################################################

app = flask.Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    return '''<h1>Poorman's Payback API Server</h1>
<p>This is the API Server for Poorman's Payback.</p>'''

@app.route('/api/redeem/request', methods=['GET'])
# Attempt to redeem points
def postUserRedeem():
    if 'token' in request.args:
        # get token
        tokenReceived = str(request.args['token'])
        if verbose == 1:
            print("Token processed: " + str(tokenReceived))
 
        # load token table
        listRedeemableDF, redeemableSentDF = loadListRedeemable()

        # filter out entry for token
        redeemableSentDF = redeemableSentDF.loc[redeemableSentDF['Token_Code'] == tokenReceived]

        # organize data that came from API
        newRedeemDF = redeemableSentDF[['Corp_Code','Program_Code','User_Code','Points','Date_Day','Date_Month','Date_Year']]
        newRedeemDF['Tax_ID'] = "0"
        newRedeemDF['External_Account_Code'] = "0"

        # load points tables
        userProfileDF = userProfileLoad()
        wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)
        redeemPointsDF = redeemPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
        pointsBankDF = pointsBankLoad()
        redeemApprovedDF = redeemApprovedLoad()
        redeemRejectedDF = redeemRejectedLoad()
        programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
        programSetupAttributesDF = programSetupMerge(programSetupDF, programAttribDF)
        addedPointsDF = addedPointsLoad()
        userProfileDF = userProfileLoad()

        # append new points to redeem attempt
        redeemPointsDF = redeemPointsDF.append(newRedeemDF)

        # attempt to redeem points
        redeemPointsDF, pointsBankDF, redeemApprovedDF, redeemRejectedDF = redeemPoints(redeemPointsDF,pointsBankDF,redeemApprovedDF,redeemRejectedDF,programSetupAttributesDF,userProfileDF)

        # remove token from database
        listRedeemableDF, redeemableSentDF = loadListRedeemable()
        redeemableSentDF = redeemableSentDF.loc[redeemableSentDF['Token_Code'] != tokenReceived]

        # export updated files
        redeemPointsDF.to_csv(incomingbatchFileDirectory + "RedeemPoints.csv", index = False)
        pointsBankDF.to_csv("PointsBank.csv", index = False)
        redeemApprovedDF.to_csv("RedeemApproved.csv", index = False)
        redeemRejectedDF.to_csv("RedeemRejected.csv", index = False)
        redeemableSentDF.to_csv("ReedemableSent.csv", index = False)

        return "Success: request was received"
    else:
        return "Error: unable to process request"

endLogAPIServer()