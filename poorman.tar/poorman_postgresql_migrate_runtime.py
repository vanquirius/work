# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# PostgreSQL module to migrate existing csv data to new tables

from poorman_postgresql_migrate import *

#######################################################################################################################################################
# Batch runtime starts here                                                                                                                           #
#######################################################################################################################################################

# Import CSV files
programSetupDF, corpNamesDF, countryCodesDF, currencyNamesDF, productNamesDF, programNamesDF, programAttribDF = programSetupLoad()
userProfileDF = userProfileLoad()
welcomeUserQueueDF = welcomeUserQueue()
addUserDF = addUser()
updateUserDF = updateUser()
pointsBankDF = pointsBankLoad()
wrapperExternalAccountDF, wrapperTaxIDDF = wrapperExternalAccount(userProfileDF)
loadPointsDF = loadPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
redeemPointsDF = redeemPointsLoad(wrapperExternalAccountDF, wrapperTaxIDDF)
expiredPointsDF = expiredPointsLoad()
addedPointsDF = addedPointsLoad()
redeemApprovedDF = redeemApprovedLoad()
redeemRejectedDF = redeemRejectedLoad()

welcomeUserQueueDF = welcomeUserQueue()
listRedeemableDF, redeemableSentDF = loadListRedeemable()

outAddedPointsDF = outAddedPoints(addedPointsDF, outgoingBatchCut, userProfileDF)
outExpiredPointsDF = outExpiredPoints(expiredPointsDF, outgoingBatchCut, userProfileDF)
outRedeemApprovedDF = outRedeemApproved(redeemApprovedDF, outgoingBatchCut, userProfileDF)
outRedeemRejectedDF = outRedeemRejected(redeemRejectedDF, outgoingBatchCut, userProfileDF)

# Export CSV files to PostgreSQL tables
migrateCorpNamesPostgreSQL(corpNamesDF)
migrateCountryCodesPostgreSQL(countryCodesDF)
migrateCurrencyNamesPostgreSQL(currencyNamesDF)
migrateProductNamesPostgreSQL(productNamesDF)
migrateProgramNamesPostgreSQL(programNamesDF)
migrateProgramSetupPostgreSQL(programSetupDF)
migrateProgramAttribPostgreSQL(programAttribDF)
migrateUserProfilePostgreSQL(userProfileDF)
migratePointsBankPostgreSQL(pointsBankDF)
migrateAddedPointsPostgreSQL(addedPointsDF)
migrateExpiredPointsPostgreSQL(expiredPointsDF)
migrateRedeemApprovedPostgreSQL(redeemApprovedDF)
migrateRedeemRejectedPostgreSQL(redeemRejectedDF)

migrateListRedeemablePostgreSQL(listRedeemableDF)
migrateRedeemableSentPostgreSQL(redeemableSentDF)
migrateWelcomeUserQueuePostgreSQL(welcomeUserQueueDF)
migrateAddUserPostgreSQL(addUserDF)
migrateUpdateUserPostgreSQL(updateUserDF)
migrateLoadPointsPostgreSQL(loadPointsDF)
migrateRedeemPointsPostgreSQL(redeemPointsDF)

migrateoutAddedPointsPostgreSQL(outAddedPointsDF)
migrateoutExpiredPointsPostgreSQL(outExpiredPointsDF)
migrateoutRedeemApprovedPostgreSQL(outRedeemApprovedDF)
migrateoutRedeemRejectedPostgreSQL(outRedeemRejectedDF)