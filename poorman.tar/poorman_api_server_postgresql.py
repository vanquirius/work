# Poorman's Payback
# Marcelo Ambrosio de Góes
# 2020-12-18
# API Server - PostgreSQL version

# How to run development server (Windows/Linux):
# set FLASK_APP=poorman_api_server_postgresql.py (Windows)
# set FLASK_DEBUG=1 (Windows)
# export FLASK_APP=poorman_api_server_postgresql.py (Linux)
# export FLASK_DEBUG=1 (Linux)
# python -m flask run -p [port number]

# API server and redemption server are on different files by design
# They should be run separately so that only the redemption server is customer facing,
# while the API server is meant to exchange services with other systems

from poorman_points_engine_postgresql import *

import flask
from flask import request, jsonify

beginLogAPIServer

#######################################################################################################################################################
# Program                                                                                                                                             #
#######################################################################################################################################################

app = flask.Flask(__name__)

@app.route('/', methods=['GET'])
def home():
    return '''<h1>Poorman's Payback API Server</h1>
<p>This is the API Server for Poorman's Payback.</p>'''

@app.route('/api/programs/setup', methods=['GET'])
# Get list of programs
def getPrograms():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        programSetupDF = readProgramSetupPostgreSQL()
        jsonResults = programSetupDF.to_json(orient="split")
        return jsonResults

    else:
        return "Error: token not accepted or missing"

@app.route('/api/programs/attributes', methods=['GET'])
# Get list of programs
def getProgramsAttrib():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        programAttribDF = readProgramAttribPostgreSQL()
        jsonResults = programAttribDF.to_json(orient="split")
        return jsonResults

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/usercode', methods=['GET'])
# Get user information with user code
def getUsersPerUserCode():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            userProfileDF = readUserProfilePostgreSQL()
            userProfileDF = userProfileDF.loc[userProfileDF['User_Code'].astype(str) == usercode]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/taxid', methods=['GET'])
# Get user information based on tax ID
def getUsersPerTaxID():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'taxid' in request.args:
            taxid = str(request.args['taxid'])
            userProfileDF = readUserProfilePostgreSQL()
            userProfileDF = userProfileDF.loc[userProfileDF['Tax_ID'].astype(str) == taxid]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: tax id missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/externalaccount', methods=['GET'])
# Get user information based on external account
def getUsersPerExternalAccount():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'externalaccount' in request.args:
            externalaccount = str(request.args['externalaccount'])
            userProfileDF = readUserProfilePostgreSQL()
            userProfileDF = userProfileDF.loc[userProfileDF['External_Account_Code'].astype(str) == externalaccount]
            jsonResults = userProfileDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: external account missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/pointsbank', methods=['GET'])
# Get points bank information based on user code
def getPointsBankperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            pointsBankDF = readPointsBankPostgreSQL()
            pointsBankDF = pointsBankDF.loc[pointsBankDF['User_Code'].astype(str) == usercode]
            jsonResults = pointsBankDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/added', methods=['GET'])
# Get added points history based on user code
def getAddedPointsperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            addedPointsDF = readAddedPointsPostgreSQL()
            addedPointsDF = addedPointsDF.loc[addedPointsDF['User_Code'].astype(str) == usercode]
            jsonResults = addedPointsDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/expired', methods=['GET'])
# Get expired points history based on user code
def getExpiredPointsperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            expiredPointsDF = readExpiredPointsPostgreSQL()
            expiredPointsDF = expiredPointsDF.loc[expiredPointsDF['User_Code'].astype(str) == usercode]
            jsonResults = expiredPointsDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/approved', methods=['GET'])
# Get approved redemptions based on user code
def getApprovedRedeemperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            redeemApprovedDF = readRedeemApprovedPostgreSQL()
            redeemApprovedDF = redeemApprovedDF.loc[redeemApprovedDF['User_Code'].astype(str) == usercode]
            jsonResults = redeemApprovedDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/rejected', methods=['GET'])
# Get rejected redemptions based on user code
def getRejectedRedeemperUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if 'usercode' in request.args:
            usercode = str(request.args['usercode'])
            redeemRejectedDF = readRedeemRejectedPostgreSQL()
            redeemRejectedDF = redeemRejectedDF.loc[redeemRejectedDF['User_Code'].astype(str) == usercode]
            jsonResults = redeemRejectedDF.to_json(orient="split")
            return jsonResults
        else:
            return "Error: usercode missing"

    else:
        return "Error: token not accepted or missing"


@app.route('/api/users/add', methods=['POST'])
# Add new user profile
def postAddUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('activeuser' in request.args) & ('useremail' in request.args) & ('usermobilecountrycode' in request.args) & ('usermobileareacode' in request.args) & ('usermobilephonenumber' in request.args) & ('activeemail' in request.args) & ('activemobile' in request.args) & ('taxid' in request.args) & ('externalaccountcode' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            activeuser = str(request.args['activeuser'])
            useremail = str(request.args['useremail'])
            usermobilecountrycode = str(request.args['usermobilecountrycode'])
            usermobileareacode = str(request.args['usermobileareacode'])
            usermobilephonenumber = str(request.args['usermobilephonenumber'])
            activeemail = str(request.args['activeemail'])
            activemobile = str(request.args['activemobile'])
            taxid = str(request.args['taxid'])
            externalaccountcode = str(request.args['externalaccountcode'])

            conn, cur = postgreSQLConnect(postgreSQL_dic)

            # organize data that came from API
            # load user tables            
            # append new user to add user list
            tablename = "adduserprofile"            
            fieldnames = "(Corp_Code, Program_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
            values = corpcode + "', '" + programcode + "', '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', '" + taxid + "', '" + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
            postgreSQLExecuteCommand(cur, SQLCommand)

            postgreSQLClose(conn, cur)

            # add new users to profile
            addUserProfile()

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/users/update', methods=['POST'])
# Update profile of existing user
def postUpdateUser():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('activeuser' in request.args) & ('useremail' in request.args) & ('usermobilecountrycode' in request.args) & ('usermobileareacode' in request.args) & ('usermobilephonenumber' in request.args) & ('activeemail' in request.args) & ('activemobile' in request.args) & ('taxid' in request.args) & ('externalaccountcode' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            activeuser = str(request.args['activeuser'])
            useremail = str(request.args['useremail'])
            usermobilecountrycode = str(request.args['usermobilecountrycode'])
            usermobileareacode = str(request.args['usermobileareacode'])
            usermobilephonenumber = str(request.args['usermobilephonenumber'])
            activeemail = str(request.args['activeemail'])
            activemobile = str(request.args['activemobile'])
            taxid = str(request.args['taxid'])
            externalaccountcode = str(request.args['externalaccountcode'])

            conn, cur = postgreSQLConnect(postgreSQL_dic)

            # organize data that came from API
            # load user tables            
            # append new user to add user list
            tablename = "updateuserprofile"            
            fieldnames = "(Corp_Code, Program_Code, User_Code, Active_User, User_Email, User_Mobile_Country_Code, User_Mobile_Area_Code, User_Mobile_Phone_Number, Active_Email, Active_Mobile, Tax_ID, External_Account_Code)"
            values = corpcode + "', '" + programcode + "', " + usercode + ", '" + activeuser + "', '" + useremail + "', '" + usermobilecountrycode + "', '" + usermobileareacode + "', '" + usermobilephonenumber + "', '" + activeemail + "', '" + activemobile + "', '" + taxid + "', '" + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
            postgreSQLExecuteCommand(cur, SQLCommand)

            postgreSQLClose(conn, cur)

            # update users to profile
            updateUserProfile()

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/points/add', methods=['POST'])
# Add points to user
def postAddPoints():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
        
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('currencycode' in request.args) & ('value' in request.args) & ('externalaccountcode' in request.args) & ('taxid' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            currencycode = str(request.args['currencycode'])
            value = str(request.args['value'])
            dateday = str(datetime.now().day)
            datemonth = str(datetime.now().month)
            dateyear = str(datetime.now().year)
            externalaccountcode = str(request.args['externalaccountcode'])
            taxid = str(request.args['taxid'])

            conn, cur = postgreSQLConnect(postgreSQL_dic)

            # organize data that came from API
            # load points tables          
            # append new points to load points
            tablename = "loadpoints"
            fieldnames = "(Corp_Code, Program_Code, User_Code, Currency_Code, Value, Date_Day, Date_Month, Date_Year, Tax_ID, External_Account_Code)"
            values = corpcode + "', '" + programcode + "', " + usercode + ", '" + currencycode + "', '" + value + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "', '" + taxid + "', '" + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
            postgreSQLExecuteCommand(cur, SQLCommand)

            postgreSQLClose(conn, cur)

            # add points to point bank
            addPointsBank()

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

@app.route('/api/redeem/execute', methods=['POST'])

# Attempt to redeem points
def postRedeemPoints():
    # Validate API token
    apiTokenReceived = str(request.args['apiToken'])
    if apiTokenReceived == apiToken:
 
        if ('corpcode' in request.args) & ('programcode' in request.args) & ('usercode' in request.args) & ('points' in request.args) & ('externalaccountcode' in request.args) & ('taxid' in request.args):
            corpcode = str(request.args['corpcode'])
            programcode = str(request.args['programcode'])
            usercode = str(request.args['usercode'])
            points = str(request.args['points'])
            dateday = str(datetime.now().day)
            datemonth = str(datetime.now().month)
            dateyear = str(datetime.now().year)
            externalaccountcode = str(request.args['externalaccountcode'])
            taxid = str(request.args['taxid'])

            conn, cur = postgreSQLConnect(postgreSQL_dic)

            # organize data that came from API
            # load points tables           
            # append new points to redeem attempt
            tablename = "redeempoints"
            fieldnames = "(Corp_Code, Program_Code, User_Code, Points, Date_Day, Date_Month, Date_Year, Tax_ID, External_Account_Code)"
            values = corpcode + "', '" + programcode + "', " + usercode + ", '" + points + "', '" + dateday + "', '" + datemonth + "', '" + dateyear + "',  '" + taxid + "', '" + externalaccountcode
            SQLCommand = "INSERT INTO poorman." + tablename + " " + fieldnames + " VALUES ('" + values + "');"
            postgreSQLExecuteCommand(cur, SQLCommand)

            postgreSQLClose(conn, cur)

            # attempt to redeem points
            redeemPoints()

            return "Success: information uploaded"
        else:
            return "Error: fields missing"

    else:
        return "Error: token not accepted or missing"

endLogAPIServer()